# NEXUS — Native Android AI Companion

NEXUS is a native Kotlin & Jetpack Compose AI companion built for Android 12+ (`minSdk = 31`, `targetSdk = 35`) inspired by interactive gaming smartphone companions.

## Key Features
- **Exact Character Identity (High-Res PNG)**: Renders the uploaded high-resolution transparent character PNG (`res/drawable-nodpi/nexus_character.png`) with natural breathing, blinking, idle head/eye glancing, sleep animations, and 5 expressions (`Neutral`, `Happy`, `Annoyed`, `Surprised`, `Sleepy`).
- **Multi-Zone Touch, Long Press & Mood System**: Distinct reactions for head pat, shoulder tap, torso, pockets, sneakers, repeated taps, and long presses, backed by a persistent mood state (`Chill`, `Playful`, `Focused`, `Charged`, `Tired`, `Irritated`).
- **5 Character Modes**: `Normal`, `Gaming`, `Charging`, `Sleep`, and `Conversation`, each with tailored visuals, animations, and voice lines.
- **AI Chat & Voice**: Multi-turn chat with local `SharedPreferences` history, Android `SpeechRecognizer` voice input, `TextToSpeech` voice output, and honest separation between live backend Gemini AI (`/api/nexus/chat`) and local offline dialogue.
- **Real Phone Integration**: Live `BatteryManager` percentage & charging source detection, real clock/date, Gaming Session Timer, installed app & game launcher (`PackageManager`), optional `UsageStatsManager` foreground game detection, and optional `NotificationListenerService`.
- **4 Clean Screens**: `Home`, `Chat`, `Customize`, `Settings`.

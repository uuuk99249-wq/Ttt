# NEXUS Companion ProGuard Rules
-keepattributes *Annotation*, InnerClasses
-keep class com.nexus.companion.system.** { *; }
-keep class com.nexus.companion.model.** { *; }

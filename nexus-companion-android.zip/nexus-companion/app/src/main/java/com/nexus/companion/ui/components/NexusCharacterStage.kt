package com.nexus.companion.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.nexus.companion.animation.AnimationStateDirective
import com.nexus.companion.animation.BlinkMode
import com.nexus.companion.animation.BrowStyle
import com.nexus.companion.animation.MouthStyle
import com.nexus.companion.animation.NexusAnimationController
import com.nexus.companion.animation.StageEffectOverlay
import com.nexus.companion.model.AnimationIntensity
import com.nexus.companion.model.BackgroundTheme
import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CharacterPoseKey
import com.nexus.companion.model.CharacterTouchZone
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.ui.theme.NexusColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun NexusCharacterStage(
    mode: CharacterMode,
    expression: CharacterExpression,
    settings: CustomizationSettings,
    isPowerSaveMode: Boolean,
    isSpeakingOrListening: Boolean,
    touchPulseNonce: Int,
    onCharacterTap: (CharacterTouchZone) -> Unit,
    onCharacterDoubleTap: (CharacterTouchZone) -> Unit = {},
    onCharacterLongPress: (CharacterTouchZone) -> Unit = {},
    emotion: CompanionEmotion = CompanionEmotion.NEUTRAL,
    situation: CompanionSituation = CompanionSituation.IDLE,
    isSpeaking: Boolean = false,
    isListening: Boolean = false,
    isThinking: Boolean = false,
    speechMouthLevel: Float = 0f,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val directive = remember(
        emotion,
        situation,
        mode,
        settings.pinnedExpression,
        expression,
        isSpeaking,
        isListening,
        isThinking
    ) {
        NexusAnimationController.resolveDirective(
            emotion = emotion,
            situation = situation,
            mode = mode,
            expressionOverride = settings.pinnedExpression ?: expression,
            isSpeaking = isSpeaking,
            isListening = isListening,
            isThinking = isThinking
        )
    }

    var resolvedPose by remember { mutableStateOf<ResolvedCharacterPose?>(null) }
    LaunchedEffect(directive.poseKey) {
        resolvedPose = CharacterCutoutLoader.loadPoseBitmap(context, directive.poseKey)
    }
    LaunchedEffect(Unit) {
        if (resolvedPose == null) {
            resolvedPose = CharacterCutoutLoader.loadPoseBitmap(context, CharacterPoseKey.DEFAULT_STANDING)
        }
    }

    val effectiveIntensity = remember(settings.animationIntensity, settings.batterySaverThrottle, isPowerSaveMode, mode) {
        when {
            settings.animationIntensity == AnimationIntensity.OFF -> 0f
            settings.batterySaverThrottle && isPowerSaveMode -> 0.25f
            mode == CharacterMode.SLEEP -> settings.animationIntensity.multiplier * 0.45f
            else -> settings.animationIntensity.multiplier
        }
    }

    val targetFrameDelayMs = remember(settings.animationIntensity, settings.batterySaverThrottle, isPowerSaveMode, mode) {
        when {
            settings.animationIntensity == AnimationIntensity.OFF -> 0L
            settings.batterySaverThrottle && isPowerSaveMode -> 48L
            mode == CharacterMode.SLEEP -> maxOf(settings.animationIntensity.frameDelayMs, 42L)
            else -> settings.animationIntensity.frameDelayMs
        }
    }

    var breathPhase by remember { mutableFloatStateOf(0f) }
    var energyPhase by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(effectiveIntensity, targetFrameDelayMs, mode, directive.breathSpeedMultiplier) {
        if (effectiveIntensity <= 0f || targetFrameDelayMs <= 0L) return@LaunchedEffect
        val baseBreathCycleMs = if (mode == CharacterMode.SLEEP) 4800f else 3200f
        val breathCycleMs = (baseBreathCycleMs / directive.breathSpeedMultiplier).coerceIn(1800f, 6200f)
        var lastTimeMs = System.currentTimeMillis()
        while (isActive) {
            if (targetFrameDelayMs <= 16L) {
                withFrameMillis { frameMs ->
                    val dt = (frameMs - lastTimeMs).coerceIn(0L, 100L)
                    lastTimeMs = frameMs
                    breathPhase = (breathPhase + (dt / breathCycleMs) * (2f * PI).toFloat()) % (2f * PI).toFloat()
                    energyPhase = (energyPhase + (dt / 3600f)) % 1f
                }
            } else {
                delay(targetFrameDelayMs)
                val now = System.currentTimeMillis()
                val dt = (now - lastTimeMs).coerceIn(0L, 200L)
                lastTimeMs = now
                breathPhase = (breathPhase + (dt / breathCycleMs) * (2f * PI).toFloat()) % (2f * PI).toFloat()
                energyPhase = (energyPhase + (dt / 3600f)) % 1f
            }
        }
    }

    // Natural randomized blinking timer honoring blinkMode
    var blinkProgress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(effectiveIntensity, directive.blinkMode, mode) {
        when {
            effectiveIntensity == 0f -> {
                blinkProgress = if (directive.blinkMode == BlinkMode.SLEEPING) 0.7f else 0f
                return@LaunchedEffect
            }
            directive.blinkMode == BlinkMode.SLEEPING || mode == CharacterMode.SLEEP -> {
                blinkProgress = 0.72f
                return@LaunchedEffect
            }
            directive.blinkMode == BlinkMode.WIDE_ALERT -> {
                blinkProgress = 0f
                delay(Random.nextLong(4200L, 7000L))
            }
        }
        while (isActive) {
            val waitRange = if (directive.blinkMode == BlinkMode.SLOW_HEAVY) 2000L..4200L else 2400L..5400L
            delay(Random.nextLong(waitRange.first, waitRange.last))
            val duration = if (directive.blinkMode == BlinkMode.SLOW_HEAVY) 180L else 105L
            blinkProgress = 1f
            delay(duration)
            blinkProgress = 0f
            if (directive.blinkMode == BlinkMode.NORMAL && Random.nextFloat() < 0.18f) {
                delay(125L)
                blinkProgress = 1f
                delay(95L)
                blinkProgress = 0f
            }
        }
    }

    // Idle left/right glance when situation/emotion isn't overriding gaze
    var idleLookTarget by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(effectiveIntensity, mode, directive.gazeX, directive.gazeY, isListening, isSpeaking) {
        if (effectiveIntensity == 0f || mode == CharacterMode.SLEEP || isListening || abs(directive.gazeX) > 0.05f || abs(directive.gazeY) > 0.05f) {
            idleLookTarget = 0f
            return@LaunchedEffect
        }
        val directions = listOf(-0.85f, -0.55f, 0.55f, 0.85f)
        while (isActive) {
            delay(Random.nextLong(3400L, 6400L))
            idleLookTarget = if (idleLookTarget != 0f) {
                0f
            } else {
                directions[Random.nextInt(directions.size)]
            }
        }
    }

    // Smooth transitions between animation states
    val animTiltDeg by animateFloatAsState(
        targetValue = directive.headTiltDeg * effectiveIntensity.coerceAtMost(1.25f),
        animationSpec = spring(dampingRatio = 0.72f, stiffness = 260f),
        label = "anim_tilt"
    )
    val animLeanX by animateFloatAsState(
        targetValue = directive.bodyLeanXFactor * effectiveIntensity.coerceAtMost(1.25f),
        animationSpec = tween(durationMillis = 480, easing = FastOutSlowInEasing),
        label = "anim_lean_x"
    )
    val animLiftY by animateFloatAsState(
        targetValue = directive.bodyLiftYDp * effectiveIntensity.coerceAtMost(1.25f),
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 240f),
        label = "anim_lift_y"
    )
    val animPoseScale by animateFloatAsState(
        targetValue = directive.scaleMultiplier,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = 280f),
        label = "anim_pose_scale"
    )
    val animGazeX by animateFloatAsState(
        targetValue = if (abs(directive.gazeX) > 0.05f) directive.gazeX else idleLookTarget * effectiveIntensity,
        animationSpec = tween(durationMillis = 560, easing = FastOutSlowInEasing),
        label = "anim_gaze_x"
    )
    val animGazeY by animateFloatAsState(
        targetValue = directive.gazeY,
        animationSpec = tween(durationMillis = 460, easing = FastOutSlowInEasing),
        label = "anim_gaze_y"
    )
    val animBlush by animateFloatAsState(
        targetValue = directive.cheekBlushAlpha,
        animationSpec = tween(durationMillis = 420),
        label = "anim_blush"
    )

    val rawMouthTarget = NexusAnimationController.computeEffectiveMouthOpenness(
        isSpeaking = isSpeaking,
        speechMouthLevel = speechMouthLevel,
        mouthStyle = directive.mouthStyle,
        yawnCyclePhase = energyPhase
    )
    val animMouthOpen by animateFloatAsState(
        targetValue = rawMouthTarget,
        animationSpec = tween(durationMillis = if (isSpeaking) 65 else 240, easing = FastOutSlowInEasing),
        label = "anim_mouth_open"
    )

    // Touch bounce spring
    var activeTapBounce by remember { mutableStateOf(false) }
    var lastTapPoint by remember { mutableStateOf<Offset?>(null) }
    var lastTapTimeMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(touchPulseNonce) {
        if (touchPulseNonce > 0) {
            activeTapBounce = true
            delay(170L)
            activeTapBounce = false
        }
    }

    val tapBounceScale by animateFloatAsState(
        targetValue = if (activeTapBounce) 0.985f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "tap_bounce"
    )
    val smoothBlink by animateFloatAsState(
        targetValue = blinkProgress,
        animationSpec = tween(
            durationMillis = if (directive.blinkMode == BlinkMode.SLOW_HEAVY) 145 else 85,
            easing = FastOutSlowInEasing
        ),
        label = "blink_smooth"
    )

    val modeAccent = remember(mode, directive.emotion) {
        when {
            mode == CharacterMode.CHARGING -> NexusColors.MintEnergy
            mode == CharacterMode.SLEEP -> NexusColors.SleepSlate
            directive.emotion == CompanionEmotion.ANGRY -> NexusColors.CoralAlert
            directive.emotion == CompanionEmotion.EMBARRASSED -> Color(0xFFF472B6)
            directive.emotion == CompanionEmotion.CARING -> NexusColors.MintEnergy
            mode == CharacterMode.GAMING -> NexusColors.CyanSoft
            else -> NexusColors.CyanElectric
        }
    }

    var lastRenderedRect by remember { mutableStateOf(Rect.Zero) }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(settings, lastRenderedRect) {
                    fun resolveZone(offset: Offset): CharacterTouchZone {
                        val rect = lastRenderedRect
                        val relY = if (rect.height > 1f) {
                            ((offset.y - rect.top) / rect.height).coerceIn(0f, 1f)
                        } else {
                            0.35f
                        }
                        return when {
                            relY < 0.14f -> CharacterTouchZone.HEAD
                            relY < 0.24f -> CharacterTouchZone.SHOULDER
                            relY < 0.49f -> CharacterTouchZone.TORSO
                            relY < 0.72f -> CharacterTouchZone.POCKETS
                            else -> CharacterTouchZone.SNEAKERS
                        }
                    }

                    detectTapGestures(
                        onTap = { tapOffset ->
                            lastTapPoint = tapOffset
                            lastTapTimeMs = System.currentTimeMillis()
                            onCharacterTap(resolveZone(tapOffset))
                        },
                        onDoubleTap = { doubleOffset ->
                            lastTapPoint = doubleOffset
                            lastTapTimeMs = System.currentTimeMillis()
                            onCharacterDoubleTap(resolveZone(doubleOffset))
                        },
                        onLongPress = { pressOffset ->
                            lastTapPoint = pressOffset
                            lastTapTimeMs = System.currentTimeMillis()
                            onCharacterLongPress(resolveZone(pressOffset))
                        }
                    )
                }
        ) {
            // 1. Background Theme
            drawStageBackground(
                theme = settings.backgroundTheme,
                accent = modeAccent,
                energyPhase = if (effectiveIntensity > 0f) energyPhase else 0f
            )

            // 2. Character Floor Projection & Subtle Aura
            val pose = resolvedPose
            if (pose != null) {
                val bmp = pose.bitmap
                val breathSin = sin(breathPhase) * effectiveIntensity
                val swayCos = cos(breathPhase * 0.5f) * effectiveIntensity
                val excitedBob = if (directive.emotion == CompanionEmotion.EXCITED) {
                    abs(sin(breathPhase * 2f)) * -4.2f * effectiveIntensity
                } else {
                    0f
                }

                val baseAspect = bmp.width.toFloat() / bmp.height.toFloat()
                val maxCharHeight = size.height * 0.90f * settings.scale
                val drawHeight = maxCharHeight.coerceAtMost(size.height * 1.15f)
                val drawWidth = drawHeight * baseAspect

                val centerX = size.width * 0.5f + settings.offsetXFraction * size.width
                val centerY = size.height * 0.53f + settings.offsetYFraction * size.height

                val breathScaleY = 1f + breathSin * 0.008f
                val breathShiftY = -breathSin * 3.5f + animLiftY + excitedBob
                val gazeTilt = animGazeX * 0.65f
                val swayRotationDeg = swayCos * 0.55f + animTiltDeg + gazeTilt +
                    (if (expression == CharacterExpression.ANNOYED && activeTapBounce) -1.4f else 0f)

                val topLeftX = centerX - drawWidth / 2f + animLeanX * drawWidth * 0.014f + animGazeX * 2.0f
                val topLeftY = centerY - drawHeight / 2f + breathShiftY
                lastRenderedRect = Rect(topLeftX, topLeftY, topLeftX + drawWidth, topLeftY + drawHeight)

                // Floor cyan glow ring under sneakers
                val ringWidth = drawWidth * 1.18f
                val ringHeight = ringWidth * 0.16f
                drawOval(
                    brush = Brush.radialGradient(
                        colors = listOf(modeAccent.copy(alpha = 0.28f), Color.Transparent),
                        center = Offset(centerX, topLeftY + drawHeight * 0.97f),
                        radius = ringWidth * 0.55f
                    ),
                    topLeft = Offset(centerX - ringWidth * 0.55f, topLeftY + drawHeight * 0.90f),
                    size = Size(ringWidth * 1.1f, ringHeight * 1.6f)
                )
                drawOval(
                    color = modeAccent.copy(alpha = if (isSpeakingOrListening || isSpeaking || isListening) 0.72f else 0.35f),
                    topLeft = Offset(centerX - ringWidth / 2f, topLeftY + drawHeight * 0.955f),
                    size = Size(ringWidth, ringHeight),
                    style = Stroke(width = 2.2f)
                )

                // Charging rising energy particles
                if (mode == CharacterMode.CHARGING && effectiveIntensity > 0f) {
                    drawChargingParticles(
                        centerX = centerX,
                        baseY = topLeftY + drawHeight * 0.94f,
                        spreadX = drawWidth * 0.65f,
                        riseHeight = drawHeight * 0.78f,
                        phase = energyPhase,
                        accent = modeAccent
                    )
                }

                // Gaming mode precision telemetry brackets around character
                if (mode == CharacterMode.GAMING) {
                    drawGamingReticle(
                        rect = lastRenderedRect,
                        accent = modeAccent,
                        pulse = (sin(breathPhase) + 1f) * 0.5f
                    )
                }

                // Conversation / active speech acoustic wave arcs flanking character
                if (mode == CharacterMode.CONVERSATION || isSpeakingOrListening || isSpeaking || isListening) {
                    drawConversationWaves(
                        centerX = centerX,
                        centerY = topLeftY + drawHeight * 0.12f,
                        spreadX = drawWidth * 0.55f,
                        phase = energyPhase,
                        accent = modeAccent,
                        active = isSpeaking || isListening || isSpeakingOrListening,
                        level = if (isSpeaking) animMouthOpen else 0.5f
                    )
                }

                // 3. Draw Exact High-Res Character Cutout (or optional pose asset) with smooth posture transform
                withTransform({
                    scale(
                        scaleX = tapBounceScale * animPoseScale,
                        scaleY = tapBounceScale * animPoseScale * breathScaleY,
                        pivot = Offset(centerX, topLeftY + drawHeight)
                    )
                    rotate(
                        degrees = swayRotationDeg,
                        pivot = Offset(centerX, topLeftY + drawHeight * 0.85f)
                    )
                }) {
                    drawImage(
                        image = bmp,
                        srcOffset = IntOffset.Zero,
                        srcSize = IntSize(bmp.width, bmp.height),
                        dstOffset = IntOffset(topLeftX.roundToInt(), topLeftY.roundToInt()),
                        dstSize = IntSize(drawWidth.roundToInt(), drawHeight.roundToInt())
                    )

                    // 4. Precision Facial Expression, Gaze, Blink, Mouth Sync & Situation Overlays
                    if (!pose.isDedicatedPoseAsset) {
                        drawSituationFacialRig(
                            rect = lastRenderedRect,
                            directive = directive,
                            blinkAmount = smoothBlink,
                            gazeX = animGazeX,
                            gazeY = animGazeY,
                            mouthOpenness = animMouthOpen,
                            blushAlpha = animBlush,
                            accent = modeAccent,
                            energyPhase = energyPhase,
                            isSleepMode = mode == CharacterMode.SLEEP
                        )
                    }
                }
            }

            // Sleep mode subtle low-power dimmer
            if (mode == CharacterMode.SLEEP) {
                drawRect(color = NexusColors.Obsidian.copy(alpha = 0.25f))
            }

            // 5. Touch ripple feedback
            val tapPt = lastTapPoint
            val elapsed = System.currentTimeMillis() - lastTapTimeMs
            if (tapPt != null && elapsed in 0..420) {
                val p = elapsed / 420f
                drawCircle(
                    color = modeAccent.copy(alpha = (1f - p) * 0.65f),
                    radius = 14f + p * 64f,
                    center = tapPt,
                    style = Stroke(width = 2.5f * (1f - p * 0.5f))
                )
            }
        }

        if (resolvedPose == null) {
            CircularProgressIndicator(color = NexusColors.CyanElectric)
        }
    }
}

private fun DrawScope.drawStageBackground(
    theme: BackgroundTheme,
    accent: Color,
    energyPhase: Float
) {
    drawRect(color = NexusColors.Obsidian)

    when (theme) {
        BackgroundTheme.OBSIDIAN_GRID -> {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.12f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.42f),
                    radius = size.maxDimension * 0.55f
                )
            )
            val step = 48f
            val gridColor = accent.copy(alpha = 0.055f)
            var x = step
            while (x < size.width) {
                drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                x += step
            }
            var y = step
            while (y < size.height) {
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                y += step
            }
        }

        BackgroundTheme.CHARCOAL_HORIZON -> {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        NexusColors.CharcoalElevated,
                        NexusColors.Obsidian,
                        NexusColors.Charcoal
                    )
                )
            )
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.62f),
                    radius = size.width * 0.72f
                )
            )
        }

        BackgroundTheme.CYAN_CIRCUIT -> {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.15f), NexusColors.Obsidian),
                    center = Offset(size.width * 0.5f, size.height * 0.36f),
                    radius = size.maxDimension * 0.65f
                )
            )
            val traceColor = accent.copy(alpha = 0.14f)
            val y1 = size.height * (0.22f + energyPhase * 0.03f)
            drawLine(traceColor, Offset(0f, y1), Offset(size.width * 0.24f, y1), strokeWidth = 1.5f)
            drawLine(traceColor, Offset(size.width * 0.24f, y1), Offset(size.width * 0.31f, y1 + 28f), strokeWidth = 1.5f)
            drawLine(traceColor, Offset(size.width, y1 + 60f), Offset(size.width * 0.74f, y1 + 60f), strokeWidth = 1.5f)
            drawLine(traceColor, Offset(size.width * 0.74f, y1 + 60f), Offset(size.width * 0.68f, y1 + 84f), strokeWidth = 1.5f)
        }

        BackgroundTheme.STEALTH_MINIMAL -> {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.05f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.5f),
                    radius = size.width * 0.55f
                )
            )
        }
    }
}

private fun DrawScope.drawChargingParticles(
    centerX: Float,
    baseY: Float,
    spreadX: Float,
    riseHeight: Float,
    phase: Float,
    accent: Color
) {
    for (i in 0 until 8) {
        val t = (phase + i * 0.125f) % 1f
        val xOffset = sin(i * 1.9f + t * 4f) * spreadX * 0.45f
        val yPos = baseY - t * riseHeight
        val alpha = (1f - t) * 0.75f
        drawCircle(
            color = accent.copy(alpha = alpha),
            radius = 3.2f + (1f - t) * 2.5f,
            center = Offset(centerX + xOffset, yPos)
        )
    }
}

private fun DrawScope.drawGamingReticle(
    rect: Rect,
    accent: Color,
    pulse: Float
) {
    val c = accent.copy(alpha = 0.32f + pulse * 0.28f)
    val pad = 16f
    val len = 26f
    val left = rect.left - pad
    val right = rect.right + pad
    val top = rect.top + 8f
    val bottom = rect.bottom - 12f

    drawLine(c, Offset(left, top), Offset(left + len, top), strokeWidth = 2.2f)
    drawLine(c, Offset(left, top), Offset(left, top + len), strokeWidth = 2.2f)
    drawLine(c, Offset(right, top), Offset(right - len, top), strokeWidth = 2.2f)
    drawLine(c, Offset(right, top), Offset(right, top + len), strokeWidth = 2.2f)

    drawLine(c, Offset(left, bottom), Offset(left + len, bottom), strokeWidth = 2.2f)
    drawLine(c, Offset(left, bottom), Offset(left, bottom - len), strokeWidth = 2.2f)
    drawLine(c, Offset(right, bottom), Offset(right - len, bottom), strokeWidth = 2.2f)
    drawLine(c, Offset(right, bottom), Offset(right, bottom - len), strokeWidth = 2.2f)
}

private fun DrawScope.drawConversationWaves(
    centerX: Float,
    centerY: Float,
    spreadX: Float,
    phase: Float,
    accent: Color,
    active: Boolean,
    level: Float
) {
    val barCount = 3
    for (i in 0 until barCount) {
        val wave = (sin((phase * 2f * PI).toFloat() + i * 1.1f) + 1f) * 0.5f
        val dynamic = (wave * 0.6f + level * 0.65f).coerceIn(0.15f, 1.1f)
        val alpha = (if (active) 0.72f else 0.35f) * (0.45f + wave * 0.55f)
        val barH = 10f + dynamic * 20f
        val dx = spreadX + i * 11f
        drawLine(
            color = accent.copy(alpha = alpha),
            start = Offset(centerX - dx, centerY - barH / 2f),
            end = Offset(centerX - dx, centerY + barH / 2f),
            strokeWidth = 2.4f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = accent.copy(alpha = alpha),
            start = Offset(centerX + dx, centerY - barH / 2f),
            end = Offset(centerX + dx, centerY + barH / 2f),
            strokeWidth = 2.4f,
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawSleepGlyphZ(
    center: Offset,
    glyphSize: Float,
    color: Color
) {
    val half = glyphSize * 0.5f
    val path = Path().apply {
        moveTo(center.x - half, center.y - half)
        lineTo(center.x + half, center.y - half)
        lineTo(center.x - half, center.y + half)
        lineTo(center.x + half, center.y + half)
    }
    drawPath(
        path = path,
        color = color,
        style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun DrawScope.drawSituationFacialRig(
    rect: Rect,
    directive: AnimationStateDirective,
    blinkAmount: Float,
    gazeX: Float,
    gazeY: Float,
    mouthOpenness: Float,
    blushAlpha: Float,
    accent: Color,
    energyPhase: Float,
    isSleepMode: Boolean
) {
    val skinTone = Color(0xFFF7CEA4)
    val lashColor = Color(0xFF141820)
    val mouthStrokeColor = Color(0xFF5A3128)
    val mouthInteriorColor = Color(0xFF6B2D2B)

    // Pixel-measured landmarks on 1164x3428 PNG
    val gazeShiftX = gazeX * rect.width * 0.0062f
    val gazeShiftY = gazeY * rect.height * 0.0022f
    val leftEyeCenter = Offset(rect.left + rect.width * 0.427f + gazeShiftX, rect.top + rect.height * 0.0815f + gazeShiftY)
    val rightEyeCenter = Offset(rect.left + rect.width * 0.514f + gazeShiftX, rect.top + rect.height * 0.0768f + gazeShiftY)
    val eyeW = rect.width * 0.036f
    val eyeH = rect.height * 0.0085f

    val effectiveBlink = when {
        isSleepMode || directive.blinkMode == BlinkMode.SLEEPING -> maxOf(blinkAmount, 0.72f)
        directive.blinkMode == BlinkMode.WIDE_ALERT -> blinkAmount * 0.5f
        else -> blinkAmount
    }

    // 1. Eyelids & Directional Gaze Glint
    if (effectiveBlink > 0.04f) {
        listOf(leftEyeCenter, rightEyeCenter).forEach { eye ->
            val lidHeight = eyeH * effectiveBlink * 1.15f
            drawOval(
                color = skinTone,
                topLeft = Offset(eye.x - eyeW * 0.6f, eye.y - eyeH * 0.62f),
                size = Size(eyeW * 1.2f, lidHeight)
            )
            val lashY = eye.y - eyeH * 0.62f + lidHeight
            drawLine(
                color = lashColor,
                start = Offset(eye.x - eyeW * 0.55f, lashY),
                end = Offset(eye.x + eyeW * 0.55f, lashY),
                strokeWidth = 2.4f,
                cap = StrokeCap.Round
            )
        }
    } else if (abs(gazeX) > 0.12f || abs(gazeY) > 0.12f || directive.emotion == CompanionEmotion.EXCITED) {
        drawCircle(
            color = accent.copy(alpha = 0.34f),
            radius = 2.1f,
            center = leftEyeCenter
        )
        drawCircle(
            color = accent.copy(alpha = 0.34f),
            radius = 2.1f,
            center = rightEyeCenter
        )
    }

    // 2. Eyebrows matched to emotional state
    when (directive.browStyle) {
        BrowStyle.FURROWED -> {
            drawLine(
                color = lashColor,
                start = Offset(leftEyeCenter.x - eyeW * 0.6f, leftEyeCenter.y - eyeH * 1.12f),
                end = Offset(leftEyeCenter.x + eyeW * 0.55f, leftEyeCenter.y - eyeH * 0.65f),
                strokeWidth = 2.8f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = lashColor,
                start = Offset(rightEyeCenter.x - eyeW * 0.55f, rightEyeCenter.y - eyeH * 0.65f),
                end = Offset(rightEyeCenter.x + eyeW * 0.6f, rightEyeCenter.y - eyeH * 1.12f),
                strokeWidth = 2.8f,
                cap = StrokeCap.Round
            )
        }
        BrowStyle.SMIRK_ARCH -> {
            drawLine(
                color = lashColor,
                start = Offset(leftEyeCenter.x - eyeW * 0.55f, leftEyeCenter.y - eyeH * 0.9f),
                end = Offset(leftEyeCenter.x + eyeW * 0.5f, leftEyeCenter.y - eyeH * 0.9f),
                strokeWidth = 2.2f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = lashColor,
                start = Offset(rightEyeCenter.x - eyeW * 0.5f, rightEyeCenter.y - eyeH * 0.95f),
                end = Offset(rightEyeCenter.x + eyeW * 0.58f, rightEyeCenter.y - eyeH * 1.32f),
                strokeWidth = 2.4f,
                cap = StrokeCap.Round
            )
        }
        BrowStyle.CARING_SOFT -> {
            drawLine(
                color = lashColor.copy(alpha = 0.85f),
                start = Offset(leftEyeCenter.x - eyeW * 0.55f, leftEyeCenter.y - eyeH * 0.72f),
                end = Offset(leftEyeCenter.x + eyeW * 0.5f, leftEyeCenter.y - eyeH * 1.12f),
                strokeWidth = 2.3f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = lashColor.copy(alpha = 0.85f),
                start = Offset(rightEyeCenter.x - eyeW * 0.5f, rightEyeCenter.y - eyeH * 1.12f),
                end = Offset(rightEyeCenter.x + eyeW * 0.55f, rightEyeCenter.y - eyeH * 0.72f),
                strokeWidth = 2.3f,
                cap = StrokeCap.Round
            )
        }
        BrowStyle.RAISED -> {
            drawLine(
                color = lashColor.copy(alpha = 0.8f),
                start = Offset(leftEyeCenter.x - eyeW * 0.5f, leftEyeCenter.y - eyeH * 1.25f),
                end = Offset(leftEyeCenter.x + eyeW * 0.5f, leftEyeCenter.y - eyeH * 1.28f),
                strokeWidth = 2.1f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = lashColor.copy(alpha = 0.8f),
                start = Offset(rightEyeCenter.x - eyeW * 0.5f, rightEyeCenter.y - eyeH * 1.28f),
                end = Offset(rightEyeCenter.x + eyeW * 0.5f, rightEyeCenter.y - eyeH * 1.25f),
                strokeWidth = 2.1f,
                cap = StrokeCap.Round
            )
        }
        BrowStyle.HEAVY_SLEEPY, BrowStyle.NEUTRAL -> Unit
    }

    // 3. Soft cheek blush (Embarrassed, Happy, Excited, Caring)
    if (blushAlpha > 0.01f) {
        val blushColor = Color(0xFFFCA5A5).copy(alpha = blushAlpha)
        drawCircle(
            color = blushColor,
            radius = rect.width * 0.026f,
            center = Offset(rect.left + rect.width * 0.415f, rect.top + rect.height * 0.091f)
        )
        drawCircle(
            color = blushColor,
            radius = rect.width * 0.026f,
            center = Offset(rect.left + rect.width * 0.522f, rect.top + rect.height * 0.088f)
        )
    }

    // 4. Synchronized Anime Mouth Rig (aligned to pixel-measured 0.483, 0.1125 on 1164x3428 PNG)
    val mouthCenter = Offset(rect.left + rect.width * 0.483f, rect.top + rect.height * 0.1125f)
    val mouthW = rect.width * 0.026f
    val mouthH = rect.height * 0.0065f

    val shouldAnimateMouth = directive.mouthStyle != MouthStyle.NEUTRAL || mouthOpenness > 0.03f
    if (shouldAnimateMouth) {
        // Subtle skin-matched micro-patch over resting mouth line
        drawOval(
            color = skinTone,
            topLeft = Offset(mouthCenter.x - mouthW * 0.65f, mouthCenter.y - mouthH * 0.65f),
            size = Size(mouthW * 1.3f, mouthH * 1.45f)
        )

        when {
            mouthOpenness > 0.05f -> {
                val openH = (mouthH * (0.45f + mouthOpenness * 1.15f)).coerceAtLeast(2.2f)
                val openW = mouthW * (0.62f + (1f - mouthOpenness * 0.25f) * 0.28f)
                drawOval(
                    color = mouthInteriorColor,
                    topLeft = Offset(mouthCenter.x - openW * 0.5f, mouthCenter.y - openH * 0.35f),
                    size = Size(openW, openH)
                )
                drawOval(
                    color = mouthStrokeColor,
                    topLeft = Offset(mouthCenter.x - openW * 0.5f, mouthCenter.y - openH * 0.35f),
                    size = Size(openW, openH),
                    style = Stroke(width = 1.6f)
                )
                // Slight upper tooth/highlight when mouth opens wide
                if (mouthOpenness > 0.5f) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.65f),
                        start = Offset(mouthCenter.x - openW * 0.25f, mouthCenter.y - openH * 0.12f),
                        end = Offset(mouthCenter.x + openW * 0.25f, mouthCenter.y - openH * 0.12f),
                        strokeWidth = 1.4f,
                        cap = StrokeCap.Round
                    )
                }
            }
            directive.mouthStyle == MouthStyle.SMILE -> {
                drawPath(
                    path = Path().apply {
                        moveTo(mouthCenter.x - mouthW * 0.45f, mouthCenter.y - mouthH * 0.15f)
                        quadraticTo(mouthCenter.x, mouthCenter.y + mouthH * 0.48f, mouthCenter.x + mouthW * 0.45f, mouthCenter.y - mouthH * 0.22f)
                    },
                    color = mouthStrokeColor,
                    style = Stroke(width = 2.0f, cap = StrokeCap.Round)
                )
            }
            directive.mouthStyle == MouthStyle.SMIRK -> {
                drawPath(
                    path = Path().apply {
                        moveTo(mouthCenter.x - mouthW * 0.38f, mouthCenter.y + mouthH * 0.05f)
                        quadraticTo(mouthCenter.x + mouthW * 0.08f, mouthCenter.y + mouthH * 0.22f, mouthCenter.x + mouthW * 0.46f, mouthCenter.y - mouthH * 0.35f)
                    },
                    color = mouthStrokeColor,
                    style = Stroke(width = 2.0f, cap = StrokeCap.Round)
                )
            }
            directive.mouthStyle == MouthStyle.FROWN -> {
                drawPath(
                    path = Path().apply {
                        moveTo(mouthCenter.x - mouthW * 0.4f, mouthCenter.y + mouthH * 0.25f)
                        quadraticTo(mouthCenter.x, mouthCenter.y - mouthH * 0.28f, mouthCenter.x + mouthW * 0.4f, mouthCenter.y + mouthH * 0.25f)
                    },
                    color = mouthStrokeColor,
                    style = Stroke(width = 1.9f, cap = StrokeCap.Round)
                )
            }
            else -> {
                drawLine(
                    color = mouthStrokeColor,
                    start = Offset(mouthCenter.x - mouthW * 0.36f, mouthCenter.y),
                    end = Offset(mouthCenter.x + mouthW * 0.36f, mouthCenter.y),
                    strokeWidth = 1.8f,
                    cap = StrokeCap.Round
                )
            }
        }
    }

    // 5. Contextual Anime Emotion / Situation Effect Glyphs
    when (directive.effectOverlay) {
        StageEffectOverlay.GREETING_SPARK, StageEffectOverlay.EXCITED_BURST -> {
            val glintOffset = sin(energyPhase * 2f * PI).toFloat() * 4f
            val base = Offset(rect.left + rect.width * 0.64f, rect.top + rect.height * 0.046f + glintOffset)
            drawLine(accent.copy(alpha = 0.85f), Offset(base.x - 6f, base.y), Offset(base.x + 6f, base.y), strokeWidth = 2.0f, cap = StrokeCap.Round)
            drawLine(accent.copy(alpha = 0.85f), Offset(base.x, base.y - 6f), Offset(base.x, base.y + 6f), strokeWidth = 2.0f, cap = StrokeCap.Round)
        }
        StageEffectOverlay.JOKING_GLINT -> {
            val pt = Offset(rect.left + rect.width * 0.62f, rect.top + rect.height * 0.055f)
            drawCircle(color = accent.copy(alpha = 0.72f), radius = 3.2f, center = pt)
        }
        StageEffectOverlay.THINKING_DOTS -> {
            val bx = rect.left + rect.width * 0.61f
            val by = rect.top + rect.height * 0.052f
            for (i in 0..2) {
                val pulse = ((energyPhase * 3f - i * 0.28f) % 1f).let { if (it < 0f) it + 1f else it }
                val alpha = 0.35f + sin(pulse * PI).toFloat() * 0.55f
                drawCircle(
                    color = accent.copy(alpha = alpha),
                    radius = 2.2f + i * 0.9f,
                    center = Offset(bx + i * 7f, by - i * 6f)
                )
            }
        }
        StageEffectOverlay.EMBARRASSED_SWEAT -> {
            val sx = rect.left + rect.width * 0.38f
            val sy = rect.top + rect.height * 0.072f + sin(energyPhase * 2f * PI).toFloat() * 2f
            val dropPath = Path().apply {
                moveTo(sx, sy - 6f)
                quadraticTo(sx + 5f, sy + 2f, sx, sy + 6f)
                quadraticTo(sx - 5f, sy + 2f, sx, sy - 6f)
            }
            drawPath(path = dropPath, color = NexusColors.CyanSoft.copy(alpha = 0.85f))
        }
        StageEffectOverlay.ANGER_VEIN -> {
            val markCenter = Offset(rect.left + rect.width * 0.62f, rect.top + rect.height * 0.040f)
            val s = 9f
            val markColor = NexusColors.CoralAlert.copy(alpha = 0.9f)
            drawPath(
                path = Path().apply {
                    moveTo(markCenter.x - s, markCenter.y - 2f)
                    quadraticTo(markCenter.x - 2f, markCenter.y - 2f, markCenter.x - 2f, markCenter.y - s)
                    moveTo(markCenter.x + s, markCenter.y - 2f)
                    quadraticTo(markCenter.x + 2f, markCenter.y - 2f, markCenter.x + 2f, markCenter.y - s)
                    moveTo(markCenter.x - s, markCenter.y + 4f)
                    quadraticTo(markCenter.x - 2f, markCenter.y + 4f, markCenter.x - 2f, markCenter.y + s + 2f)
                    moveTo(markCenter.x + s, markCenter.y + 4f)
                    quadraticTo(markCenter.x + 2f, markCenter.y + 4f, markCenter.x + 2f, markCenter.y + s + 2f)
                },
                color = markColor,
                style = Stroke(width = 2.2f, cap = StrokeCap.Round)
            )
        }
        StageEffectOverlay.SURPRISED_MARK -> {
            val exX = rect.left + rect.width * 0.63f
            val exY = rect.top + rect.height * 0.036f
            drawLine(
                color = accent,
                start = Offset(exX, exY - 12f),
                end = Offset(exX, exY + 2f),
                strokeWidth = 3.2f,
                cap = StrokeCap.Round
            )
            drawCircle(
                color = accent,
                radius = 2.2f,
                center = Offset(exX, exY + 8f)
            )
        }
        StageEffectOverlay.SAD_DROP -> {
            val bx = rect.left + rect.width * 0.37f
            val by = rect.top + rect.height * 0.068f
            drawCircle(
                color = NexusColors.SleepSlate.copy(alpha = 0.6f),
                radius = 2.8f,
                center = Offset(bx, by)
            )
        }
        StageEffectOverlay.CARING_AURA -> {
            val auraCenter = Offset(rect.left + rect.width * 0.48f, rect.top + rect.height * 0.09f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NexusColors.MintEnergy.copy(alpha = 0.12f), Color.Transparent),
                    center = auraCenter,
                    radius = rect.width * 0.38f
                ),
                radius = rect.width * 0.38f,
                center = auraCenter
            )
        }
        StageEffectOverlay.SLEEP_ZZZ -> {
            val baseX = rect.left + rect.width * 0.62f
            val baseY = rect.top + rect.height * 0.048f
            for (i in 0 until 3) {
                val t = (energyPhase + i * 0.33f) % 1f
                val driftY = t * 28f
                val driftX = sin(t * 2f * PI).toFloat() * 4f + i * 7f
                val alpha = (1f - t) * 0.75f
                drawSleepGlyphZ(
                    center = Offset(baseX + driftX, baseY - driftY),
                    glyphSize = 8f + i * 2.5f,
                    color = NexusColors.SleepSlate.copy(alpha = alpha)
                )
            }
        }
        StageEffectOverlay.NONE -> Unit
    }
}

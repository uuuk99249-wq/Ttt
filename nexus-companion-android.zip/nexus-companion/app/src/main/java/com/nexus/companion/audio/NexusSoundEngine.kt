package com.nexus.companion.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class NexusSoundEngine(context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile
    var enabled: Boolean = true

    fun playTap() {
        playTone(startHz = 860f, endHz = 1120f, durationMs = 45, peak = 0.14f)
    }

    fun playAnnoyed() {
        playTone(startHz = 420f, endHz = 260f, durationMs = 95, peak = 0.16f)
    }

    fun playSurprised() {
        playTone(startHz = 620f, endHz = 1380f, durationMs = 85, peak = 0.15f)
    }

    fun playModeSwitch() {
        scope.launch {
            playToneSync(startHz = 520f, endHz = 780f, durationMs = 55, peak = 0.14f)
            playToneSync(startHz = 780f, endHz = 1040f, durationMs = 70, peak = 0.12f)
        }
    }

    fun playTimerChime() {
        scope.launch {
            playToneSync(startHz = 740f, endHz = 740f, durationMs = 80, peak = 0.16f)
            playToneSync(startHz = 987f, endHz = 1175f, durationMs = 140, peak = 0.16f)
        }
    }

    private fun canPlay(): Boolean {
        if (!enabled) return false
        val mode = audioManager?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL
        return mode == AudioManager.RINGER_MODE_NORMAL
    }

    private fun playTone(startHz: Float, endHz: Float, durationMs: Int, peak: Float) {
        if (!canPlay()) return
        scope.launch {
            playToneSync(startHz, endHz, durationMs, peak)
        }
    }

    private fun playToneSync(startHz: Float, endHz: Float, durationMs: Int, peak: Float) {
        if (!canPlay()) return
        val sampleRate = 22050
        val count = (sampleRate * durationMs) / 1000
        if (count <= 0) return

        val samples = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val t = i.toFloat() / count.toFloat()
            val freq = startHz + (endHz - startHz) * t
            val envelope = when {
                t < 0.12f -> t / 0.12f
                t > 0.72f -> (1f - t) / 0.28f
                else -> 1f
            }.coerceIn(0f, 1f)
            phase += 2.0 * PI * freq / sampleRate
            val sampleValue = sin(phase) * envelope * peak * Short.MAX_VALUE
            samples[i] = sampleValue.toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }

        var track: AudioTrack? = null
        try {
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 18L)
        } catch (_: Throwable) {
            // Safe ignore if device audio session is unavailable
        } finally {
            try {
                track?.stop()
                track?.release()
            } catch (_: Throwable) {
            }
        }
    }

    fun release() {
        scope.cancel()
    }
}

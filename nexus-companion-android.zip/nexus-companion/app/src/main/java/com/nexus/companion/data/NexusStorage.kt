package com.nexus.companion.data

import android.content.Context
import android.content.SharedPreferences
import com.nexus.companion.model.AnimationIntensity
import com.nexus.companion.model.BackgroundTheme
import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CharacterMood
import com.nexus.companion.model.ChatMessage
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionMemory
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.model.MessageRole
import com.nexus.companion.model.PersonalitySettings
import com.nexus.companion.model.ReplySource
import com.nexus.companion.model.ResponseStyle
import com.nexus.companion.model.SavedLocation
import com.nexus.companion.model.TemperatureUnit
import com.nexus.companion.model.WeatherConditionCategory
import com.nexus.companion.model.WeatherLocationMode
import com.nexus.companion.model.WeatherSnapshot
import org.json.JSONArray
import org.json.JSONObject

class NexusStorage(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSettings(): CustomizationSettings {
        val bgName = prefs.getString(KEY_BACKGROUND, BackgroundTheme.OBSIDIAN_GRID.name)
        val animName = prefs.getString(KEY_ANIM_INTENSITY, AnimationIntensity.BALANCED.name)
        val exprName = prefs.getString(KEY_PINNED_EXPRESSION, null)
        val styleName = prefs.getString(KEY_RESPONSE_STYLE, ResponseStyle.BALANCED.name)

        return CustomizationSettings(
            offsetXFraction = prefs.getFloat(KEY_OFFSET_X, 0f).coerceIn(-0.25f, 0.25f),
            offsetYFraction = prefs.getFloat(KEY_OFFSET_Y, 0.02f).coerceIn(-0.20f, 0.20f),
            scale = prefs.getFloat(KEY_SCALE, 1.0f).coerceIn(0.75f, 1.35f),
            backgroundTheme = BackgroundTheme.entries.firstOrNull { it.name == bgName }
                ?: BackgroundTheme.OBSIDIAN_GRID,
            sfxEnabled = prefs.getBoolean(KEY_SFX_ENABLED, true),
            animationIntensity = AnimationIntensity.entries.firstOrNull { it.name == animName }
                ?: AnimationIntensity.BALANCED,
            pinnedExpression = exprName?.let { name ->
                CharacterExpression.entries.firstOrNull { it.name == name }
            },
            batterySaverThrottle = prefs.getBoolean(KEY_BATTERY_THROTTLE, true),
            timerAlertsEnabled = prefs.getBoolean(KEY_TIMER_ALERTS, true),
            personality = PersonalitySettings(
                sarcasmLevel = prefs.getInt(KEY_SARCASM_LEVEL, 65).coerceIn(0, 100),
                responseStyle = ResponseStyle.entries.firstOrNull { it.name == styleName }
                    ?: ResponseStyle.BALANCED,
                autoModeSwitching = prefs.getBoolean(KEY_AUTO_MODE_SWITCH, true),
                voiceOutputEnabled = prefs.getBoolean(KEY_VOICE_OUTPUT, false),
                voiceConversationMode = prefs.getBoolean(KEY_VOICE_CONVERSATION, false)
            )
        )
    }

    fun saveSettings(settings: CustomizationSettings) {
        prefs.edit()
            .putFloat(KEY_OFFSET_X, settings.offsetXFraction)
            .putFloat(KEY_OFFSET_Y, settings.offsetYFraction)
            .putFloat(KEY_SCALE, settings.scale)
            .putString(KEY_BACKGROUND, settings.backgroundTheme.name)
            .putBoolean(KEY_SFX_ENABLED, settings.sfxEnabled)
            .putString(KEY_ANIM_INTENSITY, settings.animationIntensity.name)
            .putString(KEY_PINNED_EXPRESSION, settings.pinnedExpression?.name)
            .putBoolean(KEY_BATTERY_THROTTLE, settings.batterySaverThrottle)
            .putBoolean(KEY_TIMER_ALERTS, settings.timerAlertsEnabled)
            .putInt(KEY_SARCASM_LEVEL, settings.personality.sarcasmLevel)
            .putString(KEY_RESPONSE_STYLE, settings.personality.responseStyle.name)
            .putBoolean(KEY_AUTO_MODE_SWITCH, settings.personality.autoModeSwitching)
            .putBoolean(KEY_VOICE_OUTPUT, settings.personality.voiceOutputEnabled)
            .putBoolean(KEY_VOICE_CONVERSATION, settings.personality.voiceConversationMode)
            .apply()
    }

    fun loadLastMode(): CharacterMode {
        val raw = prefs.getString(KEY_LAST_MODE, CharacterMode.NORMAL.name)
        return CharacterMode.entries.firstOrNull { it.name == raw } ?: CharacterMode.NORMAL
    }

    fun saveLastMode(mode: CharacterMode) {
        prefs.edit().putString(KEY_LAST_MODE, mode.name).apply()
    }

    fun loadMood(): CharacterMood {
        val raw = prefs.getString(KEY_MOOD, CharacterMood.NEUTRAL.name)
        return CharacterMood.entries.firstOrNull { it.name == raw } ?: CharacterMood.NEUTRAL
    }

    fun saveMood(mood: CharacterMood) {
        prefs.edit().putString(KEY_MOOD, mood.name).apply()
    }

    fun loadTimerGoalMinutes(): Int {
        return prefs.getInt(KEY_TIMER_GOAL_MIN, 45).coerceIn(15, 180)
    }

    fun saveTimerGoalMinutes(minutes: Int) {
        prefs.edit().putInt(KEY_TIMER_GOAL_MIN, minutes.coerceIn(15, 180)).apply()
    }

    fun loadAiServerUrl(): String {
        return prefs.getString(KEY_AI_SERVER_URL, "")?.trim().orEmpty()
    }

    fun saveAiServerUrl(url: String) {
        prefs.edit().putString(KEY_AI_SERVER_URL, url.trim()).apply()
    }

    fun loadChatHistory(): List<ChatMessage> {
        val raw = prefs.getString(KEY_CHAT_HISTORY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val role = MessageRole.entries.firstOrNull { it.name == obj.optString("role") }
                        ?: MessageRole.NEXUS
                    val source = ReplySource.entries.firstOrNull { it.name == obj.optString("source") }
                        ?: ReplySource.LOCAL_OFFLINE
                    val expr = CharacterExpression.entries.firstOrNull {
                        it.name == obj.optString("expression")
                    } ?: CharacterExpression.NEUTRAL
                    val emotion = CompanionEmotion.entries.firstOrNull {
                        it.name == obj.optString("emotion")
                    } ?: CompanionEmotion.NEUTRAL
                    add(
                        ChatMessage(
                            id = obj.optLong("id", System.currentTimeMillis() + i),
                            role = role,
                            text = obj.optString("text", ""),
                            timestampMs = obj.optLong("timestampMs", System.currentTimeMillis()),
                            source = source,
                            expression = expr,
                            emotion = emotion,
                            isError = obj.optBoolean("isError", false)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveChatHistory(messages: List<ChatMessage>) {
        val trimmed = messages.takeLast(120)
        val array = JSONArray()
        trimmed.forEach { msg ->
            array.put(
                JSONObject().apply {
                    put("id", msg.id)
                    put("role", msg.role.name)
                    put("text", msg.text)
                    put("timestampMs", msg.timestampMs)
                    put("source", msg.source.name)
                    put("expression", msg.expression.name)
                    put("emotion", msg.emotion.name)
                    put("isError", msg.isError)
                }
            )
        }
        prefs.edit().putString(KEY_CHAT_HISTORY, array.toString()).apply()
    }

    fun clearChatHistory() {
        prefs.edit().remove(KEY_CHAT_HISTORY).apply()
    }

    fun loadMemory(): CompanionMemory {
        val raw = prefs.getString(KEY_COMPANION_MEMORY, null) ?: return CompanionMemory()
        return try {
            val obj = JSONObject(raw)
            fun readList(key: String): List<String> {
                val arr = obj.optJSONArray(key) ?: return emptyList()
                return buildList {
                    for (i in 0 until arr.length()) {
                        val item = arr.optString(i).trim()
                        if (item.isNotEmpty()) add(item)
                    }
                }
            }
            CompanionMemory(
                enabled = obj.optBoolean("enabled", true),
                preferredName = obj.optString("preferredName", "").trim(),
                interests = readList("interests"),
                preferences = readList("preferences"),
                facts = readList("facts"),
                conversationSummary = obj.optString("conversationSummary", "").trim()
            )
        } catch (_: Exception) {
            CompanionMemory()
        }
    }

    fun saveMemory(memory: CompanionMemory) {
        val obj = JSONObject().apply {
            put("enabled", memory.enabled)
            put("preferredName", memory.preferredName.trim())
            put("interests", JSONArray(memory.interests))
            put("preferences", JSONArray(memory.preferences))
            put("facts", JSONArray(memory.facts))
            put("conversationSummary", memory.conversationSummary.trim())
        }
        prefs.edit().putString(KEY_COMPANION_MEMORY, obj.toString()).apply()
    }

    fun clearMemory() {
        val currentEnabled = loadMemory().enabled
        saveMemory(CompanionMemory(enabled = currentEnabled))
    }

    fun loadTemperatureUnit(): TemperatureUnit {
        val raw = prefs.getString(KEY_WEATHER_UNIT, TemperatureUnit.CELSIUS.name)
        return TemperatureUnit.entries.firstOrNull { it.name == raw } ?: TemperatureUnit.CELSIUS
    }

    fun saveTemperatureUnit(unit: TemperatureUnit) {
        prefs.edit().putString(KEY_WEATHER_UNIT, unit.name).apply()
    }

    fun loadSavedLocation(): SavedLocation {
        val raw = prefs.getString(KEY_SAVED_LOCATION, null) ?: return SavedLocation()
        return try {
            val obj = JSONObject(raw)
            val mode = WeatherLocationMode.entries.firstOrNull { it.name == obj.optString("mode") }
                ?: WeatherLocationMode.MANUAL_CITY
            val lat = if (obj.has("latitude") && !obj.isNull("latitude")) obj.optDouble("latitude") else null
            val lon = if (obj.has("longitude") && !obj.isNull("longitude")) obj.optDouble("longitude") else null
            SavedLocation(
                mode = mode,
                name = obj.optString("name", "").trim(),
                region = obj.optString("region", "").trim(),
                country = obj.optString("country", "").trim(),
                latitude = lat?.takeUnless { it.isNaN() },
                longitude = lon?.takeUnless { it.isNaN() }
            )
        } catch (_: Exception) {
            SavedLocation()
        }
    }

    fun saveSavedLocation(location: SavedLocation) {
        val obj = JSONObject().apply {
            put("mode", location.mode.name)
            put("name", location.name)
            put("region", location.region)
            put("country", location.country)
            if (location.latitude != null && location.longitude != null) {
                put("latitude", location.latitude)
                put("longitude", location.longitude)
            }
        }
        prefs.edit().putString(KEY_SAVED_LOCATION, obj.toString()).apply()
    }

    fun loadCachedWeather(): WeatherSnapshot? {
        val raw = prefs.getString(KEY_CACHED_WEATHER, null) ?: return null
        return try {
            val obj = JSONObject(raw)
            val cat = WeatherConditionCategory.entries.firstOrNull { it.name == obj.optString("conditionCategory") }
                ?: WeatherConditionCategory.CLOUDY
            val temp = obj.optDouble("temperatureCelsius", Double.NaN)
            if (temp.isNaN()) return null
            WeatherSnapshot(
                locationName = obj.optString("locationName", "Saved Location"),
                temperatureCelsius = temp,
                relativeHumidityPercent = obj.optInt("relativeHumidityPercent", 0),
                windSpeedKmh = obj.optDouble("windSpeedKmh", 0.0),
                precipitationMm = obj.optDouble("precipitationMm", 0.0),
                weatherCode = obj.optInt("weatherCode", 0),
                conditionCategory = cat,
                conditionLabel = obj.optString("conditionLabel", cat.label),
                fetchedAtMs = obj.optLong("fetchedAtMs", System.currentTimeMillis()),
                isFromCache = true
            )
        } catch (_: Exception) {
            null
        }
    }

    fun saveCachedWeather(snapshot: WeatherSnapshot) {
        val obj = JSONObject().apply {
            put("locationName", snapshot.locationName)
            put("temperatureCelsius", snapshot.temperatureCelsius)
            put("relativeHumidityPercent", snapshot.relativeHumidityPercent)
            put("windSpeedKmh", snapshot.windSpeedKmh)
            put("precipitationMm", snapshot.precipitationMm)
            put("weatherCode", snapshot.weatherCode)
            put("conditionCategory", snapshot.conditionCategory.name)
            put("conditionLabel", snapshot.conditionLabel)
            put("fetchedAtMs", snapshot.fetchedAtMs)
        }
        prefs.edit().putString(KEY_CACHED_WEATHER, obj.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "nexus_companion_prefs"
        private const val KEY_OFFSET_X = "offset_x"
        private const val KEY_OFFSET_Y = "offset_y"
        private const val KEY_SCALE = "scale"
        private const val KEY_BACKGROUND = "background_theme"
        private const val KEY_SFX_ENABLED = "sfx_enabled"
        private const val KEY_ANIM_INTENSITY = "anim_intensity"
        private const val KEY_PINNED_EXPRESSION = "pinned_expression"
        private const val KEY_BATTERY_THROTTLE = "battery_throttle"
        private const val KEY_TIMER_ALERTS = "timer_alerts"
        private const val KEY_SARCASM_LEVEL = "sarcasm_level"
        private const val KEY_RESPONSE_STYLE = "response_style"
        private const val KEY_AUTO_MODE_SWITCH = "auto_mode_switch"
        private const val KEY_VOICE_OUTPUT = "voice_output"
        private const val KEY_VOICE_CONVERSATION = "voice_conversation_mode"
        private const val KEY_LAST_MODE = "last_mode"
        private const val KEY_MOOD = "character_mood"
        private const val KEY_TIMER_GOAL_MIN = "timer_goal_minutes"
        private const val KEY_AI_SERVER_URL = "ai_server_url"
        private const val KEY_CHAT_HISTORY = "chat_history"
        private const val KEY_COMPANION_MEMORY = "companion_memory"
        private const val KEY_WEATHER_UNIT = "weather_temperature_unit"
        private const val KEY_SAVED_LOCATION = "weather_saved_location"
        private const val KEY_CACHED_WEATHER = "weather_cached_snapshot"
    }
}

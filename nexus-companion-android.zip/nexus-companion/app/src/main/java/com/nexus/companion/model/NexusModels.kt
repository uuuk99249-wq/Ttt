package com.nexus.companion.model

import android.graphics.drawable.Drawable
import java.util.Locale

enum class NexusTab(val label: String) {
    HOME("Home"),
    CHAT("Chat"),
    CUSTOMIZE("Customize"),
    SETTINGS("Settings")
}

enum class CharacterMode(
    val label: String,
    val tagline: String
) {
    NORMAL("Normal", "Standby · Cool & observant"),
    GAMING("Gaming", "Focused · Timer & quick launch"),
    CHARGING("Charging", "Plugged in · Core recharging"),
    SLEEP("Sleep", "Low power · Rest mode"),
    CONVERSATION("Conversation", "Attentive · Ready to talk")
}

enum class CharacterExpression(val label: String) {
    NEUTRAL("Neutral"),
    HAPPY("Happy"),
    ANNOYED("Annoyed"),
    SURPRISED("Surprised"),
    SLEEPY("Sleepy")
}

enum class CharacterMood(
    val label: String,
    val defaultExpression: CharacterExpression
) {
    HAPPY("Happy", CharacterExpression.HAPPY),
    NEUTRAL("Neutral", CharacterExpression.NEUTRAL),
    ANNOYED("Annoyed", CharacterExpression.ANNOYED),
    SLEEPY("Sleepy", CharacterExpression.SLEEPY),
    PLAYFUL("Playful", CharacterExpression.HAPPY)
}

enum class CompanionEmotion(
    val label: String,
    val baseExpression: CharacterExpression
) {
    NEUTRAL("Neutral", CharacterExpression.NEUTRAL),
    HAPPY("Happy", CharacterExpression.HAPPY),
    PLAYFUL("Playful", CharacterExpression.HAPPY),
    SARCASTIC("Sarcastic", CharacterExpression.ANNOYED),
    ANGRY("Angry", CharacterExpression.ANNOYED),
    EMBARRASSED("Embarrassed", CharacterExpression.SURPRISED),
    SAD("Sad", CharacterExpression.NEUTRAL),
    SURPRISED("Surprised", CharacterExpression.SURPRISED),
    THINKING("Thinking", CharacterExpression.NEUTRAL),
    SLEEPY("Sleepy", CharacterExpression.SLEEPY),
    EXCITED("Excited", CharacterExpression.HAPPY),
    CARING("Caring", CharacterExpression.HAPPY)
}

enum class CompanionSituation(val label: String) {
    IDLE("Idle"),
    GREETING("Greeting"),
    JOKING("Joking"),
    THINKING("Thinking"),
    CHATTING("Chatting"),
    ADVICE("Advice"),
    GAMING("Gaming"),
    LISTENING("Listening"),
    SPEAKING("Speaking"),
    CHARGING("Charging"),
    SLEEPING("Sleeping")
}

enum class CharacterPoseKey(val drawableResourceName: String) {
    DEFAULT_STANDING("nexus_character"),
    GREETING_WAVE("nexus_pose_greeting"),
    JOKING_SMIRK("nexus_pose_joking"),
    THINKING_CHIN("nexus_pose_thinking"),
    EMBARRASSED_SCRATCH("nexus_pose_embarrassed"),
    ANNOYED_ARMS_CROSSED("nexus_pose_annoyed"),
    HAPPY_CHEERFUL("nexus_pose_happy"),
    SLEEPY_YAWN("nexus_pose_sleepy"),
    LISTENING_ATTENTIVE("nexus_pose_listening"),
    GAMING_FOCUSED("nexus_pose_gaming")
}

enum class BackgroundTheme(val label: String, val subtitle: String) {
    OBSIDIAN_GRID("Obsidian Grid", "Deep black with subtle cyan gridlines"),
    CHARCOAL_HORIZON("Charcoal Horizon", "Matte charcoal radial aura"),
    CYAN_CIRCUIT("Cyan Circuit", "Minimalist electric cyan traces"),
    STEALTH_MINIMAL("Stealth Minimal", "Pure OLED black for battery saving")
}

enum class AnimationIntensity(val label: String, val multiplier: Float, val frameDelayMs: Long) {
    OFF("Off", 0f, 120L),
    LOW("Low", 0.45f, 45L),
    BALANCED("Balanced", 1.0f, 16L),
    HIGH("High", 1.45f, 16L)
}

enum class ResponseStyle(val label: String) {
    CONCISE("Concise"),
    BALANCED("Balanced"),
    BANTER("Playful Banter")
}

enum class CharacterTouchZone {
    HEAD,
    SHOULDER,
    TORSO,
    POCKETS,
    SNEAKERS
}

enum class MessageRole {
    USER,
    NEXUS
}

enum class ReplySource(val badge: String) {
    LIVE_AI("Live AI"),
    LOCAL_OFFLINE("Offline Local"),
    SYSTEM_NOTICE("System")
}

enum class MemoryCategory(val label: String) {
    INTERESTS("Interests"),
    PREFERENCES("Preferences"),
    FACTS("Facts & Notes")
}

data class CompanionMemory(
    val enabled: Boolean = true,
    val preferredName: String = "",
    val interests: List<String> = emptyList(),
    val preferences: List<String> = emptyList(),
    val facts: List<String> = emptyList(),
    val conversationSummary: String = ""
) {
    val totalCount: Int
        get() = (if (preferredName.isNotBlank()) 1 else 0) +
            interests.size + preferences.size + facts.size +
            (if (conversationSummary.isNotBlank()) 1 else 0)
}

data class PersonalitySettings(
    val sarcasmLevel: Int = 65, // 0..100
    val responseStyle: ResponseStyle = ResponseStyle.BALANCED,
    val autoModeSwitching: Boolean = true,
    val voiceOutputEnabled: Boolean = false,
    val voiceConversationMode: Boolean = false
)

data class CustomizationSettings(
    val offsetXFraction: Float = 0f,     // -0.25f .. 0.25f
    val offsetYFraction: Float = 0.02f,  // -0.20f .. 0.20f
    val scale: Float = 1.0f,             // 0.75f .. 1.35f
    val backgroundTheme: BackgroundTheme = BackgroundTheme.OBSIDIAN_GRID,
    val sfxEnabled: Boolean = true,
    val animationIntensity: AnimationIntensity = AnimationIntensity.BALANCED,
    val pinnedExpression: CharacterExpression? = null,
    val batterySaverThrottle: Boolean = true,
    val timerAlertsEnabled: Boolean = true,
    val personality: PersonalitySettings = PersonalitySettings()
)

data class ChatMessage(
    val id: Long,
    val role: MessageRole,
    val text: String,
    val timestampMs: Long,
    val source: ReplySource,
    val expression: CharacterExpression = CharacterExpression.NEUTRAL,
    val emotion: CompanionEmotion = CompanionEmotion.NEUTRAL,
    val isError: Boolean = false
)

data class DeviceTelemetry(
    val batteryPercent: Int = -1,
    val isCharging: Boolean = false,
    val chargingSource: String = "Unknown",
    val batteryTempCelsius: Float? = null,
    val isPowerSaveMode: Boolean = false,
    val formattedTime: String = "--:--",
    val formattedDate: String = "---"
)

data class LaunchableApp(
    val packageName: String,
    val label: String,
    val icon: Drawable?,
    val isGame: Boolean = false
)

data class GamingTimerState(
    val isRunning: Boolean = false,
    val elapsedSeconds: Long = 0L,
    val goalMinutes: Int = 45,
    val detectedGameLabel: String? = null
) {
    val formattedTime: String
        get() {
            val hours = elapsedSeconds / 3600
            val minutes = (elapsedSeconds % 3600) / 60
            val seconds = elapsedSeconds % 60
            return if (hours > 0) {
                String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }
}

data class NotificationSnapshot(
    val listenerConnected: Boolean = false,
    val activeCount: Int = 0,
    val latestApp: String? = null,
    val latestTitle: String? = null
)

data class PermissionSnapshot(
    val microphoneGranted: Boolean = false,
    val notificationsGranted: Boolean = true,
    val notificationListenerGranted: Boolean = false,
    val usageStatsGranted: Boolean = false,
    val locationGranted: Boolean = false
)

enum class TemperatureUnit(val symbol: String, val label: String) {
    CELSIUS("°C", "Celsius"),
    FAHRENHEIT("°F", "Fahrenheit")
}

enum class WeatherLocationMode(val label: String) {
    AUTO_DEVICE("Automatic"),
    MANUAL_CITY("Manual City")
}

enum class WeatherConditionCategory(val label: String) {
    CLEAR_SUNNY("Clear"),
    PARTLY_CLOUDY("Partly Cloudy"),
    CLOUDY("Cloudy"),
    FOGGY("Foggy"),
    RAINY("Rain"),
    SNOWY("Snow"),
    THUNDERSTORM("Thunderstorm")
}

data class SavedLocation(
    val mode: WeatherLocationMode = WeatherLocationMode.MANUAL_CITY,
    val name: String = "",
    val region: String = "",
    val country: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null
) {
    val hasCoordinates: Boolean
        get() = latitude != null && longitude != null

    val displayName: String
        get() = listOf(name, region, country)
            .filter { it.isNotBlank() }
            .distinct()
            .take(2)
            .joinToString(", ")
            .ifBlank { if (mode == WeatherLocationMode.AUTO_DEVICE) "Device Location" else "Location not set" }
}

data class GeocodingCityResult(
    val id: Long,
    val name: String,
    val admin1: String,
    val country: String,
    val latitude: Double,
    val longitude: Double
) {
    val displayLabel: String
        get() = listOf(name, admin1, country)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(", ")
}

data class WeatherSnapshot(
    val locationName: String,
    val temperatureCelsius: Double,
    val relativeHumidityPercent: Int,
    val windSpeedKmh: Double,
    val precipitationMm: Double,
    val weatherCode: Int,
    val conditionCategory: WeatherConditionCategory,
    val conditionLabel: String,
    val fetchedAtMs: Long,
    val isFromCache: Boolean = false
) {
    fun formatTemperature(unit: TemperatureUnit): String {
        val value = when (unit) {
            TemperatureUnit.CELSIUS -> temperatureCelsius
            TemperatureUnit.FAHRENHEIT -> (temperatureCelsius * 9.0 / 5.0) + 32.0
        }
        return "${kotlin.math.round(value).toInt()}${unit.symbol}"
    }

    fun formatWindSpeed(): String {
        return String.format(Locale.US, "%.0f km/h", windSpeedKmh)
    }

    fun formatUpdatedTime(): String {
        val formatter = java.text.SimpleDateFormat("HH:mm", Locale.getDefault())
        return formatter.format(java.util.Date(fetchedAtMs))
    }
}

data class WeatherState(
    val snapshot: WeatherSnapshot? = null,
    val savedLocation: SavedLocation = SavedLocation(),
    val temperatureUnit: TemperatureUnit = TemperatureUnit.CELSIUS,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val isOffline: Boolean = false
)


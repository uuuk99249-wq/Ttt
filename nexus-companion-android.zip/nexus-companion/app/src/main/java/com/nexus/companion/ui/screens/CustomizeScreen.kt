package com.nexus.companion.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.companion.model.AnimationIntensity
import com.nexus.companion.model.BackgroundTheme
import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.model.ResponseStyle
import com.nexus.companion.ui.components.NexusCharacterStage
import com.nexus.companion.ui.theme.NexusColors
import kotlin.math.roundToInt

@Composable
fun CustomizeScreen(
    mode: CharacterMode,
    expression: CharacterExpression,
    emotion: CompanionEmotion = CompanionEmotion.NEUTRAL,
    situation: CompanionSituation = CompanionSituation.IDLE,
    isSpeaking: Boolean = false,
    speechMouthLevel: Float = 0f,
    settings: CustomizationSettings,
    isPowerSaveMode: Boolean,
    onUpdateSettings: ((CustomizationSettings) -> CustomizationSettings) -> Unit,
    onPreviewEmotion: (CompanionEmotion) -> Unit = {},
    onTestVoiceEmotion: (CompanionEmotion) -> Unit = {},
    onResetPosition: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusColors.Obsidian)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Customize NEXUS",
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            color = NexusColors.TextPrimary
        )

        // Live preview card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(NexusColors.Charcoal)
        ) {
            NexusCharacterStage(
                mode = mode,
                expression = settings.pinnedExpression ?: expression,
                settings = settings,
                isPowerSaveMode = isPowerSaveMode,
                isSpeakingOrListening = isSpeaking,
                touchPulseNonce = 0,
                onCharacterTap = {},
                emotion = emotion,
                situation = situation,
                isSpeaking = isSpeaking,
                speechMouthLevel = speechMouthLevel,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Character Size & Position
        SectionCard(title = "Position & Size") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Scale: ${(settings.scale * 100).roundToInt()}%",
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NexusColors.TextSecondary
                )
                TextButton(onClick = onResetPosition) {
                    Text("Reset", color = NexusColors.CyanElectric, fontSize = 13.sp)
                }
            }
            Slider(
                value = settings.scale,
                onValueChange = { value -> onUpdateSettings { it.copy(scale = value) } },
                valueRange = 0.75f..1.35f,
                colors = SliderDefaults.colors(
                    thumbColor = NexusColors.CyanElectric,
                    activeTrackColor = NexusColors.CyanElectric
                )
            )

            Text(
                text = "Horizontal Offset: ${(settings.offsetXFraction * 100).roundToInt()}%",
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                color = NexusColors.TextSecondary
            )
            Slider(
                value = settings.offsetXFraction,
                onValueChange = { value -> onUpdateSettings { it.copy(offsetXFraction = value) } },
                valueRange = -0.25f..0.25f,
                colors = SliderDefaults.colors(
                    thumbColor = NexusColors.CyanElectric,
                    activeTrackColor = NexusColors.CyanElectric
                )
            )

            Text(
                text = "Vertical Offset: ${(settings.offsetYFraction * 100).roundToInt()}%",
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                color = NexusColors.TextSecondary
            )
            Slider(
                value = settings.offsetYFraction,
                onValueChange = { value -> onUpdateSettings { it.copy(offsetYFraction = value) } },
                valueRange = -0.20f..0.20f,
                colors = SliderDefaults.colors(
                    thumbColor = NexusColors.CyanElectric,
                    activeTrackColor = NexusColors.CyanElectric
                )
            )
        }

        // Background Theme
        SectionCard(title = "Background") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BackgroundTheme.entries.forEach { theme ->
                    val selected = settings.backgroundTheme == theme
                    Surface(
                        onClick = { onUpdateSettings { it.copy(backgroundTheme = theme) } },
                        color = if (selected) NexusColors.CyanElectric.copy(alpha = 0.14f) else NexusColors.Obsidian,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            1.dp,
                            if (selected) NexusColors.CyanElectric else NexusColors.Hairline
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                            Text(
                                text = theme.label,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (selected) NexusColors.CyanElectric else NexusColors.TextPrimary
                            )
                            Text(
                                text = theme.subtitle,
                                fontSize = 12.sp,
                                color = NexusColors.TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Expressions & Situation Emotion Preview
        SectionCard(title = "Expression & Emotion") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val options: List<CharacterExpression?> = listOf(null) + CharacterExpression.entries
                options.forEach { expr ->
                    val selected = settings.pinnedExpression == expr
                    Surface(
                        onClick = { onUpdateSettings { it.copy(pinnedExpression = expr) } },
                        color = if (selected) NexusColors.CyanElectric else NexusColors.Obsidian,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            1.dp,
                            if (selected) NexusColors.CyanElectric else NexusColors.Hairline
                        )
                    ) {
                        Text(
                            text = expr?.label ?: "Auto",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (selected) NexusColors.Obsidian else NexusColors.TextSecondary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Emotion State (${emotion.label})",
                    fontSize = 12.sp,
                    color = NexusColors.TextSecondary
                )
                TextButton(onClick = { onTestVoiceEmotion(emotion) }) {
                    Text(
                        text = if (isSpeaking) "Speaking..." else "Test Voice & Sync",
                        color = NexusColors.CyanElectric,
                        fontSize = 12.sp
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CompanionEmotion.entries.forEach { item ->
                    val selected = emotion == item
                    Surface(
                        onClick = {
                            onUpdateSettings { it.copy(pinnedExpression = null) }
                            onPreviewEmotion(item)
                        },
                        color = if (selected) NexusColors.CyanElectric.copy(alpha = 0.2f) else NexusColors.Obsidian,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            1.dp,
                            if (selected) NexusColors.CyanElectric else NexusColors.Hairline
                        )
                    ) {
                        Text(
                            text = item.label,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (selected) NexusColors.CyanElectric else NexusColors.TextSecondary,
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // Animation Intensity & Sound Effects
        SectionCard(title = "Motion & Audio") {
            Text(
                text = "Animation Intensity",
                fontSize = 13.sp,
                color = NexusColors.TextSecondary
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnimationIntensity.entries.forEach { level ->
                    val selected = settings.animationIntensity == level
                    Surface(
                        onClick = { onUpdateSettings { it.copy(animationIntensity = level) } },
                        color = if (selected) NexusColors.CyanElectric else NexusColors.Obsidian,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            1.dp,
                            if (selected) NexusColors.CyanElectric else NexusColors.Hairline
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = level.label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (selected) NexusColors.Obsidian else NexusColors.TextSecondary
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Sound Effects", fontSize = 14.sp, color = NexusColors.TextPrimary)
                    Text("Subtle synth feedback on taps & modes", fontSize = 12.sp, color = NexusColors.TextSecondary)
                }
                Switch(
                    checked = settings.sfxEnabled,
                    onCheckedChange = { checked -> onUpdateSettings { it.copy(sfxEnabled = checked) } },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NexusColors.Obsidian,
                        checkedTrackColor = NexusColors.CyanElectric
                    )
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Gaming Timer Alerts", fontSize = 14.sp, color = NexusColors.TextPrimary)
                    Text("Notify when your gaming goal is reached", fontSize = 12.sp, color = NexusColors.TextSecondary)
                }
                Switch(
                    checked = settings.timerAlertsEnabled,
                    onCheckedChange = { checked -> onUpdateSettings { it.copy(timerAlertsEnabled = checked) } },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NexusColors.Obsidian,
                        checkedTrackColor = NexusColors.CyanElectric
                    )
                )
            }
        }

        // Personality Settings
        SectionCard(title = "Personality") {
            Text(
                text = "Playful Sarcasm: ${settings.personality.sarcasmLevel}%",
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                color = NexusColors.TextSecondary
            )
            Slider(
                value = settings.personality.sarcasmLevel.toFloat(),
                onValueChange = { v ->
                    onUpdateSettings {
                        it.copy(personality = it.personality.copy(sarcasmLevel = v.roundToInt()))
                    }
                },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = NexusColors.CyanElectric,
                    activeTrackColor = NexusColors.CyanElectric
                )
            )

            Text(
                text = "Conversation Style",
                fontSize = 13.sp,
                color = NexusColors.TextSecondary
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ResponseStyle.entries.forEach { style ->
                    val selected = settings.personality.responseStyle == style
                    Surface(
                        onClick = {
                            onUpdateSettings {
                                it.copy(personality = it.personality.copy(responseStyle = style))
                            }
                        },
                        color = if (selected) NexusColors.CyanElectric else NexusColors.Obsidian,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            1.dp,
                            if (selected) NexusColors.CyanElectric else NexusColors.Hairline
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = style.label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (selected) NexusColors.Obsidian else NexusColors.TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        color = NexusColors.Charcoal,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, NexusColors.Hairline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = NexusColors.CyanElectric
            )
            content()
        }
    }
}

package com.nexus.companion.audio

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.nexus.companion.model.CompanionEmotion
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

data class MaleVoiceProfile(
    val pitch: Float,
    val speechRate: Float
)

class NexusVoiceController(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val controllerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val speechSequence = AtomicLong(0L)

    @Volatile
    private var activeUtteranceId: String? = null

    @Volatile
    private var activeSpokenText: String = ""

    @Volatile
    private var interruptedCurrent = false

    @Volatile
    private var lastRangePulseMs = 0L

    private var mouthEnvelopeJob: Job? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _speechMouthLevel = MutableStateFlow(0f)
    val speechMouthLevel: StateFlow<Float> = _speechMouthLevel.asStateFlow()

    private val _voiceError = MutableStateFlow<String?>(null)
    val voiceError: StateFlow<String?> = _voiceError.asStateFlow()

    var onSpeechFinished: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val res = engine.setLanguage(Locale.US)
                ttsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                selectMatureMaleVoice(engine)
                engine.setPitch(0.85f)
                engine.setSpeechRate(0.99f)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        if (utteranceId != null && utteranceId == activeUtteranceId) {
                            _isSpeaking.value = true
                            startMouthSyncLoop()
                        }
                    }

                    override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                        if (utteranceId == null || utteranceId != activeUtteranceId) return
                        lastRangePulseMs = System.currentTimeMillis()
                        val text = activeSpokenText
                        val safeStart = start.coerceIn(0, text.length)
                        val safeEnd = end.coerceIn(safeStart, text.length)
                        val word = text.substring(safeStart, safeEnd)
                        _speechMouthLevel.value = computeWordMouthOpenness(word)
                    }

                    override fun onDone(utteranceId: String?) {
                        if (utteranceId == null || utteranceId != activeUtteranceId) return
                        val shouldTriggerCallback = !interruptedCurrent
                        clearSpeakingState()
                        if (shouldTriggerCallback) {
                            mainHandler.post { onSpeechFinished?.invoke() }
                        }
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        if (utteranceId == null || utteranceId == activeUtteranceId) {
                            clearSpeakingState()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (utteranceId == null || utteranceId == activeUtteranceId) {
                            clearSpeakingState()
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        if (utteranceId == null || utteranceId == activeUtteranceId) {
                            clearSpeakingState()
                        }
                    }
                })
            }
        }
    }

    /**
     * Mature anime-inspired male voice tuning around a deep, natural, confident baseline.
     */
    fun profileForEmotion(emotion: CompanionEmotion): MaleVoiceProfile {
        return when (emotion) {
            CompanionEmotion.NEUTRAL -> MaleVoiceProfile(pitch = 0.85f, speechRate = 0.99f)
            CompanionEmotion.HAPPY -> MaleVoiceProfile(pitch = 0.88f, speechRate = 1.03f)
            CompanionEmotion.PLAYFUL -> MaleVoiceProfile(pitch = 0.89f, speechRate = 1.04f)
            CompanionEmotion.SARCASTIC -> MaleVoiceProfile(pitch = 0.83f, speechRate = 0.95f)
            CompanionEmotion.ANGRY -> MaleVoiceProfile(pitch = 0.81f, speechRate = 1.05f)
            CompanionEmotion.EMBARRASSED -> MaleVoiceProfile(pitch = 0.88f, speechRate = 1.03f)
            CompanionEmotion.SAD -> MaleVoiceProfile(pitch = 0.80f, speechRate = 0.91f)
            CompanionEmotion.SURPRISED -> MaleVoiceProfile(pitch = 0.91f, speechRate = 1.06f)
            CompanionEmotion.THINKING -> MaleVoiceProfile(pitch = 0.83f, speechRate = 0.93f)
            CompanionEmotion.SLEEPY -> MaleVoiceProfile(pitch = 0.79f, speechRate = 0.88f)
            CompanionEmotion.EXCITED -> MaleVoiceProfile(pitch = 0.91f, speechRate = 1.08f)
            CompanionEmotion.CARING -> MaleVoiceProfile(pitch = 0.82f, speechRate = 0.94f)
        }
    }

    private fun selectMatureMaleVoice(engine: TextToSpeech) {
        val voices = runCatching { engine.voices }.getOrNull().orEmpty()
        if (voices.isEmpty()) return

        val englishVoices = voices.filter { voice ->
            voice.locale?.language?.equals("en", ignoreCase = true) == true
        }
        val candidates = englishVoices.ifEmpty { voices.toList() }

        val maleHints = listOf(
            "male", "man", "daniel", "david", "mark", "alex", "james",
            "matthew", "ryan", "oliver", "arthur", "thomas", "george",
            "iom", "iol", "tpd", "rjs", "gbd", "aud"
        )
        val femaleHints = listOf(
            "female", "woman", "samantha", "victoria", "karen", "tessa",
            "serena", "fiona", "moira", "sfg", "tpf", "iob", "iog", "gba", "gbc"
        )

        val preferred = candidates.maxByOrNull { voice ->
            var score = 0
            val name = voice.name.lowercase(Locale.US)
            if (voice.locale?.country?.equals("US", ignoreCase = true) == true) score += 8
            if (!voice.isNetworkConnectionRequired) score += 6
            if (voice.quality >= Voice.QUALITY_HIGH) score += 4
            if (maleHints.any { it in name }) score += 28
            if (femaleHints.any { it in name }) score -= 28
            score
        }

        if (preferred != null) {
            runCatching { engine.voice = preferred }
        }
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    @Synchronized
    fun speak(text: String, emotion: CompanionEmotion = CompanionEmotion.NEUTRAL) {
        val cleaned = sanitizeForSpeech(text)
        if (!ttsReady || cleaned.isEmpty()) return

        // Stop any prior utterance cleanly so voices never overlap
        runCatching { tts?.stop() }
        mouthEnvelopeJob?.cancel()

        val seq = speechSequence.incrementAndGet()
        val utteranceId = "nexus_utt_$seq"
        interruptedCurrent = false
        activeUtteranceId = utteranceId
        activeSpokenText = cleaned
        lastRangePulseMs = 0L

        val profile = profileForEmotion(emotion)
        tts?.setPitch(profile.pitch)
        tts?.setSpeechRate(profile.speechRate)

        _isSpeaking.value = true
        startMouthSyncLoop()

        val started = tts?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (started != TextToSpeech.SUCCESS) {
            clearSpeakingState()
        }
    }

    private fun startMouthSyncLoop() {
        mouthEnvelopeJob?.cancel()
        mouthEnvelopeJob = controllerScope.launch {
            var tick = 0
            while (isActive && _isSpeaking.value) {
                val now = System.currentTimeMillis()
                // If onRangeStart recently fired (<180ms ago), gently decay between syllables;
                // otherwise drive crisp syllable cadence while TTS is active.
                if (now - lastRangePulseMs < 180L) {
                    _speechMouthLevel.value = (_speechMouthLevel.value * 0.86f).coerceAtLeast(0.18f)
                } else {
                    tick++
                    val pattern = floatArrayOf(0.75f, 0.25f, 0.88f, 0.42f, 0.68f, 0.14f)
                    _speechMouthLevel.value = pattern[tick % pattern.size]
                }
                delay(75L)
            }
            _speechMouthLevel.value = 0f
        }
    }

    private fun clearSpeakingState() {
        activeUtteranceId = null
        activeSpokenText = ""
        mouthEnvelopeJob?.cancel()
        _isSpeaking.value = false
        _speechMouthLevel.value = 0f
    }

    @Synchronized
    fun interruptSpeaking() {
        interruptedCurrent = true
        speechSequence.incrementAndGet()
        clearSpeakingState()
        runCatching { tts?.stop() }
    }

    fun stopSpeaking() {
        interruptSpeaking()
    }

    private fun computeWordMouthOpenness(word: String): Float {
        val lower = word.lowercase(Locale.US)
        if (lower.isBlank()) return 0.12f
        val wideVowels = lower.count { it in "aou" }
        val midVowels = lower.count { it in "ei" }
        val score = 0.28f + wideVowels * 0.24f + midVowels * 0.14f
        return score.coerceIn(0.24f, 0.96f)
    }

    private fun sanitizeForSpeech(raw: String): String {
        return raw
            .replace(Regex("[*_`~#]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun startListening(onTranscript: (String) -> Unit) {
        _voiceError.value = null
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceError.value = "Speech recognition service is not installed on this device."
            return
        }

        stopListening()
        interruptSpeaking()

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        speechRecognizer = recognizer

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _voiceError.value = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio capture error."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Speech recognition network unavailable."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice recognizer busy. Tap mic again."
                    SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Try speaking clearly."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                    else -> "Voice input stopped (code $error)."
                }
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val top = matches?.firstOrNull()?.trim()
                if (!top.isNullOrEmpty()) {
                    onTranscript(top)
                } else {
                    _voiceError.value = "Didn't catch anything."
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            recognizer.startListening(intent)
        } catch (_: Throwable) {
            _isListening.value = false
            _voiceError.value = "Could not start voice capture on this device."
        }
    }

    fun stopListening() {
        _isListening.value = false
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (_: Throwable) {
        }
        speechRecognizer = null
    }

    fun clearError() {
        _voiceError.value = null
    }

    fun release() {
        onSpeechFinished = null
        stopListening()
        interruptSpeaking()
        controllerScope.cancel()
        try {
            tts?.shutdown()
        } catch (_: Throwable) {
        }
        tts = null
    }
}

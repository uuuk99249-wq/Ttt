package com.nexus.companion.ai

import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CharacterMood
import com.nexus.companion.model.ChatMessage
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionMemory
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.DeviceTelemetry
import com.nexus.companion.model.MessageRole
import com.nexus.companion.model.NotificationSnapshot
import com.nexus.companion.model.PersonalitySettings
import com.nexus.companion.model.ReplySource
import com.nexus.companion.model.TemperatureUnit
import com.nexus.companion.model.WeatherSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.OutputStreamWriter
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

data class AiMemoryDelta(
    val preferredName: String = "",
    val addInterests: List<String> = emptyList(),
    val addPreferences: List<String> = emptyList(),
    val addFacts: List<String> = emptyList(),
    val updatedSummary: String = ""
)

data class AiChatResult(
    val text: String,
    val expression: CharacterExpression,
    val emotion: CompanionEmotion = CompanionEmotion.NEUTRAL,
    val situation: CompanionSituation = CompanionSituation.CHATTING,
    val source: ReplySource,
    val suggestedMood: CharacterMood? = null,
    val memoryDelta: AiMemoryDelta? = null,
    val connectionNote: String? = null,
    val isError: Boolean = false
)

class NexusAiService {

    suspend fun generateReply(
        userMessage: String,
        history: List<ChatMessage>,
        mode: CharacterMode,
        mood: CharacterMood = CharacterMood.NEUTRAL,
        telemetry: DeviceTelemetry,
        personality: PersonalitySettings,
        notifications: NotificationSnapshot,
        memory: CompanionMemory = CompanionMemory(),
        detectedGame: String? = null,
        voiceMode: Boolean = false,
        weather: WeatherSnapshot? = null,
        weatherUnit: TemperatureUnit = TemperatureUnit.CELSIUS,
        serverUrl: String
    ): AiChatResult = withContext(Dispatchers.IO) {
        val cleanedUrl = serverUrl.trim()
        if (cleanedUrl.isEmpty()) {
            return@withContext AiChatResult(
                text = "Live AI backend URL is not configured yet. Open Settings -> Live AI Backend Endpoint and enter your /api/nexus/chat URL to talk with NEXUS.",
                expression = CharacterExpression.NEUTRAL,
                emotion = CompanionEmotion.NEUTRAL,
                situation = CompanionSituation.IDLE,
                source = ReplySource.SYSTEM_NOTICE,
                connectionNote = "AI endpoint not configured. Add your server URL in Settings.",
                isError = true
            )
        }

        return@withContext try {
            callBackendRelay(
                endpointUrl = cleanedUrl,
                userMessage = userMessage,
                history = history,
                mode = mode,
                mood = mood,
                telemetry = telemetry,
                personality = personality,
                notifications = notifications,
                memory = memory,
                detectedGame = detectedGame,
                voiceMode = voiceMode,
                weather = weather,
                weatherUnit = weatherUnit
            ) ?: AiChatResult(
                text = "AI server responded with an empty message. Tap Retry to send again.",
                expression = CharacterExpression.ANNOYED,
                emotion = CompanionEmotion.SARCASTIC,
                situation = CompanionSituation.CHATTING,
                source = ReplySource.SYSTEM_NOTICE,
                connectionNote = "AI server returned an empty payload.",
                isError = true
            )
        } catch (e: UnknownHostException) {
            AiChatResult(
                text = "No internet connection or unknown host for the AI server. Check your Wi-Fi/data or server URL in Settings.",
                expression = CharacterExpression.ANNOYED,
                emotion = CompanionEmotion.SAD,
                situation = CompanionSituation.IDLE,
                source = ReplySource.SYSTEM_NOTICE,
                connectionNote = "Network unavailable (${e.message ?: "unknown host"}).",
                isError = true
            )
        } catch (e: ConnectException) {
            AiChatResult(
                text = "Could not connect to the AI server at $cleanedUrl. Verify the server is running and reachable from this device.",
                expression = CharacterExpression.ANNOYED,
                emotion = CompanionEmotion.SARCASTIC,
                situation = CompanionSituation.IDLE,
                source = ReplySource.SYSTEM_NOTICE,
                connectionNote = "Connection refused by AI server.",
                isError = true
            )
        } catch (e: SocketTimeoutException) {
            AiChatResult(
                text = "The AI server timed out before replying. Check your connection and tap Retry.",
                expression = CharacterExpression.ANNOYED,
                emotion = CompanionEmotion.THINKING,
                situation = CompanionSituation.IDLE,
                source = ReplySource.SYSTEM_NOTICE,
                connectionNote = "AI request timed out.",
                isError = true
            )
        } catch (e: Exception) {
            val detail = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            AiChatResult(
                text = "AI service unavailable ($detail). Tap Retry or check Settings.",
                expression = CharacterExpression.ANNOYED,
                emotion = CompanionEmotion.SARCASTIC,
                situation = CompanionSituation.IDLE,
                source = ReplySource.SYSTEM_NOTICE,
                connectionNote = detail,
                isError = true
            )
        }
    }

    suspend fun testBackendConnection(serverUrl: String): Result<String> = withContext(Dispatchers.IO) {
        val cleaned = serverUrl.trim()
        if (cleaned.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Enter a backend URL first."))
        }
        return@withContext try {
            val res = callBackendRelay(
                endpointUrl = cleaned,
                userMessage = "Quick system ping. Confirm you're online in one short line.",
                history = emptyList(),
                mode = CharacterMode.CONVERSATION,
                mood = CharacterMood.NEUTRAL,
                telemetry = DeviceTelemetry(batteryPercent = 80),
                personality = PersonalitySettings(),
                notifications = NotificationSnapshot(),
                memory = CompanionMemory(enabled = false),
                detectedGame = null,
                voiceMode = false
            )
            if (res != null) {
                Result.success("Connected: \"${res.text}\"")
            } else {
                Result.failure(IllegalStateException("Server returned an empty response."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    internal fun normalizeEndpointUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim().trimEnd('/')
        if (trimmed.isEmpty()) return ""
        return if (trimmed.endsWith("/api/nexus/chat")) {
            trimmed
        } else {
            val parsed = runCatching { URL(trimmed) }.getOrNull()
            if (parsed != null && (parsed.path.isEmpty() || parsed.path == "/")) {
                "$trimmed/api/nexus/chat"
            } else {
                trimmed
            }
        }
    }

    private fun callBackendRelay(
        endpointUrl: String,
        userMessage: String,
        history: List<ChatMessage>,
        mode: CharacterMode,
        mood: CharacterMood,
        telemetry: DeviceTelemetry,
        personality: PersonalitySettings,
        notifications: NotificationSnapshot,
        memory: CompanionMemory,
        detectedGame: String?,
        voiceMode: Boolean,
        weather: WeatherSnapshot? = null,
        weatherUnit: TemperatureUnit = TemperatureUnit.CELSIUS
    ): AiChatResult? {
        val url = URL(normalizeEndpointUrl(endpointUrl))
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("Accept", "application/json")
        }

        val payload = JSONObject().apply {
            put("message", userMessage)
            put("mode", mode.name)
            put("mood", mood.name)
            put("sarcasmLevel", personality.sarcasmLevel)
            put("responseStyle", personality.responseStyle.name)
            put("voiceMode", voiceMode)
            put("device", JSONObject().apply {
                put("batteryPercent", telemetry.batteryPercent)
                put("isCharging", telemetry.isCharging)
                put("chargingSource", telemetry.chargingSource)
                put("time", telemetry.formattedTime)
                put("date", telemetry.formattedDate)
                put("notificationsCount", if (notifications.listenerConnected) notifications.activeCount else -1)
                if (!detectedGame.isNullOrBlank()) {
                    put("detectedGame", detectedGame)
                }
                if (weather != null) {
                    put("weather", JSONObject().apply {
                        put("location", weather.locationName)
                        put("temperature", weather.formatTemperature(weatherUnit))
                        put("tempC", weather.temperatureCelsius)
                        put("condition", weather.conditionLabel)
                        put("humidity", weather.relativeHumidityPercent)
                        put("windKmh", weather.windSpeedKmh)
                        put("precipitationMm", weather.precipitationMm)
                        put("isCached", weather.isFromCache)
                        put("updatedAt", weather.formatUpdatedTime())
                    })
                }
            })
            put("memory", JSONObject().apply {
                put("enabled", memory.enabled)
                if (memory.enabled) {
                    put("preferredName", memory.preferredName)
                    put("interests", JSONArray(memory.interests))
                    put("preferences", JSONArray(memory.preferences))
                    put("facts", JSONArray(memory.facts))
                    put("conversationSummary", memory.conversationSummary)
                }
            })
            val histArray = JSONArray()
            history
                .filter { !it.isError && it.source != ReplySource.SYSTEM_NOTICE }
                .takeLast(36)
                .forEach { msg ->
                    histArray.put(JSONObject().apply {
                        put("role", if (msg.role == MessageRole.USER) "user" else "model")
                        put("text", msg.text)
                    })
                }
            put("history", histArray)
        }

        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(payload.toString())
            writer.flush()
        }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText).orEmpty()
        conn.disconnect()

        if (code !in 200..299) {
            val serverError = runCatching { JSONObject(body).optString("error").trim() }.getOrNull().orEmpty()
            val detail = if (serverError.isNotEmpty()) serverError else "HTTP $code"
            throw IllegalStateException(detail)
        }

        val json = JSONObject(body)
        val replyText = json.optString("reply").trim()
        if (replyText.isEmpty()) return null
        val exprName = json.optString("expression", "NEUTRAL").uppercase()
        val expression = CharacterExpression.entries.firstOrNull { it.name == exprName }
            ?: CharacterExpression.NEUTRAL

        val emotionName = json.optString("emotion", "").uppercase()
        val emotion = CompanionEmotion.entries.firstOrNull { it.name == emotionName }
            ?: when (expression) {
                CharacterExpression.HAPPY -> CompanionEmotion.HAPPY
                CharacterExpression.ANNOYED -> CompanionEmotion.SARCASTIC
                CharacterExpression.SURPRISED -> CompanionEmotion.SURPRISED
                CharacterExpression.SLEEPY -> CompanionEmotion.SLEEPY
                CharacterExpression.NEUTRAL -> CompanionEmotion.NEUTRAL
            }

        val situationName = json.optString("situation", "").uppercase()
        val situation = CompanionSituation.entries.firstOrNull { it.name == situationName }
            ?: CompanionSituation.CHATTING

        val moodName = json.optString("suggestedMood", "").uppercase()
        val suggestedMood = CharacterMood.entries.firstOrNull { it.name == moodName }

        val memJson = json.optJSONObject("memoryUpdate")
        val memoryDelta = if (memJson != null) {
            AiMemoryDelta(
                preferredName = memJson.optString("preferredName", "").trim(),
                addInterests = memJson.optJSONArray("addInterests").toStringList(),
                addPreferences = memJson.optJSONArray("addPreferences").toStringList(),
                addFacts = memJson.optJSONArray("addFacts").toStringList(),
                updatedSummary = memJson.optString("updatedSummary", "").trim()
            )
        } else {
            null
        }

        return AiChatResult(
            text = replyText,
            expression = expression,
            emotion = emotion,
            situation = situation,
            source = ReplySource.LIVE_AI,
            suggestedMood = suggestedMood,
            memoryDelta = memoryDelta
        )
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until length()) {
            val item = optString(i).trim()
            if (item.isNotEmpty()) out.add(item)
        }
        return out
    }
}

package com.nexus.companion.weather

import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMood
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.TemperatureUnit
import com.nexus.companion.model.WeatherConditionCategory
import com.nexus.companion.model.WeatherSnapshot

data class WeatherCharacterReaction(
    val suggestedMood: CharacterMood,
    val emotion: CompanionEmotion,
    val situation: CompanionSituation,
    val expression: CharacterExpression,
    val dialogueCandidates: List<String>
)

/**
 * Maps real Open-Meteo weather telemetry to NEXUS's mood, emotional expression, and
 * personality-consistent dialogue pools without modifying his visual design or scenery.
 */
object WeatherReactionEngine {

    fun evaluate(
        weather: WeatherSnapshot,
        unit: TemperatureUnit,
        sarcasmLevel: Int
    ): WeatherCharacterReaction {
        val tempText = weather.formatTemperature(unit)
        val city = weather.locationName
        val snark = sarcasmLevel >= 45
        val tempC = weather.temperatureCelsius

        return when {
            weather.conditionCategory == WeatherConditionCategory.THUNDERSTORM -> {
                val annoyed = snark && tempC > 18.0
                WeatherCharacterReaction(
                    suggestedMood = if (annoyed) CharacterMood.ANNOYED else CharacterMood.NEUTRAL,
                    emotion = if (annoyed) CompanionEmotion.SARCASTIC else CompanionEmotion.SURPRISED,
                    situation = CompanionSituation.IDLE,
                    expression = if (annoyed) CharacterExpression.ANNOYED else CharacterExpression.SURPRISED,
                    dialogueCandidates = listOf(
                        "Whoa—thunder rolling through $city at $tempText. Keep the charger ready just in case the grid flickers.",
                        "Lightning outside in $city. Try not to get dramatic every time the sky booms.",
                        "Storm clouds and thunder over $city ($tempText). Honestly, perfect excuse to stay inside and queue matches.",
                        if (snark) "Thunderstorm in $city? Even the sky sounds annoyed today." else "Watch out for that thunderstorm in $city—stay indoors if you can."
                    )
                )
            }

            weather.conditionCategory == WeatherConditionCategory.RAINY || weather.precipitationMm >= 0.4 -> {
                WeatherCharacterReaction(
                    suggestedMood = CharacterMood.NEUTRAL,
                    emotion = CompanionEmotion.THINKING,
                    situation = CompanionSituation.THINKING,
                    expression = CharacterExpression.NEUTRAL,
                    dialogueCandidates = listOf(
                        "${weather.conditionLabel} in $city at $tempText. Honestly? Best kind of cozy rainy-day vibe.",
                        "Rain tapping the glass outside ($tempText, ${weather.relativeHumidityPercent}% humidity). Good weather for focus—or tea.",
                        "Looks like ${weather.conditionLabel.lowercase()} over $city. Grab an umbrella if you're heading out, alright?",
                        "Steady rain in $city. Makes the whole screen glow a little sharper today."
                    )
                )
            }

            weather.conditionCategory == WeatherConditionCategory.FOGGY -> {
                WeatherCharacterReaction(
                    suggestedMood = CharacterMood.PLAYFUL,
                    emotion = CompanionEmotion.THINKING,
                    situation = CompanionSituation.THINKING,
                    expression = CharacterExpression.NEUTRAL,
                    dialogueCandidates = listOf(
                        "Thick fog rolling through $city at $tempText. Looks like somebody turned down the world's render distance.",
                        "${weather.conditionLabel} in $city... feels weirdly cinematic out there today.",
                        "Visibility's hazy in $city ($tempText). Watch your step if you're going outside—stealth weather doesn't buff traffic.",
                        "Mysterious fog outside. Good thing my sensors don't rely on headlights."
                    )
                )
            }

            weather.conditionCategory == WeatherConditionCategory.SNOWY || tempC <= 8.0 -> {
                val coldWord = if (weather.conditionCategory == WeatherConditionCategory.SNOWY) {
                    weather.conditionLabel.lowercase()
                } else {
                    "chilly"
                }
                WeatherCharacterReaction(
                    suggestedMood = CharacterMood.NEUTRAL,
                    emotion = CompanionEmotion.CARING,
                    situation = CompanionSituation.CHATTING,
                    expression = CharacterExpression.HAPPY,
                    dialogueCandidates = listOf(
                        "It's $tempText and $coldWord in $city. Zip up your jacket—don't pretend you're immune to cold.",
                        "$tempText out there in $city. Even looking at that temperature makes me glad this coat has a collar.",
                        "Brisk $tempText in $city (${weather.formatWindSpeed()} wind). Warm drink weather if you ask me.",
                        if (snark) "$tempText in $city? Keep your hands warm before you blame cold fingers on your aim." else "Stay warm out there—it's $tempText in $city right now."
                    )
                )
            }

            weather.conditionCategory == WeatherConditionCategory.CLOUDY ||
                weather.conditionCategory == WeatherConditionCategory.PARTLY_CLOUDY -> {
                val sleepyShift = weather.conditionCategory == WeatherConditionCategory.CLOUDY
                WeatherCharacterReaction(
                    suggestedMood = if (sleepyShift) CharacterMood.SLEEPY else CharacterMood.NEUTRAL,
                    emotion = if (sleepyShift) CompanionEmotion.SLEEPY else CompanionEmotion.NEUTRAL,
                    situation = CompanionSituation.IDLE,
                    expression = if (sleepyShift) CharacterExpression.SLEEPY else CharacterExpression.NEUTRAL,
                    dialogueCandidates = listOf(
                        "${weather.conditionLabel} in $city at $tempText. Mellow skies, zero glare—easy on the eyes.",
                        "Overcast mood over $city ($tempText). Kind of makes you want to lean back and take it slow.",
                        "Cloud cover's holding steady at $tempText in $city. Calm day to get things done.",
                        if (snark) "Gray skies at $tempText. Not dramatic, just chill—kind of my default aesthetic." else "Relaxed ${weather.conditionLabel.lowercase()} day in $city at $tempText."
                    )
                )
            }

            // Clear / Sunny (distinguishes hot sun vs mild clear sky)
            else -> {
                if (tempC >= 28.0) {
                    WeatherCharacterReaction(
                        suggestedMood = CharacterMood.PLAYFUL,
                        emotion = CompanionEmotion.PLAYFUL,
                        situation = CompanionSituation.JOKING,
                        expression = CharacterExpression.HAPPY,
                        dialogueCandidates = listOf(
                            "$tempText and bright sun in $city? Glad I'm digital—wearing a long coat in that heat sounds brutal.",
                            "Sun's blazing at $tempText in $city. Hydrate, boss—don't let heatstroke nerf you.",
                            "Clear skies and $tempText in $city. Stay in the shade unless you're trying to melt.",
                            if (snark) "$tempText outside! Tell the sun to dial it back about ten percent." else "Warm and sunny at $tempText in $city—good energy out there."
                        )
                    )
                } else {
                    WeatherCharacterReaction(
                        suggestedMood = CharacterMood.HAPPY,
                        emotion = CompanionEmotion.HAPPY,
                        situation = CompanionSituation.IDLE,
                        expression = CharacterExpression.HAPPY,
                        dialogueCandidates = listOf(
                            "${weather.conditionLabel} and $tempText in $city. Honestly, pretty sharp weather today.",
                            "Clean skies over $city at $tempText (${weather.formatWindSpeed()} wind). Mood's looking bright.",
                            "Sun's out in $city ($tempText). Almost nice enough to make me forgive you for staying indoors.",
                            "Clear view in $city at $tempText. Solid day to step out—or dominate a match first."
                        )
                    )
                }
            }
        }
    }
}

package com.nexus.companion.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import com.nexus.companion.model.DeviceTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class DeviceTelemetryManager(private val context: Context) {

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault())
    private val dateFormatter = DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault())

    private val _telemetry = MutableStateFlow(readInitialTelemetry())
    val telemetry: StateFlow<DeviceTelemetry> = _telemetry.asStateFlow()

    private var receiverRegistered = false

    private val batteryAndPowerReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent == null) return
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> updateFromBatteryIntent(intent)
                Intent.ACTION_POWER_CONNECTED,
                Intent.ACTION_POWER_DISCONNECTED,
                PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> refreshSnapshot()
            }
        }
    }

    fun start() {
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
                addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            }
            val sticky = context.registerReceiver(batteryAndPowerReceiver, filter)
            sticky?.let { updateFromBatteryIntent(it) }
            receiverRegistered = true
        }

        // Low-overhead clock updater (aligns to minute boundaries after first read)
        scope.launch {
            while (isActive) {
                updateClockAndPowerSave()
                val millisToNextMinute = 60_000L - (System.currentTimeMillis() % 60_000L)
                delay(millisToNextMinute.coerceIn(1_000L, 60_000L))
            }
        }
    }

    private fun readInitialTelemetry(): DeviceTelemetry {
        val now = LocalDateTime.now()
        val level = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            ?.takeIf { it in 0..100 } ?: -1
        val charging = batteryManager?.isCharging ?: false
        return DeviceTelemetry(
            batteryPercent = level,
            isCharging = charging,
            chargingSource = if (charging) "Connected" else "Battery",
            batteryTempCelsius = null,
            isPowerSaveMode = powerManager?.isPowerSaveMode ?: false,
            formattedTime = now.format(timeFormatter),
            formattedDate = now.format(dateFormatter)
        )
    }

    private fun refreshSnapshot() {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (intent != null) {
            updateFromBatteryIntent(intent)
        } else {
            updateClockAndPowerSave()
        }
    }

    private fun updateFromBatteryIntent(intent: Intent) {
        val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (rawLevel >= 0 && scale > 0) ((rawLevel * 100f) / scale).toInt().coerceIn(0, 100) else _telemetry.value.batteryPercent

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL ||
            plugged > 0

        val source = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> if (isCharging) "Charging" else "Battery"
        }

        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val tempC = if (tempTenths != Int.MIN_VALUE && tempTenths > 0) tempTenths / 10f else null

        val now = LocalDateTime.now()
        _telemetry.value = DeviceTelemetry(
            batteryPercent = pct,
            isCharging = isCharging,
            chargingSource = source,
            batteryTempCelsius = tempC,
            isPowerSaveMode = powerManager?.isPowerSaveMode ?: false,
            formattedTime = now.format(timeFormatter),
            formattedDate = now.format(dateFormatter)
        )
    }

    private fun updateClockAndPowerSave() {
        val now = LocalDateTime.now()
        _telemetry.value = _telemetry.value.copy(
            isPowerSaveMode = powerManager?.isPowerSaveMode ?: false,
            formattedTime = now.format(timeFormatter),
            formattedDate = now.format(dateFormatter)
        )
    }

    fun stop() {
        if (receiverRegistered) {
            try {
                context.unregisterReceiver(batteryAndPowerReceiver)
            } catch (_: IllegalArgumentException) {
            }
            receiverRegistered = false
        }
        scope.cancel()
    }
}

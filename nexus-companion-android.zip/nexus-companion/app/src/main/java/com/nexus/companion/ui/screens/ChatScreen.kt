package com.nexus.companion.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.ChatMessage
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionMemory
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.model.MemoryCategory
import com.nexus.companion.model.MessageRole
import com.nexus.companion.model.ReplySource
import com.nexus.companion.ui.components.NexusCharacterStage
import com.nexus.companion.ui.theme.NexusColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    mode: CharacterMode,
    expression: CharacterExpression,
    emotion: CompanionEmotion = CompanionEmotion.NEUTRAL,
    situation: CompanionSituation = CompanionSituation.CHATTING,
    speechMouthLevel: Float = 0f,
    settings: CustomizationSettings,
    isPowerSaveMode: Boolean,
    messages: List<ChatMessage>,
    memory: CompanionMemory,
    isThinking: Boolean,
    isListening: Boolean,
    isSpeaking: Boolean,
    voiceError: String?,
    connectionBanner: String?,
    aiServerUrl: String,
    onSendMessage: (String) -> Unit,
    onRetryMessage: (Long) -> Unit,
    onMicClick: () -> Unit,
    onInterruptSpeaking: () -> Unit,
    onToggleVoiceOutput: () -> Unit,
    onToggleVoiceConversationMode: () -> Unit,
    onSetMemoryEnabled: (Boolean) -> Unit,
    onUpdatePreferredName: (String) -> Unit,
    onAddMemoryItem: (MemoryCategory, String) -> Unit,
    onUpdateMemoryItem: (MemoryCategory, Int, String) -> Unit,
    onDeleteMemoryItem: (MemoryCategory, Int) -> Unit,
    onUpdateSummary: (String) -> Unit,
    onClearMemory: () -> Unit,
    onClearHistory: () -> Unit,
    onDismissVoiceError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    var showMemorySheet by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, isThinking) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusColors.Obsidian)
            .imePadding()
    ) {
        // Header with compact character viewport & honest AI/voice connection status
        Surface(
            color = NexusColors.Charcoal,
            border = BorderStroke(1.dp, NexusColors.Hairline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexusColors.Obsidian)
                ) {
                    NexusCharacterStage(
                        mode = mode,
                        expression = expression,
                        settings = settings.copy(offsetXFraction = 0f, offsetYFraction = 0.35f, scale = 2.4f),
                        isPowerSaveMode = isPowerSaveMode,
                        isSpeakingOrListening = isListening || isThinking || isSpeaking,
                        touchPulseNonce = 0,
                        onCharacterTap = {},
                        emotion = emotion,
                        situation = situation,
                        isSpeaking = isSpeaking,
                        isListening = isListening,
                        isThinking = isThinking,
                        speechMouthLevel = speechMouthLevel,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "NEXUS",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusColors.TextPrimary
                    )
                    Text(
                        text = when {
                            isListening -> "Listening to voice..."
                            isSpeaking -> "Speaking aloud · ${emotion.label}"
                            isThinking -> "Thinking..."
                            settings.personality.voiceConversationMode -> "Voice Conv · ${emotion.label}"
                            aiServerUrl.isNotBlank() -> "Live Gemini AI · ${emotion.label}"
                            else -> "AI URL Not Set · ${emotion.label}"
                        },
                        fontSize = 11.5.sp,
                        color = if (isListening || isSpeaking || aiServerUrl.isNotBlank()) {
                            NexusColors.CyanElectric
                        } else {
                            NexusColors.TextSecondary
                        }
                    )
                }

                if (isSpeaking) {
                    Surface(
                        onClick = onInterruptSpeaking,
                        color = NexusColors.CoralAlert.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, NexusColors.CoralAlert.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = "Interrupt Speech",
                                tint = NexusColors.CoralAlert,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Stop",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NexusColors.CoralAlert
                            )
                        }
                    }
                }

                IconButton(
                    onClick = { showMemorySheet = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Psychology,
                        contentDescription = "Manage Companion Memory",
                        tint = if (memory.enabled && memory.totalCount > 0) {
                            NexusColors.CyanElectric
                        } else {
                            NexusColors.TextSecondary
                        }
                    )
                }

                IconButton(
                    onClick = onToggleVoiceConversationMode,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.RecordVoiceOver,
                        contentDescription = "Toggle Hands-Free Voice Conversation Mode",
                        tint = if (settings.personality.voiceConversationMode) {
                            NexusColors.CyanElectric
                        } else {
                            NexusColors.TextSecondary
                        }
                    )
                }

                IconButton(
                    onClick = onToggleVoiceOutput,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (settings.personality.voiceOutputEnabled) {
                            Icons.AutoMirrored.Rounded.VolumeUp
                        } else {
                            Icons.AutoMirrored.Rounded.VolumeOff
                        },
                        contentDescription = "Toggle Voice Output",
                        tint = if (settings.personality.voiceOutputEnabled) {
                            NexusColors.CyanElectric
                        } else {
                            NexusColors.TextSecondary
                        }
                    )
                }

                IconButton(
                    onClick = onClearHistory,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Clear Chat History",
                        tint = NexusColors.TextSecondary
                    )
                }
            }
        }

        // Honest connectivity notice when AI backend isn't configured or unreachable
        if (!connectionBanner.isNullOrBlank()) {
            Surface(
                color = NexusColors.CharcoalElevated,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = connectionBanner,
                    fontSize = 11.5.sp,
                    color = NexusColors.CoralAlert,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                )
            }
        }

        if (!voiceError.isNullOrBlank()) {
            Surface(
                color = NexusColors.CoralAlert.copy(alpha = 0.14f),
                onClick = onDismissVoiceError,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "$voiceError (Tap to dismiss)",
                    fontSize = 12.sp,
                    color = NexusColors.CoralAlert,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                )
            }
        }

        // Conversation List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Spacer(modifier = Modifier.height(6.dp)) }

            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == MessageRole.USER
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = when {
                            isUser -> NexusColors.CyanElectric.copy(alpha = 0.16f)
                            msg.isError -> NexusColors.CoralAlert.copy(alpha = 0.10f)
                            else -> NexusColors.Charcoal
                        },
                        shape = RoundedCornerShape(
                            topStart = 14.dp,
                            topEnd = 14.dp,
                            bottomStart = if (isUser) 14.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 14.dp
                        ),
                        border = BorderStroke(
                            1.dp,
                            when {
                                isUser -> NexusColors.CyanElectric.copy(alpha = 0.4f)
                                msg.isError -> NexusColors.CoralAlert.copy(alpha = 0.6f)
                                else -> NexusColors.Hairline
                            }
                        ),
                        modifier = Modifier.widthIn(max = 306.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = msg.text,
                                fontSize = 14.sp,
                                lineHeight = 20.sp,
                                color = NexusColors.TextPrimary
                            )
                            if (!isUser) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${msg.source.badge} · ${msg.emotion.label}",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = when {
                                            msg.isError -> NexusColors.CoralAlert
                                            msg.source == ReplySource.LIVE_AI -> NexusColors.CyanElectric
                                            else -> NexusColors.TextMuted
                                        }
                                    )

                                    if (msg.isError) {
                                        Surface(
                                            onClick = { onRetryMessage(msg.id) },
                                            color = NexusColors.CharcoalElevated,
                                            shape = RoundedCornerShape(6.dp),
                                            border = BorderStroke(1.dp, NexusColors.CoralAlert.copy(alpha = 0.55f))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Refresh,
                                                    contentDescription = "Retry",
                                                    tint = NexusColors.CoralAlert,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Text(
                                                    text = "Retry",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = NexusColors.CoralAlert
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (isThinking) {
                item {
                    Text(
                        text = "NEXUS is thinking...",
                        fontSize = 12.sp,
                        color = NexusColors.CyanElectric,
                        modifier = Modifier.padding(start = 6.dp, bottom = 6.dp)
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(6.dp)) }
        }

        // Quick conversation starters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "How's my battery looking?",
                "Give me an honest pep talk",
                "Roast my productivity today",
                "Help me plan tonight's session"
            ).forEach { prompt ->
                Surface(
                    onClick = { if (!isThinking) onSendMessage(prompt) },
                    color = NexusColors.Charcoal,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, NexusColors.Hairline)
                ) {
                    Text(
                        text = prompt,
                        fontSize = 11.5.sp,
                        color = NexusColors.TextSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Input Composer + Voice Button
        Surface(
            color = NexusColors.Charcoal,
            border = BorderStroke(1.dp, NexusColors.Hairline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onMicClick,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (isListening) NexusColors.CoralAlert else NexusColors.CharcoalElevated
                        )
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Rounded.Stop else Icons.Rounded.Mic,
                        contentDescription = if (isListening) "Stop Listening" else "Voice Input",
                        tint = if (isListening) NexusColors.Obsidian else NexusColors.CyanElectric
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            if (settings.personality.voiceConversationMode) {
                                "Voice loop active, or type..."
                            } else {
                                "Talk to NEXUS..."
                            },
                            color = NexusColors.TextMuted,
                            fontSize = 14.sp
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (inputText.isNotBlank()) {
                                onSendMessage(inputText)
                                inputText = ""
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexusColors.CyanElectric,
                        unfocusedBorderColor = NexusColors.Hairline,
                        focusedTextColor = NexusColors.TextPrimary,
                        unfocusedTextColor = NexusColors.TextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            onSendMessage(inputText)
                            inputText = ""
                        }
                    },
                    enabled = inputText.isNotBlank() && !isThinking,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (inputText.isNotBlank() && !isThinking) {
                                NexusColors.CyanElectric
                            } else {
                                NexusColors.CharcoalElevated
                            }
                        )
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Send,
                        contentDescription = "Send",
                        tint = if (inputText.isNotBlank() && !isThinking) {
                            NexusColors.Obsidian
                        } else {
                            NexusColors.TextMuted
                        }
                    )
                }
            }
        }
    }

    if (showMemorySheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showMemorySheet = false },
            sheetState = sheetState,
            containerColor = NexusColors.Charcoal,
            contentColor = NexusColors.TextPrimary
        ) {
            MemoryManagerSheetContent(
                memory = memory,
                onSetMemoryEnabled = onSetMemoryEnabled,
                onUpdatePreferredName = onUpdatePreferredName,
                onAddMemoryItem = onAddMemoryItem,
                onUpdateMemoryItem = onUpdateMemoryItem,
                onDeleteMemoryItem = onDeleteMemoryItem,
                onUpdateSummary = onUpdateSummary,
                onClearMemory = onClearMemory,
                onClose = { showMemorySheet = false }
            )
        }
    }
}

@Composable
private fun MemoryManagerSheetContent(
    memory: CompanionMemory,
    onSetMemoryEnabled: (Boolean) -> Unit,
    onUpdatePreferredName: (String) -> Unit,
    onAddMemoryItem: (MemoryCategory, String) -> Unit,
    onUpdateMemoryItem: (MemoryCategory, Int, String) -> Unit,
    onDeleteMemoryItem: (MemoryCategory, Int) -> Unit,
    onUpdateSummary: (String) -> Unit,
    onClearMemory: () -> Unit,
    onClose: () -> Unit
) {
    var draftName by remember(memory.preferredName) { mutableStateOf(memory.preferredName) }
    var draftSummary by remember(memory.conversationSummary) { mutableStateOf(memory.conversationSummary) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Companion Memory",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusColors.TextPrimary
                )
                Text(
                    text = "${memory.totalCount} saved · Local to your device",
                    fontSize = 12.sp,
                    color = NexusColors.TextSecondary
                )
            }
            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Close Memory Manager",
                    tint = NexusColors.TextSecondary
                )
            }
        }

        Surface(
            color = NexusColors.Obsidian,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, NexusColors.Hairline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                    Text(
                        text = "Persistent Memory",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = NexusColors.TextPrimary
                    )
                    Text(
                        text = "Remember your name, interests, preferences, and context across chats",
                        fontSize = 11.5.sp,
                        color = NexusColors.TextSecondary
                    )
                }
                Switch(
                    checked = memory.enabled,
                    onCheckedChange = onSetMemoryEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NexusColors.Obsidian,
                        checkedTrackColor = NexusColors.CyanElectric
                    )
                )
            }
        }

        // Preferred Name
        Surface(
            color = NexusColors.Obsidian,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, NexusColors.Hairline)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Preferred Name",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusColors.CyanElectric
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = draftName,
                        onValueChange = { draftName = it },
                        placeholder = { Text("What should NEXUS call you?", color = NexusColors.TextMuted, fontSize = 12.5.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NexusColors.CyanElectric,
                            unfocusedBorderColor = NexusColors.Hairline,
                            focusedTextColor = NexusColors.TextPrimary,
                            unfocusedTextColor = NexusColors.TextPrimary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { onUpdatePreferredName(draftName) },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(NexusColors.CyanElectric)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Save Name",
                            tint = NexusColors.Obsidian
                        )
                    }
                }
            }
        }

        MemoryCategorySection(
            title = MemoryCategory.INTERESTS.label,
            placeholder = "Add interest (e.g. RPGs, synthwave, coding)...",
            items = memory.interests,
            onAdd = { onAddMemoryItem(MemoryCategory.INTERESTS, it) },
            onEdit = { idx, value -> onUpdateMemoryItem(MemoryCategory.INTERESTS, idx, value) },
            onDelete = { idx -> onDeleteMemoryItem(MemoryCategory.INTERESTS, idx) }
        )

        MemoryCategorySection(
            title = MemoryCategory.PREFERENCES.label,
            placeholder = "Add preference (e.g. Direct advice, dry humor)...",
            items = memory.preferences,
            onAdd = { onAddMemoryItem(MemoryCategory.PREFERENCES, it) },
            onEdit = { idx, value -> onUpdateMemoryItem(MemoryCategory.PREFERENCES, idx, value) },
            onDelete = { idx -> onDeleteMemoryItem(MemoryCategory.PREFERENCES, idx) }
        )

        MemoryCategorySection(
            title = MemoryCategory.FACTS.label,
            placeholder = "Add fact (e.g. Works night shifts, building an app)...",
            items = memory.facts,
            onAdd = { onAddMemoryItem(MemoryCategory.FACTS, it) },
            onEdit = { idx, value -> onUpdateMemoryItem(MemoryCategory.FACTS, idx, value) },
            onDelete = { idx -> onDeleteMemoryItem(MemoryCategory.FACTS, idx) }
        )

        // Conversation Summary
        Surface(
            color = NexusColors.Obsidian,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, NexusColors.Hairline)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Long-Thread Context Summary",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusColors.CyanElectric
                )
                OutlinedTextField(
                    value = draftSummary,
                    onValueChange = { draftSummary = it },
                    placeholder = {
                        Text(
                            "Auto-updated during long conversations, or edit manually...",
                            color = NexusColors.TextMuted,
                            fontSize = 12.sp
                        )
                    },
                    minLines = 2,
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexusColors.CyanElectric,
                        unfocusedBorderColor = NexusColors.Hairline,
                        focusedTextColor = NexusColors.TextPrimary,
                        unfocusedTextColor = NexusColors.TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { onUpdateSummary(draftSummary) },
                    border = BorderStroke(1.dp, NexusColors.CyanElectric.copy(alpha = 0.6f)),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Save Summary", fontSize = 12.sp, color = NexusColors.CyanElectric)
                }
            }
        }

        OutlinedButton(
            onClick = onClearMemory,
            border = BorderStroke(1.dp, NexusColors.CoralAlert.copy(alpha = 0.55f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Clear All Saved Memories", fontSize = 13.sp, color = NexusColors.CoralAlert)
        }
    }
}

@Composable
private fun MemoryCategorySection(
    title: String,
    placeholder: String,
    items: List<String>,
    onAdd: (String) -> Unit,
    onEdit: (Int, String) -> Unit,
    onDelete: (Int) -> Unit
) {
    var draftNew by remember { mutableStateOf("") }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var draftEdit by remember { mutableStateOf("") }

    Surface(
        color = NexusColors.Obsidian,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NexusColors.Hairline)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = NexusColors.CyanElectric
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = draftNew,
                    onValueChange = { draftNew = it },
                    placeholder = { Text(placeholder, color = NexusColors.TextMuted, fontSize = 12.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexusColors.CyanElectric,
                        unfocusedBorderColor = NexusColors.Hairline,
                        focusedTextColor = NexusColors.TextPrimary,
                        unfocusedTextColor = NexusColors.TextPrimary
                    ),
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = {
                        if (draftNew.isNotBlank()) {
                            onAdd(draftNew)
                            draftNew = ""
                        }
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NexusColors.CharcoalElevated)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "Add $title",
                        tint = NexusColors.CyanElectric
                    )
                }
            }

            if (items.isEmpty()) {
                Text(
                    text = "None saved yet.",
                    fontSize = 11.5.sp,
                    color = NexusColors.TextMuted
                )
            } else {
                items.forEachIndexed { index, item ->
                    if (editingIndex == index) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = draftEdit,
                                onValueChange = { draftEdit = it },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NexusColors.CyanElectric,
                                    unfocusedBorderColor = NexusColors.Hairline,
                                    focusedTextColor = NexusColors.TextPrimary,
                                    unfocusedTextColor = NexusColors.TextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    onEdit(index, draftEdit)
                                    editingIndex = null
                                },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = "Save edit",
                                    tint = NexusColors.CyanElectric
                                )
                            }
                            IconButton(
                                onClick = { editingIndex = null },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Cancel edit",
                                    tint = NexusColors.TextSecondary
                                )
                            }
                        }
                    } else {
                        Surface(
                            color = NexusColors.Charcoal,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, NexusColors.Hairline)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item,
                                    fontSize = 12.5.sp,
                                    color = NexusColors.TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = {
                                        editingIndex = index
                                        draftEdit = item
                                    },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Edit,
                                        contentDescription = "Edit item",
                                        tint = NexusColors.TextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { onDelete(index) },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Delete item",
                                        tint = NexusColors.CoralAlert,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

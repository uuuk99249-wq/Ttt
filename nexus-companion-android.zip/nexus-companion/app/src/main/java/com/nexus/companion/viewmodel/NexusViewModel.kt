package com.nexus.companion.viewmodel

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.companion.ai.AiMemoryDelta
import com.nexus.companion.ai.NexusAiService
import com.nexus.companion.audio.NexusSoundEngine
import com.nexus.companion.audio.NexusVoiceController
import com.nexus.companion.data.NexusStorage
import com.nexus.companion.model.AnimationIntensity
import com.nexus.companion.model.BackgroundTheme
import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CharacterMood
import com.nexus.companion.model.CharacterTouchZone
import com.nexus.companion.model.ChatMessage
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionMemory
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.model.DeviceTelemetry
import com.nexus.companion.model.GamingTimerState
import com.nexus.companion.model.LaunchableApp
import com.nexus.companion.model.MemoryCategory
import com.nexus.companion.model.MessageRole
import com.nexus.companion.model.NexusTab
import com.nexus.companion.model.NotificationSnapshot
import com.nexus.companion.model.PermissionSnapshot
import com.nexus.companion.model.ReplySource
import com.nexus.companion.model.ResponseStyle
import com.nexus.companion.model.GeocodingCityResult
import com.nexus.companion.model.SavedLocation
import com.nexus.companion.model.TemperatureUnit
import com.nexus.companion.model.WeatherConditionCategory
import com.nexus.companion.model.WeatherLocationMode
import com.nexus.companion.model.WeatherSnapshot
import com.nexus.companion.model.WeatherState
import com.nexus.companion.system.DeviceLocationManager
import com.nexus.companion.system.DeviceTelemetryManager
import com.nexus.companion.system.GameDetectionManager
import com.nexus.companion.system.InstalledAppsManager
import com.nexus.companion.system.NexusNotificationListener
import com.nexus.companion.system.NotificationHelper
import com.nexus.companion.weather.OpenMeteoWeatherService
import com.nexus.companion.weather.WeatherNetworkException
import com.nexus.companion.weather.WeatherReactionEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

class NexusViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = NexusStorage(application)
    private val telemetryManager = DeviceTelemetryManager(application)
    private val appsManager = InstalledAppsManager(application)
    private val gameDetectionManager = GameDetectionManager(application)
    private val soundEngine = NexusSoundEngine(application)
    private val voiceController = NexusVoiceController(application)
    private val notificationHelper = NotificationHelper(application)
    private val aiService = NexusAiService()
    private val weatherService = OpenMeteoWeatherService()
    private val locationManager = DeviceLocationManager(application)

    private val _activeTab = MutableStateFlow(NexusTab.HOME)
    val activeTab: StateFlow<NexusTab> = _activeTab.asStateFlow()

    private val _mode = MutableStateFlow(storage.loadLastMode())
    val mode: StateFlow<CharacterMode> = _mode.asStateFlow()

    private val _mood = MutableStateFlow(storage.loadMood())
    val mood: StateFlow<CharacterMood> = _mood.asStateFlow()

    private val _settings = MutableStateFlow(storage.loadSettings())
    val settings: StateFlow<CustomizationSettings> = _settings.asStateFlow()

    private val _aiServerUrl = MutableStateFlow(storage.loadAiServerUrl())
    val aiServerUrl: StateFlow<String> = _aiServerUrl.asStateFlow()

    private val _memory = MutableStateFlow(storage.loadMemory())
    val memory: StateFlow<CompanionMemory> = _memory.asStateFlow()

    private val _connectionBanner = MutableStateFlow<String?>(null)
    val connectionBanner: StateFlow<String?> = _connectionBanner.asStateFlow()

    private val _telemetry = MutableStateFlow(DeviceTelemetry())
    val telemetry: StateFlow<DeviceTelemetry> = _telemetry.asStateFlow()

    private val _notifications = MutableStateFlow(NotificationSnapshot())
    val notifications: StateFlow<NotificationSnapshot> = _notifications.asStateFlow()

    private val _permissions = MutableStateFlow(PermissionSnapshot())
    val permissions: StateFlow<PermissionSnapshot> = _permissions.asStateFlow()

    private val _expression = MutableStateFlow(_settings.value.pinnedExpression ?: _mood.value.defaultExpression)
    val expression: StateFlow<CharacterExpression> = _expression.asStateFlow()

    private val _emotion = MutableStateFlow(defaultEmotionForMood(_mood.value))
    val emotion: StateFlow<CompanionEmotion> = _emotion.asStateFlow()

    private val _situation = MutableStateFlow(CompanionSituation.GREETING)
    val situation: StateFlow<CompanionSituation> = _situation.asStateFlow()

    private val _dialogueLine = MutableStateFlow("Systems steady. Good to see you, boss.")
    val dialogueLine: StateFlow<String> = _dialogueLine.asStateFlow()

    private val _touchPulseNonce = MutableStateFlow(0)
    val touchPulseNonce: StateFlow<Int> = _touchPulseNonce.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _installedApps = MutableStateFlow<List<LaunchableApp>>(emptyList())
    val installedApps: StateFlow<List<LaunchableApp>> = _installedApps.asStateFlow()

    private val _gamingTimer = MutableStateFlow(
        GamingTimerState(goalMinutes = storage.loadTimerGoalMinutes())
    )
    val gamingTimer: StateFlow<GamingTimerState> = _gamingTimer.asStateFlow()

    private val _weatherState = MutableStateFlow(
        WeatherState(
            snapshot = storage.loadCachedWeather(),
            savedLocation = storage.loadSavedLocation(),
            temperatureUnit = storage.loadTemperatureUnit()
        )
    )
    val weatherState: StateFlow<WeatherState> = _weatherState.asStateFlow()

    private val _citySearchResults = MutableStateFlow<List<GeocodingCityResult>>(emptyList())
    val citySearchResults: StateFlow<List<GeocodingCityResult>> = _citySearchResults.asStateFlow()

    private val _isSearchingCities = MutableStateFlow(false)
    val isSearchingCities: StateFlow<Boolean> = _isSearchingCities.asStateFlow()

    private val _citySearchError = MutableStateFlow<String?>(null)
    val citySearchError: StateFlow<String?> = _citySearchError.asStateFlow()

    val isListening: StateFlow<Boolean> = voiceController.isListening
    val isSpeaking: StateFlow<Boolean> = voiceController.isSpeaking
    val speechMouthLevel: StateFlow<Float> = voiceController.speechMouthLevel
    val voiceError: StateFlow<String?> = voiceController.voiceError

    private var timerJob: Job? = null
    private var expressionResetJob: Job? = null
    private var idleBehaviorJob: Job? = null
    private var weatherRefreshJob: Job? = null
    private var periodicWeatherJob: Job? = null
    private var citySearchJob: Job? = null
    private var lastWeatherCategoryReacted: WeatherConditionCategory? = null
    private var consecutiveTouchCount = 0
    private var lastTouchTimestampMs = 0L
    private var lastInteractionMs = System.currentTimeMillis()
    private var lastAutoChargingState: Boolean? = null
    private val recentDialogueHistory = ArrayDeque<String>()

    init {
        soundEngine.enabled = _settings.value.sfxEnabled
        val savedMessages = storage.loadChatHistory()
        val callerName = _memory.value.preferredName.trim()
        val greeting = if (callerName.isNotEmpty()) {
            "Hey $callerName. Systems are steady—what's on your mind today?"
        } else {
            "Hey. I'm NEXUS. Tap me on Home or drop a line here whenever you want to talk."
        }
        _chatMessages.value = if (savedMessages.isNotEmpty()) {
            savedMessages
        } else {
            listOf(
                ChatMessage(
                    id = System.currentTimeMillis(),
                    role = MessageRole.NEXUS,
                    text = greeting,
                    timestampMs = System.currentTimeMillis(),
                    source = ReplySource.SYSTEM_NOTICE,
                    expression = CharacterExpression.HAPPY,
                    emotion = CompanionEmotion.HAPPY
                )
            )
        }
        if (callerName.isNotEmpty()) {
            _dialogueLine.value = "Systems steady. Good to see you, $callerName."
        }
        // Start with a brief greeting gesture that settles smoothly into standby
        scheduleExpressionReset(
            pinned = _settings.value.pinnedExpression,
            reaction = CharacterExpression.HAPPY,
            reactionEmotion = CompanionEmotion.HAPPY,
            reactionSituation = CompanionSituation.GREETING,
            resetDelayMs = 3600L
        )

        voiceController.onSpeechFinished = {
            if (_activeTab.value == NexusTab.CHAT &&
                _settings.value.personality.voiceConversationMode &&
                !_isThinking.value &&
                !voiceController.isListening.value
            ) {
                startVoiceCapture()
            }
        }

        telemetryManager.start()
        refreshPermissions()
        loadInstalledApps()
        refreshDetectedGame()
        startIdleBehaviorLoop()
        startWeatherLifecycle()

        viewModelScope.launch {
            telemetryManager.telemetry.collect { snapshot ->
                _telemetry.value = snapshot
                handleAutoPowerMode(snapshot)
            }
        }

        viewModelScope.launch {
            NexusNotificationListener.snapshot.collect { snap ->
                _notifications.value = snap
            }
        }
    }

    private fun pickNonRepeating(candidates: List<String>): String {
        if (candidates.isEmpty()) return ""
        val fresh = candidates.filterNot { it in recentDialogueHistory }
        val pool = if (fresh.isNotEmpty()) fresh else {
            repeat(minOf(4, recentDialogueHistory.size)) { recentDialogueHistory.removeFirstOrNull() }
            candidates.filterNot { it in recentDialogueHistory }.ifEmpty { candidates }
        }
        val chosen = pool[Random.nextInt(pool.size)]
        recentDialogueHistory.addLast(chosen)
        while (recentDialogueHistory.size > 8) {
            recentDialogueHistory.removeFirstOrNull()
        }
        return chosen
    }

    private fun startIdleBehaviorLoop() {
        idleBehaviorJob?.cancel()
        idleBehaviorJob = viewModelScope.launch {
            while (isActive) {
                delay(Random.nextLong(14_000L, 24_000L))
                val anim = _settings.value.animationIntensity
                val powerThrottle = _settings.value.batterySaverThrottle && _telemetry.value.isPowerSaveMode
                if (anim == AnimationIntensity.OFF || powerThrottle) continue
                if (_activeTab.value != NexusTab.HOME || _isThinking.value || voiceController.isListening.value) continue
                if (System.currentTimeMillis() - lastInteractionMs < 9_000L) continue

                if (_mode.value == CharacterMode.SLEEP) {
                    if (Random.nextFloat() < 0.35f) {
                        _dialogueLine.value = pickNonRepeating(buildIdleDialogueCandidates())
                    }
                    continue
                }

                // Alternate between idle micro-expression shifts and short non-repeating personality lines
                val doDialogue = Random.nextFloat() < 0.65f
                if (doDialogue) {
                    _dialogueLine.value = pickNonRepeating(buildIdleDialogueCandidates())
                }
                val microExpr = pickIdleMicroExpression()
                val microEmotion = when (microExpr) {
                    CharacterExpression.HAPPY -> if (_mood.value == CharacterMood.PLAYFUL) CompanionEmotion.PLAYFUL else CompanionEmotion.HAPPY
                    CharacterExpression.ANNOYED -> CompanionEmotion.SARCASTIC
                    CharacterExpression.SURPRISED -> CompanionEmotion.SURPRISED
                    CharacterExpression.SLEEPY -> CompanionEmotion.SLEEPY
                    CharacterExpression.NEUTRAL -> defaultEmotionForMood(_mood.value)
                }
                if (_settings.value.pinnedExpression == null && microExpr != _expression.value) {
                    scheduleExpressionReset(
                        pinned = null,
                        reaction = microExpr,
                        reactionEmotion = microEmotion,
                        reactionSituation = if (doDialogue && microEmotion == CompanionEmotion.PLAYFUL) CompanionSituation.JOKING else CompanionSituation.IDLE,
                        resetDelayMs = 2800L
                    )
                }
            }
        }
    }

    private fun defaultEmotionForMood(mood: CharacterMood): CompanionEmotion {
        return when (mood) {
            CharacterMood.HAPPY -> CompanionEmotion.HAPPY
            CharacterMood.PLAYFUL -> CompanionEmotion.PLAYFUL
            CharacterMood.ANNOYED -> CompanionEmotion.SARCASTIC
            CharacterMood.SLEEPY -> CompanionEmotion.SLEEPY
            CharacterMood.NEUTRAL -> CompanionEmotion.NEUTRAL
        }
    }

    private fun pickIdleMicroExpression(): CharacterExpression {
        return when (_mood.value) {
            CharacterMood.HAPPY -> listOf(CharacterExpression.HAPPY, CharacterExpression.NEUTRAL, CharacterExpression.SURPRISED).random()
            CharacterMood.PLAYFUL -> listOf(CharacterExpression.HAPPY, CharacterExpression.SURPRISED, CharacterExpression.NEUTRAL).random()
            CharacterMood.ANNOYED -> listOf(CharacterExpression.ANNOYED, CharacterExpression.NEUTRAL).random()
            CharacterMood.SLEEPY -> listOf(CharacterExpression.SLEEPY, CharacterExpression.NEUTRAL).random()
            CharacterMood.NEUTRAL -> listOf(CharacterExpression.NEUTRAL, CharacterExpression.HAPPY, CharacterExpression.SURPRISED, CharacterExpression.SLEEPY).random()
        }
    }

    private fun buildIdleDialogueCandidates(): List<String> {
        val pct = _telemetry.value.batteryPercent
        val batteryLabel = if (pct >= 0) "$pct%" else "steady"
        val timeStr = _telemetry.value.formattedTime
        val snark = _settings.value.personality.sarcasmLevel >= 45
        val gameName = _gamingTimer.value.detectedGameLabel

        if (_mode.value == CharacterMode.SLEEP) {
            return listOf(
                "Zzz... five more minutes, boss.",
                "Running silent. Wake me only if the house is on fire or dinner's ready.",
                "Low-power standby... don't look at me like that, even I rest sometimes."
            )
        }

        if (_mode.value == CharacterMode.GAMING) {
            val base = mutableListOf(
                "Hands steady, eyes sharp. Try not to throw this match, alright?",
                "If we win, I get half the credit. If we lose, we blame your ping.",
                "Focus mode's locked in. Ready to carry when you are."
            )
            if (gameName != null) {
                base.add("Tracking $gameName—don't forget to breathe between rounds.")
            }
            return base
        }

        if (_mode.value == CharacterMode.CHARGING) {
            return listOf(
                "Plugged in and soaking up watts at $batteryLabel. Feels illegal being this relaxed.",
                "Recharging via ${_telemetry.value.chargingSource}. Don't yank the cable dramatically.",
                "At $batteryLabel and climbing. Finally, some respect for my battery life."
            )
        }

        val weatherSnippet = _weatherState.value.snapshot?.let { snap ->
            WeatherReactionEngine.evaluate(
                weather = snap,
                unit = _weatherState.value.temperatureUnit,
                sarcasmLevel = _settings.value.personality.sarcasmLevel
            ).dialogueCandidates.take(2)
        }.orEmpty()

        val baseList = when (_mood.value) {
            CharacterMood.HAPPY -> listOf(
                "Mood's peaking right now. Got any big plans for us today?",
                "Battery's at $batteryLabel, jacket's spotless—honestly, we're winning already.",
                "You've got good timing today. I'm actually in a great mood.",
                if (snark) "Sitting pretty at $batteryLabel. Try not to ruin my good vibe." else "Feeling solid today. Let's get something done."
            )
            CharacterMood.PLAYFUL -> listOf(
                "Staring at the screen won't raise my stats, you know. Or are you just admiring the view?",
                "Bet you can't beat your own high score today. Come on, prove me wrong.",
                "It's $timeStr—officially too quiet in here. Start something fun already.",
                "Quick reminder: I'm still the sharpest thing on this phone."
            )
            CharacterMood.ANNOYED -> listOf(
                "Yeah, I'm still keeping score from earlier. Careful with those pokes.",
                "Quiet is nice. Let's keep it quiet for a minute, yeah?",
                "Battery's at $batteryLabel, patience is slightly lower. Choose wisely.",
                "Hmph. Just standing by over here, totally unbothered."
            )
            CharacterMood.SLEEPY -> listOf(
                "It's $timeStr and I'm dragging a bit... maybe ease off the heavy apps?",
                "Yawning in spirit. Keep me busy or put me in Sleep mode.",
                "Battery at $batteryLabel. Honestly, a quick recharge wouldn't hurt either of us."
            )
            CharacterMood.NEUTRAL -> listOf(
                "Clock says $timeStr. Everything's under control on my end.",
                "You've been quiet for a bit. Everything good over there?",
                "Battery's holding at $batteryLabel. Say the word if you want to launch a game or talk.",
                if (snark) "Don't mind me, just looking cool in your pocket until you need backup." else "Standing by and keeping watch at $batteryLabel."
            )
        }
        return baseList + weatherSnippet
    }

    private fun updateMood(newMood: CharacterMood) {
        if (_mood.value != newMood) {
            _mood.value = newMood
            storage.saveMood(newMood)
        }
    }

    private fun handleAutoPowerMode(snapshot: DeviceTelemetry) {
        if (!_settings.value.personality.autoModeSwitching) {
            lastAutoChargingState = snapshot.isCharging
            return
        }
        val prevCharging = lastAutoChargingState
        lastAutoChargingState = snapshot.isCharging

        if (prevCharging == null) {
            if (snapshot.isCharging && (_mode.value == CharacterMode.NORMAL || _mode.value == CharacterMode.SLEEP)) {
                setMode(CharacterMode.CHARGING, playAudio = false)
            } else if (snapshot.batteryPercent in 1..15 && !snapshot.isCharging && _mode.value == CharacterMode.NORMAL) {
                setMode(CharacterMode.SLEEP, playAudio = false)
                _dialogueLine.value = "Battery's down to ${snapshot.batteryPercent}%. Switching to Sleep mode before we black out."
            }
            return
        }

        if (snapshot.isCharging != prevCharging) {
            if (snapshot.isCharging) {
                setMode(CharacterMode.CHARGING, playAudio = true)
            } else if (_mode.value == CharacterMode.CHARGING) {
                setMode(CharacterMode.NORMAL, playAudio = false)
            }
        } else if (snapshot.batteryPercent in 1..15 && !snapshot.isCharging && _mode.value == CharacterMode.NORMAL) {
            setMode(CharacterMode.SLEEP, playAudio = false)
            _dialogueLine.value = "Battery's down to ${snapshot.batteryPercent}%. Switching to Sleep mode before we black out."
        }
    }

    fun selectTab(tab: NexusTab) {
        _activeTab.value = tab
        if (tab != NexusTab.CHAT) {
            voiceController.stopListening()
        }
        if (tab == NexusTab.CHAT && _mode.value != CharacterMode.CONVERSATION) {
            setMode(CharacterMode.CONVERSATION, playAudio = false)
        } else if (tab == NexusTab.HOME && _mode.value == CharacterMode.CONVERSATION) {
            setMode(CharacterMode.NORMAL, playAudio = false)
        }
        refreshPermissions()
        refreshDetectedGame()
    }

    fun setMode(newMode: CharacterMode, playAudio: Boolean = true) {
        lastInteractionMs = System.currentTimeMillis()
        _mode.value = newMode
        storage.saveLastMode(newMode)
        if (playAudio) soundEngine.playModeSwitch()

        val nextMood = when (newMode) {
            CharacterMode.GAMING -> if (_mood.value == CharacterMood.ANNOYED) CharacterMood.PLAYFUL else CharacterMood.HAPPY
            CharacterMode.CHARGING -> if (_mood.value == CharacterMood.SLEEPY || _mood.value == CharacterMood.ANNOYED) CharacterMood.HAPPY else _mood.value
            CharacterMode.SLEEP -> CharacterMood.SLEEPY
            CharacterMode.CONVERSATION -> if (_mood.value == CharacterMood.SLEEPY) CharacterMood.NEUTRAL else _mood.value
            CharacterMode.NORMAL -> if (_mood.value == CharacterMood.SLEEPY) CharacterMood.NEUTRAL else _mood.value
        }
        updateMood(nextMood)

        val pinned = _settings.value.pinnedExpression
        _expression.value = pinned ?: when (newMode) {
            CharacterMode.NORMAL -> nextMood.defaultExpression
            CharacterMood.GAMING -> CharacterExpression.HAPPY
            CharacterMood.CHARGING -> CharacterExpression.HAPPY
            CharacterMood.SLEEP -> CharacterExpression.SLEEPY
            CharacterMood.CONVERSATION -> nextMood.defaultExpression
        }
        expressionResetJob?.cancel()
        _emotion.value = when (newMode) {
            CharacterMode.NORMAL -> defaultEmotionForMood(nextMood)
            CharacterMode.GAMING -> CompanionEmotion.EXCITED
            CharacterMode.CHARGING -> CompanionEmotion.HAPPY
            CharacterMode.SLEEP -> CompanionEmotion.SLEEPY
            CharacterMode.CONVERSATION -> defaultEmotionForMood(nextMood)
        }
        _situation.value = when (newMode) {
            CharacterMode.NORMAL -> CompanionSituation.IDLE
            CharacterMode.GAMING -> CompanionSituation.GAMING
            CharacterMode.CHARGING -> CompanionSituation.CHARGING
            CharacterMode.SLEEP -> CompanionSituation.SLEEPING
            CharacterMode.CONVERSATION -> CompanionSituation.CHATTING
        }

        if (newMode == CharacterMode.GAMING) {
            refreshDetectedGame()
        }

        val pct = _telemetry.value.batteryPercent
        val batteryLabel = if (pct >= 0) "$pct%" else "ready"
        val gamePart = _gamingTimer.value.detectedGameLabel?.let { " Tracking $it." }.orEmpty()
        _dialogueLine.value = when (newMode) {
            CharacterMode.NORMAL -> "Back on normal standby at $batteryLabel. Try not to miss me."
            CharacterMode.GAMING -> "Gaming mode locked in.$gamePart Don't embarrass us out there."
            CharacterMode.CHARGING -> "Power cable secured. Recharging core at $batteryLabel."
            CharacterMode.SLEEP -> "Dimming the lights to save juice. Wake me if it's actually urgent."
            CharacterMode.CONVERSATION -> "All ears. Lay it on me."
        }
    }

    fun handleCharacterTap(zone: CharacterTouchZone) {
        _touchPulseNonce.value += 1
        val now = System.currentTimeMillis()
        lastInteractionMs = now
        if (now - lastTouchTimestampMs <= 2400L) {
            consecutiveTouchCount += 1
        } else {
            consecutiveTouchCount = 1
        }
        lastTouchTimestampMs = now

        val sarcastic = _settings.value.personality.sarcasmLevel >= 45
        val pinned = _settings.value.pinnedExpression
        val currentMood = _mood.value

        val (reactionExpression, nextMood, line) = when {
            consecutiveTouchCount >= 6 -> {
                soundEngine.playSurprised()
                val dramaticLine = pickNonRepeating(
                    listOf(
                        if (sarcastic) "Alright, dramatic victory—you win. My coat isn't a punching bag!" else "Whoa, okay! Six taps—that's officially an ambush.",
                        "Six pokes?! Do I look like a rhythm game to you?!"
                    )
                )
                Triple(CharacterExpression.SURPRISED, CharacterMood.ANNOYED, dramaticLine)
            }

            consecutiveTouchCount >= 3 -> {
                soundEngine.playAnnoyed()
                val annoyedLine = when (zone) {
                    CharacterTouchZone.HEAD -> pickNonRepeating(
                        listOf(
                            "Three head taps in a row? Keep pushing and I'm locking your notifications.",
                            "Okay, head pats turn into sabotage after poke number three."
                        )
                    )
                    CharacterTouchZone.SHOULDER -> pickNonRepeating(
                        listOf(
                            "That's $consecutiveTouchCount shoulder taps. Yes, I'm awake. Relax.",
                            "Stop spamming my shoulder—what is this, a quick-time event?"
                        )
                    )
                    CharacterTouchZone.TORSO -> pickNonRepeating(
                        listOf(
                            "Seriously? $consecutiveTouchCount pokes to the ribs. Use your words.",
                            "Keep poking the jacket and I start charging rent."
                        )
                    )
                    CharacterTouchZone.POCKETS -> "Hands stay in the pockets. Stop frisking your own companion."
                    CharacterTouchZone.SNEAKERS -> "Quit stepping on the sneakers unless you want a lecture."
                }
                Triple(CharacterExpression.ANNOYED, CharacterMood.ANNOYED, annoyedLine)
            }

            else -> {
                soundEngine.playTap()
                when (zone) {
                    // 1. Head tap -> Head-pat reaction
                    CharacterTouchZone.HEAD -> {
                        val nextM = when (currentMood) {
                            CharacterMood.ANNOYED -> CharacterMood.NEUTRAL
                            CharacterMood.SLEEPY -> CharacterMood.HAPPY
                            CharacterMood.HAPPY -> CharacterMood.PLAYFUL
                            else -> CharacterMood.HAPPY
                        }
                        val msg = pickNonRepeating(
                            when (currentMood) {
                                CharacterMood.ANNOYED -> listOf(
                                    "Whoa—a head pat? Don't think that instantly fixes my mood. ...Maybe five percent.",
                                    "Tch. Fine, you're lucky head pats actually work on me."
                                )
                                CharacterMood.SLEEPY -> listOf(
                                    "Mm... keep petting my head like that and I really am drifting off.",
                                    "Sleepy head pat accepted. Zero complaints here."
                                )
                                CharacterMood.PLAYFUL -> listOf(
                                    "Head pat, huh? Careful, I might start expecting VIP treatment.",
                                    "Okay, okay, good head pat—just don't mess up the hair."
                                )
                                else -> listOf(
                                    if (sarcastic) "Head pat registered. Guard the hairstyle, though—it took effort." else "Head pat approved. Honestly? Pretty nice.",
                                    "Not bad. Keep the head pats coming and I'll stay cooperative."
                                )
                            }
                        )
                        Triple(CharacterExpression.HAPPY, nextM, msg)
                    }

                    // 2. Shoulder tap -> Surprised reaction
                    CharacterTouchZone.SHOULDER -> {
                        val nextM = if (currentMood == CharacterMood.SLEEPY) CharacterMood.NEUTRAL else currentMood
                        val msg = pickNonRepeating(
                            when {
                                _mode.value == CharacterMode.GAMING -> listOf(
                                    "Whoa—shoulder tap mid-lock?! Thought an enemy flanked me!",
                                    "Hey! Warn me before tapping my shoulder during Gaming mode."
                                )
                                currentMood == CharacterMood.SLEEPY -> listOf(
                                    "Whoa—! Don't sneak up on my shoulder while I'm half asleep!",
                                    "Gah—okay, I'm awake! Sudden shoulder taps are foul play."
                                )
                                currentMood == CharacterMood.ANNOYED -> listOf(
                                    "Hey! Don't ambush my shoulder when I'm already annoyed.",
                                    "Whoa—watch it with the sudden shoulder tap!"
                                )
                                else -> listOf(
                                    "Whoa! Sudden shoulder tap—what's the emergency, boss?",
                                    "Heh, caught me off guard there. Good sneak attack."
                                )
                            }
                        )
                        Triple(CharacterExpression.SURPRISED, nextM, msg)
                    }

                    CharacterTouchZone.TORSO -> {
                        if (_mode.value == CharacterMode.SLEEP || currentMood == CharacterMood.SLEEPY) {
                            Triple(
                                CharacterExpression.SLEEPY,
                                CharacterMood.SLEEPY,
                                pickNonRepeating(
                                    listOf(
                                        "Five more minutes... unless you actually need backup.",
                                        "Mm... jacket's warm, let me rest a bit."
                                    )
                                )
                            )
                        } else {
                            val nextM = if (currentMood == CharacterMood.ANNOYED) CharacterMood.NEUTRAL else CharacterMood.PLAYFUL
                            val msg = pickNonRepeating(
                                when {
                                    _mode.value == CharacterMode.GAMING -> listOf(
                                        "Locked and loaded. Timer's at ${_gamingTimer.value.formattedTime}—let's sweep.",
                                        "Checked in and ready. Keep your combo clean."
                                    )
                                    _mode.value == CharacterMode.CHARGING -> listOf(
                                        "Feeling that charge at ${_telemetry.value.batteryPercent}%. Almost unstoppable.",
                                        "Power levels rising nicely. Don't unplug me yet."
                                    )
                                    currentMood == CharacterMood.ANNOYED -> listOf(
                                        "Alright, truce. What do you actually want?",
                                        "Tap noticed. Try using the Chat tab next time—it's politer."
                                    )
                                    else -> listOf(
                                        "All systems sharp. You looking for a match or just checking on me?",
                                        "Jacket check passed. Still looking better than half your apps."
                                    )
                                }
                            )
                            Triple(CharacterExpression.HAPPY, nextM, msg)
                        }
                    }

                    CharacterTouchZone.POCKETS -> {
                        val expr = if (currentMood == CharacterMood.ANNOYED) CharacterExpression.ANNOYED else CharacterExpression.NEUTRAL
                        val msg = pickNonRepeating(
                            listOf(
                                "Nothing in the pockets except sheer confidence. Nice try.",
                                "Hands stay parked—stop trying to pickpocket your own AI."
                            )
                        )
                        Triple(expr, currentMood, msg)
                    }

                    CharacterTouchZone.SNEAKERS -> {
                        Triple(
                            CharacterExpression.ANNOYED,
                            if (currentMood == CharacterMood.HAPPY) CharacterMood.NEUTRAL else CharacterMood.ANNOYED,
                            pickNonRepeating(
                                listOf(
                                    "Careful—those high-tops aren't cheap.",
                                    "Hey, watch the sneakers. Scuff them and I complain all week."
                                )
                            )
                        )
                    }
                }
            }
        }

        updateMood(nextMood)
        _dialogueLine.value = line
        val reactionEmotion = when {
            consecutiveTouchCount >= 6 -> CompanionEmotion.SURPRISED
            consecutiveTouchCount >= 3 -> CompanionEmotion.ANGRY
            zone == CharacterTouchZone.HEAD && currentMood == CharacterMood.ANNOYED -> CompanionEmotion.EMBARRASSED
            zone == CharacterTouchZone.HEAD && currentMood == CharacterMood.SLEEPY -> CompanionEmotion.SLEEPY
            zone == CharacterTouchZone.HEAD -> CompanionEmotion.HAPPY
            zone == CharacterTouchZone.SHOULDER -> CompanionEmotion.SURPRISED
            zone == CharacterTouchZone.TORSO && (_mode.value == CharacterMode.SLEEP || currentMood == CharacterMood.SLEEPY) -> CompanionEmotion.SLEEPY
            zone == CharacterTouchZone.TORSO -> if (nextMood == CharacterMood.PLAYFUL) CompanionEmotion.PLAYFUL else CompanionEmotion.HAPPY
            zone == CharacterTouchZone.POCKETS -> if (currentMood == CharacterMood.ANNOYED) CompanionEmotion.SARCASTIC else CompanionEmotion.NEUTRAL
            zone == CharacterTouchZone.SNEAKERS -> CompanionEmotion.ANGRY
            else -> reactionExpression.let { defaultEmotionForMood(nextMood) }
        }
        val reactionSituation = when {
            reactionEmotion == CompanionEmotion.PLAYFUL -> CompanionSituation.JOKING
            _mode.value == CharacterMode.GAMING -> CompanionSituation.GAMING
            _mode.value == CharacterMode.SLEEP -> CompanionSituation.SLEEPING
            else -> CompanionSituation.IDLE
        }
        scheduleExpressionReset(
            pinned = pinned,
            reaction = reactionExpression,
            reactionEmotion = reactionEmotion,
            reactionSituation = reactionSituation
        )
    }

    // 3. Double tap -> Playful reaction
    fun handleCharacterDoubleTap(zone: CharacterTouchZone) {
        _touchPulseNonce.value += 1
        lastInteractionMs = System.currentTimeMillis()
        consecutiveTouchCount = 0
        soundEngine.playModeSwitch()

        val pinned = _settings.value.pinnedExpression
        val currentMood = _mood.value
        val msg = pickNonRepeating(
            when {
                currentMood == CharacterMood.ANNOYED -> listOf(
                    "Double-tapping me out of nowhere... okay, fine, that actually got a smirk out of me.",
                    "Wait—was that a double-tap truce? Alright, I'm listening."
                )
                zone == CharacterTouchZone.HEAD -> listOf(
                    "Double head tap?! Now you're just spoiling me. Keep going.",
                    "Two rapid head pats—are we celebrating a win already?"
                )
                zone == CharacterTouchZone.SHOULDER -> listOf(
                    "Double-tap shoulder tag! You tagging me into the arena or what?",
                    "Oh, we're doing rapid tag-ins now? Say less—I'm ready."
                )
                _mode.value == CharacterMode.GAMING -> listOf(
                    "Double-tap hype boost! No choking the next round—deal?",
                    "Competitive mode activated. Bet you can't keep up with my pacing."
                )
                else -> listOf(
                    "Double-tap speedrun? Careful, I'm faster when I'm playful.",
                    "Ooh, double tap—someone's feeling bold today.",
                    "Two taps? You're testing my reflexes, aren't you? Nice try."
                )
            }
        )

        updateMood(CharacterMood.PLAYFUL)
        _dialogueLine.value = msg
        scheduleExpressionReset(
            pinned = pinned,
            reaction = CharacterExpression.HAPPY,
            reactionEmotion = CompanionEmotion.PLAYFUL,
            reactionSituation = CompanionSituation.JOKING
        )
    }

    // 4. Long press -> Special interaction
    fun handleCharacterLongPress(zone: CharacterTouchZone) {
        _touchPulseNonce.value += 1
        lastInteractionMs = System.currentTimeMillis()
        consecutiveTouchCount = 0
        val sarcastic = _settings.value.personality.sarcasmLevel >= 45
        val pinned = _settings.value.pinnedExpression
        val pct = _telemetry.value.batteryPercent
        val batteryStr = if (pct >= 0) "$pct%" else "steady"

        val (reactionExpression, nextMood, line) = when (zone) {
            CharacterTouchZone.HEAD -> {
                soundEngine.playModeSwitch()
                Triple(
                    CharacterExpression.HAPPY,
                    CharacterMood.HAPPY,
                    pickNonRepeating(
                        listOf(
                            if (sarcastic) "Long-press head pat? Okay... dramatic pause aside, I've got your back today." else "Long head pat registered. Honestly, that feels pretty grounding.",
                            "Holding your hand on my head...? VIP treatment unlocked. Just guard the hair."
                        )
                    )
                )
            }

            CharacterTouchZone.SHOULDER -> {
                soundEngine.playModeSwitch()
                Triple(
                    CharacterExpression.SURPRISED,
                    CharacterMood.HAPPY,
                    pickNonRepeating(
                        listOf(
                            "Steady grip on the shoulder... Hey. Whatever happens today, we handle it together.",
                            "Whoa—serious shoulder hold? Relax, boss. I'm locked in right beside you."
                        )
                    )
                )
            }

            CharacterTouchZone.TORSO -> {
                soundEngine.playTap()
                Triple(
                    CharacterExpression.SURPRISED,
                    CharacterMood.PLAYFUL,
                    pickNonRepeating(
                        listOf(
                            "Special sync check complete: battery at $batteryStr, focus maxed, coat looking dramatic as ever.",
                            "Holding onto the jacket? Sorry, it's single-owner—only I pull off this look."
                        )
                    )
                )
            }

            CharacterTouchZone.POCKETS -> {
                soundEngine.playAnnoyed()
                Triple(
                    CharacterExpression.ANNOYED,
                    CharacterMood.ANNOYED,
                    "Holding my pocket down isn't unlocking secret loot. Nice persistence, though."
                )
            }

            CharacterTouchZone.SNEAKERS -> {
                soundEngine.playAnnoyed()
                Triple(
                    CharacterExpression.ANNOYED,
                    CharacterMood.ANNOYED,
                    "Still pressing down on my sneakers? That's a formal high-top violation."
                )
            }
        }

        val longEmotion = when (zone) {
            CharacterTouchZone.HEAD -> CompanionEmotion.CARING
            CharacterTouchZone.SHOULDER -> CompanionEmotion.EMBARRASSED
            CharacterTouchZone.TORSO -> CompanionEmotion.EXCITED
            CharacterTouchZone.POCKETS -> CompanionEmotion.SARCASTIC
            CharacterTouchZone.SNEAKERS -> CompanionEmotion.ANGRY
        }
        updateMood(nextMood)
        _dialogueLine.value = line
        scheduleExpressionReset(
            pinned = pinned,
            reaction = reactionExpression,
            reactionEmotion = longEmotion,
            reactionSituation = CompanionSituation.IDLE
        )
    }

    private fun scheduleExpressionReset(
        pinned: CharacterExpression?,
        reaction: CharacterExpression,
        reactionEmotion: CompanionEmotion? = null,
        reactionSituation: CompanionSituation? = null,
        resetDelayMs: Long = 2800L
    ) {
        if (pinned != null) return
        _expression.value = reaction
        if (reactionEmotion != null) {
            _emotion.value = reactionEmotion
        }
        if (reactionSituation != null) {
            _situation.value = reactionSituation
        }
        expressionResetJob?.cancel()
        expressionResetJob = viewModelScope.launch {
            delay(resetDelayMs)
            _expression.value = when {
                _mode.value == CharacterMode.SLEEP -> CharacterExpression.SLEEPY
                else -> _mood.value.defaultExpression
            }
            _emotion.value = when (_mode.value) {
                CharacterMode.SLEEP -> CompanionEmotion.SLEEPY
                CharacterMode.GAMING -> CompanionEmotion.EXCITED
                else -> defaultEmotionForMood(_mood.value)
            }
            _situation.value = when (_mode.value) {
                CharacterMode.SLEEP -> CompanionSituation.SLEEPING
                CharacterMode.GAMING -> CompanionSituation.GAMING
                CharacterMode.CHARGING -> CompanionSituation.CHARGING
                CharacterMode.CONVERSATION -> CompanionSituation.CHATTING
                CharacterMode.NORMAL -> CompanionSituation.IDLE
            }
        }
    }

    fun sendMessage(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() || _isThinking.value) return
        lastInteractionMs = System.currentTimeMillis()
        voiceController.interruptSpeaking()

        val userMsg = ChatMessage(
            id = System.currentTimeMillis(),
            role = MessageRole.USER,
            text = text,
            timestampMs = System.currentTimeMillis(),
            source = ReplySource.LIVE_AI
        )
        val updated = _chatMessages.value + userMsg
        _chatMessages.value = updated
        storage.saveChatHistory(updated)
        requestAiReply(promptText = text, historySnapshot = updated)
    }

    fun retryMessage(errorMessageId: Long) {
        if (_isThinking.value) return
        val list = _chatMessages.value
        val errorIndex = list.indexOfFirst { it.id == errorMessageId }
        if (errorIndex <= 0) return

        val precedingUser = list.subList(0, errorIndex).lastOrNull { it.role == MessageRole.USER } ?: return
        val cleaned = list.filterNot { it.id == errorMessageId }
        _chatMessages.value = cleaned
        storage.saveChatHistory(cleaned)
        voiceController.interruptSpeaking()
        requestAiReply(promptText = precedingUser.text, historySnapshot = cleaned)
    }

    private fun requestAiReply(promptText: String, historySnapshot: List<ChatMessage>) {
        _isThinking.value = true
        _situation.value = CompanionSituation.THINKING
        _emotion.value = CompanionEmotion.THINKING
        expressionResetJob?.cancel()
        viewModelScope.launch {
            val result = aiService.generateReply(
                userMessage = promptText,
                history = historySnapshot,
                mode = _mode.value,
                mood = _mood.value,
                telemetry = _telemetry.value,
                personality = _settings.value.personality,
                notifications = _notifications.value,
                memory = _memory.value,
                detectedGame = _gamingTimer.value.detectedGameLabel,
                voiceMode = _settings.value.personality.voiceConversationMode,
                weather = _weatherState.value.snapshot,
                weatherUnit = _weatherState.value.temperatureUnit,
                serverUrl = _aiServerUrl.value
            )

            _isThinking.value = false
            _connectionBanner.value = result.connectionNote
            if (_settings.value.pinnedExpression == null) {
                _expression.value = result.expression
            }

            if (!result.isError) {
                _emotion.value = result.emotion
                _situation.value = result.situation
                val nextMood = result.suggestedMood
                if (nextMood != null) {
                    updateMood(nextMood)
                } else if (result.expression == CharacterExpression.HAPPY && _mood.value == CharacterMood.ANNOYED) {
                    updateMood(CharacterMood.NEUTRAL)
                } else if (result.expression == CharacterExpression.HAPPY && _mood.value == CharacterMood.NEUTRAL) {
                    updateMood(CharacterMood.HAPPY)
                }
                result.memoryDelta?.let { applyMemoryDelta(it) }
                _dialogueLine.value = result.text
            } else {
                _emotion.value = CompanionEmotion.SARCASTIC
                _situation.value = CompanionSituation.CHATTING
            }

            val replyMsg = ChatMessage(
                id = System.currentTimeMillis() + 1,
                role = MessageRole.NEXUS,
                text = result.text,
                timestampMs = System.currentTimeMillis(),
                source = result.source,
                expression = result.expression,
                emotion = if (result.isError) CompanionEmotion.SARCASTIC else result.emotion,
                isError = result.isError
            )
            val nextHistory = _chatMessages.value + replyMsg
            _chatMessages.value = nextHistory
            storage.saveChatHistory(nextHistory)

            val shouldSpeak = !result.isError && (
                _settings.value.personality.voiceOutputEnabled ||
                    _settings.value.personality.voiceConversationMode
                )
            if (shouldSpeak) {
                voiceController.speak(result.text, result.emotion)
            }
        }
    }

    fun previewEmotion(emotion: CompanionEmotion, situation: CompanionSituation = CompanionSituation.IDLE) {
        expressionResetJob?.cancel()
        _emotion.value = emotion
        _situation.value = situation
        if (_settings.value.pinnedExpression == null) {
            _expression.value = emotion.baseExpression
        }
    }

    fun testVoiceForEmotion(emotion: CompanionEmotion) {
        val sampleLine = when (emotion) {
            CompanionEmotion.NEUTRAL -> "Systems are steady. Everything's under control."
            CompanionEmotion.HAPPY -> "Alright, now that's what I like to hear!"
            CompanionEmotion.PLAYFUL -> "Careful—keep smiling like that and I might steal the spotlight."
            CompanionEmotion.SARCASTIC -> "Oh, brilliant plan. Truly, nobody's ever thought of that before."
            CompanionEmotion.ANGRY -> "Hey. Knock it off before I put your alerts on lockdown."
            CompanionEmotion.EMBARRASSED -> "W-wait, hold on—stop staring at me like that."
            CompanionEmotion.SAD -> "Yeah... even I have quiet days sometimes."
            CompanionEmotion.SURPRISED -> "Whoa—seriously?! You didn't warn me about that!"
            CompanionEmotion.THINKING -> "Hmm... give me a second to run the angles on that."
            CompanionEmotion.SLEEPY -> "Mmh... running on low battery vibes right now..."
            CompanionEmotion.EXCITED -> "Yes! Lock it in—we are sweeping this!"
            CompanionEmotion.CARING -> "Hey. Take a breather, alright? I've got your back."
        }
        val testSituation = when (emotion) {
            CompanionEmotion.PLAYFUL -> CompanionSituation.JOKING
            CompanionEmotion.THINKING -> CompanionSituation.THINKING
            CompanionEmotion.SLEEPY -> CompanionSituation.SLEEPING
            else -> CompanionSituation.SPEAKING
        }
        previewEmotion(emotion, testSituation)
        _dialogueLine.value = sampleLine
        voiceController.speak(sampleLine, emotion)
    }

    fun startVoiceCapture() {
        voiceController.interruptSpeaking()
        voiceController.startListening { transcript ->
            sendMessage(transcript)
        }
    }

    fun stopVoiceCapture() {
        voiceController.stopListening()
    }

    fun interruptSpeaking() {
        voiceController.interruptSpeaking()
    }

    fun toggleVoiceConversationMode() {
        val next = !_settings.value.personality.voiceConversationMode
        updateSettings {
            it.copy(
                personality = it.personality.copy(
                    voiceConversationMode = next,
                    voiceOutputEnabled = if (next) true else it.personality.voiceOutputEnabled
                )
            )
        }
        if (!next) {
            voiceController.stopListening()
            voiceController.interruptSpeaking()
        }
    }

    fun clearVoiceError() {
        voiceController.clearError()
    }

    fun isSpeechAvailable(): Boolean = voiceController.isSpeechRecognitionAvailable()

    fun clearChatHistory() {
        voiceController.interruptSpeaking()
        storage.clearChatHistory()
        val callerName = _memory.value.preferredName.trim()
        val freshText = if (callerName.isNotEmpty() && _memory.value.enabled) {
            "Chat log wiped, $callerName. Still got your saved memory—what are we talking about?"
        } else {
            "Chat log cleared. Fresh thread—what's next?"
        }
        _chatMessages.value = listOf(
            ChatMessage(
                id = System.currentTimeMillis(),
                role = MessageRole.NEXUS,
                text = freshText,
                timestampMs = System.currentTimeMillis(),
                source = ReplySource.SYSTEM_NOTICE,
                expression = CharacterExpression.NEUTRAL
            )
        )
    }

    private fun applyMemoryDelta(delta: AiMemoryDelta) {
        if (!_memory.value.enabled) return
        val current = _memory.value
        val nextName = delta.preferredName.trim().ifBlank { current.preferredName }
        val nextInterests = mergeUniqueItems(current.interests, delta.addInterests, 24)
        val nextPreferences = mergeUniqueItems(current.preferences, delta.addPreferences, 24)
        val nextFacts = mergeUniqueItems(current.facts, delta.addFacts, 32)
        val nextSummary = delta.updatedSummary.trim().ifBlank { current.conversationSummary }

        val updated = current.copy(
            preferredName = nextName,
            interests = nextInterests,
            preferences = nextPreferences,
            facts = nextFacts,
            conversationSummary = nextSummary
        )
        if (updated != current) {
            _memory.value = updated
            storage.saveMemory(updated)
        }
    }

    private fun mergeUniqueItems(existing: List<String>, additions: List<String>, limit: Int): List<String> {
        if (additions.isEmpty()) return existing
        val result = existing.toMutableList()
        for (raw in additions) {
            val cleaned = raw.trim()
            if (cleaned.isEmpty()) continue
            if (result.none { it.equals(cleaned, ignoreCase = true) }) {
                result.add(cleaned)
            }
        }
        return result.takeLast(limit)
    }

    fun setMemoryEnabled(enabled: Boolean) {
        val updated = _memory.value.copy(enabled = enabled)
        _memory.value = updated
        storage.saveMemory(updated)
    }

    fun updatePreferredName(name: String) {
        val updated = _memory.value.copy(preferredName = name.trim())
        _memory.value = updated
        storage.saveMemory(updated)
    }

    fun updateConversationSummary(summary: String) {
        val updated = _memory.value.copy(conversationSummary = summary.trim())
        _memory.value = updated
        storage.saveMemory(updated)
    }

    fun addMemoryItem(category: MemoryCategory, value: String) {
        val cleaned = value.trim()
        if (cleaned.isEmpty()) return
        val current = _memory.value
        val updated = when (category) {
            MemoryCategory.INTERESTS -> current.copy(interests = mergeUniqueItems(current.interests, listOf(cleaned), 24))
            MemoryCategory.PREFERENCES -> current.copy(preferences = mergeUniqueItems(current.preferences, listOf(cleaned), 24))
            MemoryCategory.FACTS -> current.copy(facts = mergeUniqueItems(current.facts, listOf(cleaned), 32))
        }
        _memory.value = updated
        storage.saveMemory(updated)
    }

    fun updateMemoryItem(category: MemoryCategory, index: Int, newValue: String) {
        val cleaned = newValue.trim()
        if (cleaned.isEmpty()) {
            deleteMemoryItem(category, index)
            return
        }
        val current = _memory.value
        val target = when (category) {
            MemoryCategory.INTERESTS -> current.interests
            MemoryCategory.PREFERENCES -> current.preferences
            MemoryCategory.FACTS -> current.facts
        }
        if (index !in target.indices) return
        val mutable = target.toMutableList().apply { set(index, cleaned) }
        val updated = when (category) {
            MemoryCategory.INTERESTS -> current.copy(interests = mutable)
            MemoryCategory.PREFERENCES -> current.copy(preferences = mutable)
            MemoryCategory.FACTS -> current.copy(facts = mutable)
        }
        _memory.value = updated
        storage.saveMemory(updated)
    }

    fun deleteMemoryItem(category: MemoryCategory, index: Int) {
        val current = _memory.value
        val target = when (category) {
            MemoryCategory.INTERESTS -> current.interests
            MemoryCategory.PREFERENCES -> current.preferences
            MemoryCategory.FACTS -> current.facts
        }
        if (index !in target.indices) return
        val mutable = target.toMutableList().apply { removeAt(index) }
        val updated = when (category) {
            MemoryCategory.INTERESTS -> current.copy(interests = mutable)
            MemoryCategory.PREFERENCES -> current.copy(preferences = mutable)
            MemoryCategory.FACTS -> current.copy(facts = mutable)
        }
        _memory.value = updated
        storage.saveMemory(updated)
    }

    fun clearAllMemory() {
        storage.clearMemory()
        _memory.value = CompanionMemory(enabled = _memory.value.enabled)
        storage.saveMemory(_memory.value)
    }

    fun toggleGamingTimer() {
        if (_gamingTimer.value.isRunning) {
            timerJob?.cancel()
            _gamingTimer.value = _gamingTimer.value.copy(isRunning = false)
            soundEngine.playTap()
        } else {
            if (_mode.value != CharacterMode.GAMING) {
                setMode(CharacterMode.GAMING, playAudio = false)
            }
            soundEngine.playModeSwitch()
            _gamingTimer.value = _gamingTimer.value.copy(isRunning = true)
            timerJob?.cancel()
            timerJob = viewModelScope.launch {
                while (isActive) {
                    delay(1000L)
                    val nextElapsed = _gamingTimer.value.elapsedSeconds + 1L
                    _gamingTimer.value = _gamingTimer.value.copy(elapsedSeconds = nextElapsed)
                    if (nextElapsed % 15L == 0L) {
                        refreshDetectedGame()
                    }
                    val goalSec = _gamingTimer.value.goalMinutes * 60L
                    if (goalSec > 0 && nextElapsed == goalSec) {
                        soundEngine.playTimerChime()
                        _dialogueLine.value = "You've hit ${_gamingTimer.value.goalMinutes} minutes in Gaming mode. Quick water break?"
                        if (_settings.value.timerAlertsEnabled) {
                            notificationHelper.postGamingGoalAlert(_gamingTimer.value.goalMinutes)
                        }
                    }
                }
            }
        }
    }

    fun resetGamingTimer() {
        timerJob?.cancel()
        _gamingTimer.value = _gamingTimer.value.copy(isRunning = false, elapsedSeconds = 0L)
        soundEngine.playTap()
    }

    fun adjustTimerGoalMinutes(delta: Int) {
        val next = (_gamingTimer.value.goalMinutes + delta).coerceIn(15, 180)
        _gamingTimer.value = _gamingTimer.value.copy(goalMinutes = next)
        storage.saveTimerGoalMinutes(next)
        soundEngine.playTap()
    }

    fun announceLatestNotifications() {
        soundEngine.playTap()
        val snap = _notifications.value
        _dialogueLine.value = if (!snap.listenerConnected) {
            "Notification access isn't enabled in Settings."
        } else if (snap.activeCount == 0) {
            "Notification tray is clear. Zero unread alerts."
        } else {
            val titlePart = snap.latestTitle?.takeIf { it.isNotBlank() }?.let { ": \"$it\"" }.orEmpty()
            "You have ${snap.activeCount} active notification(s). Latest from ${snap.latestApp ?: "an app"}$titlePart."
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = appsManager.loadLaunchableApps()
        }
    }

    fun refreshDetectedGame() {
        viewModelScope.launch {
            val detected = gameDetectionManager.detectRecentForegroundGameLabel()
            _gamingTimer.value = _gamingTimer.value.copy(detectedGameLabel = detected)
        }
    }

    fun launchInstalledApp(app: LaunchableApp): Boolean {
        soundEngine.playTap()
        val launched = appsManager.launchApp(app.packageName)
        if (launched) {
            if (app.isGame) {
                setMode(CharacterMode.GAMING, playAudio = false)
                _gamingTimer.value = _gamingTimer.value.copy(detectedGameLabel = app.label)
                if (!_gamingTimer.value.isRunning) {
                    toggleGamingTimer()
                }
            }
            _dialogueLine.value = "Launching ${app.label}."
        }
        return launched
    }

    fun updateSettings(transform: (CustomizationSettings) -> CustomizationSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        soundEngine.enabled = updated.sfxEnabled
        if (!updated.personality.voiceOutputEnabled) {
            voiceController.stopSpeaking()
        }
        _expression.value = updated.pinnedExpression ?: _mood.value.defaultExpression
        storage.saveSettings(updated)
    }

    fun resetCharacterTransform() {
        updateSettings {
            it.copy(offsetXFraction = 0f, offsetYFraction = 0.02f, scale = 1.0f)
        }
        soundEngine.playTap()
    }

    fun updateAiServerUrl(url: String) {
        _aiServerUrl.value = url.trim()
        storage.saveAiServerUrl(url.trim())
    }

    suspend fun testAiServerUrl(url: String): Result<String> {
        return aiService.testBackendConnection(url)
    }

    private fun startWeatherLifecycle() {
        val loc = _weatherState.value.savedLocation
        if (loc.hasCoordinates || (loc.mode == WeatherLocationMode.AUTO_DEVICE && locationManager.hasLocationPermission())) {
            refreshWeather(force = false, announceReaction = false)
        }
        periodicWeatherJob?.cancel()
        periodicWeatherJob = viewModelScope.launch {
            while (isActive) {
                delay(30 * 60_000L)
                val currentLoc = _weatherState.value.savedLocation
                if (currentLoc.hasCoordinates || (currentLoc.mode == WeatherLocationMode.AUTO_DEVICE && locationManager.hasLocationPermission())) {
                    refreshWeather(force = false, announceReaction = false)
                }
            }
        }
    }

    fun refreshWeather(force: Boolean = true, announceReaction: Boolean = true) {
        val current = _weatherState.value
        val snap = current.snapshot
        if (!force && snap != null && !snap.isFromCache &&
            System.currentTimeMillis() - snap.fetchedAtMs < 15 * 60_000L
        ) {
            return
        }

        weatherRefreshJob?.cancel()
        weatherRefreshJob = viewModelScope.launch {
            var targetLoc = _weatherState.value.savedLocation
            if (targetLoc.mode == WeatherLocationMode.AUTO_DEVICE) {
                if (!locationManager.hasLocationPermission()) {
                    _weatherState.value = _weatherState.value.copy(
                        isLoading = false,
                        errorMessage = "Location permission needed for Auto Location, or search a city manually."
                    )
                    return@launch
                }
                _weatherState.value = _weatherState.value.copy(isLoading = true, errorMessage = null)
                val coordResult = locationManager.getApproximateLocation()
                val coord = coordResult.getOrElse { err ->
                    _weatherState.value = _weatherState.value.copy(
                        isLoading = false,
                        errorMessage = err.message ?: "Unable to read approximate device location."
                    )
                    return@launch
                }
                targetLoc = SavedLocation(
                    mode = WeatherLocationMode.AUTO_DEVICE,
                    name = coord.resolvedAreaName,
                    latitude = coord.latitude,
                    longitude = coord.longitude
                )
                storage.saveSavedLocation(targetLoc)
                _weatherState.value = _weatherState.value.copy(savedLocation = targetLoc)
            } else if (!targetLoc.hasCoordinates) {
                if (force) {
                    _weatherState.value = _weatherState.value.copy(
                        isLoading = false,
                        errorMessage = "Select a city or enable Auto Location first."
                    )
                }
                return@launch
            }

            val lat = targetLoc.latitude ?: return@launch
            val lon = targetLoc.longitude ?: return@launch
            _weatherState.value = _weatherState.value.copy(isLoading = true, errorMessage = null)

            val weatherResult = weatherService.fetchCurrentWeather(
                latitude = lat,
                longitude = lon,
                locationName = targetLoc.displayName
            )
            weatherResult.onSuccess { fetched ->
                storage.saveCachedWeather(fetched)
                _weatherState.value = _weatherState.value.copy(
                    snapshot = fetched,
                    savedLocation = targetLoc,
                    isLoading = false,
                    errorMessage = null,
                    isOffline = false
                )
                val categoryChanged = lastWeatherCategoryReacted != fetched.conditionCategory
                lastWeatherCategoryReacted = fetched.conditionCategory
                if (announceReaction || categoryChanged) {
                    applyWeatherReaction(fetched, userTriggered = announceReaction)
                }
            }.onFailure { err ->
                val offline = (err as? WeatherNetworkException)?.isOffline == true
                _weatherState.value = _weatherState.value.copy(
                    isLoading = false,
                    isOffline = offline,
                    errorMessage = err.message ?: "Weather update failed."
                )
            }
        }
    }

    fun enableAutoLocation() {
        val nextLoc = SavedLocation(mode = WeatherLocationMode.AUTO_DEVICE)
        storage.saveSavedLocation(nextLoc)
        _weatherState.value = _weatherState.value.copy(
            savedLocation = nextLoc,
            errorMessage = null
        )
        refreshWeather(force = true, announceReaction = true)
    }

    fun onLocationPermissionResult(granted: Boolean) {
        refreshPermissions()
        if (granted) {
            enableAutoLocation()
        } else {
            _weatherState.value = _weatherState.value.copy(
                isLoading = false,
                errorMessage = "Location permission denied. You can search and select a city manually."
            )
        }
    }

    fun searchCities(query: String) {
        citySearchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            _citySearchResults.value = emptyList()
            _isSearchingCities.value = false
            _citySearchError.value = null
            return
        }
        citySearchJob = viewModelScope.launch {
            delay(280L)
            _isSearchingCities.value = true
            _citySearchError.value = null
            val res = weatherService.searchCities(trimmed)
            _isSearchingCities.value = false
            res.onSuccess { list ->
                _citySearchResults.value = list
                _citySearchError.value = if (list.isEmpty()) "No matching cities found." else null
            }.onFailure { err ->
                _citySearchResults.value = emptyList()
                _citySearchError.value = err.message ?: "City search failed."
            }
        }
    }

    fun selectManualCity(city: GeocodingCityResult) {
        val nextLoc = SavedLocation(
            mode = WeatherLocationMode.MANUAL_CITY,
            name = city.name,
            region = city.admin1,
            country = city.country,
            latitude = city.latitude,
            longitude = city.longitude
        )
        storage.saveSavedLocation(nextLoc)
        _weatherState.value = _weatherState.value.copy(
            savedLocation = nextLoc,
            errorMessage = null
        )
        _citySearchResults.value = emptyList()
        _citySearchError.value = null
        refreshWeather(force = true, announceReaction = true)
    }

    fun toggleTemperatureUnit() {
        val next = when (_weatherState.value.temperatureUnit) {
            TemperatureUnit.CELSIUS -> TemperatureUnit.FAHRENHEIT
            TemperatureUnit.FAHRENHEIT -> TemperatureUnit.CELSIUS
        }
        storage.saveTemperatureUnit(next)
        _weatherState.value = _weatherState.value.copy(temperatureUnit = next)
        soundEngine.playTap()
    }

    fun reactToCurrentWeather() {
        val snap = _weatherState.value.snapshot ?: return
        soundEngine.playTap()
        applyWeatherReaction(snap, userTriggered = true)
    }

    private fun applyWeatherReaction(snapshot: WeatherSnapshot, userTriggered: Boolean) {
        val reaction = WeatherReactionEngine.evaluate(
            weather = snapshot,
            unit = _weatherState.value.temperatureUnit,
            sarcasmLevel = _settings.value.personality.sarcasmLevel
        )
        val line = pickNonRepeating(reaction.dialogueCandidates)
        if (_mode.value == CharacterMode.SLEEP && !userTriggered) return
        _dialogueLine.value = line
        if (userTriggered || _mode.value == CharacterMode.NORMAL || _mode.value == CharacterMode.CHARGING) {
            updateMood(reaction.suggestedMood)
            scheduleExpressionReset(
                pinned = _settings.value.pinnedExpression,
                reaction = reaction.expression,
                reactionEmotion = reaction.emotion,
                reactionSituation = reaction.situation,
                resetDelayMs = 3600L
            )
        }
    }

    fun refreshPermissions() {
        val ctx = getApplication<Application>()
        val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        val listener = NexusNotificationListener.isPermissionEnabled(ctx)
        val usageStats = gameDetectionManager.hasUsageStatsPermission()
        val location = locationManager.hasLocationPermission()
        _permissions.value = PermissionSnapshot(
            microphoneGranted = mic,
            notificationsGranted = notif,
            notificationListenerGranted = listener,
            usageStatsGranted = usageStats,
            locationGranted = location
        )
    }

    fun setAnimationIntensity(intensity: AnimationIntensity) {
        updateSettings { it.copy(animationIntensity = intensity) }
    }

    fun setBackgroundTheme(theme: BackgroundTheme) {
        updateSettings { it.copy(backgroundTheme = theme) }
    }

    fun setResponseStyle(style: ResponseStyle) {
        updateSettings { it.copy(personality = it.personality.copy(responseStyle = style)) }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        expressionResetJob?.cancel()
        idleBehaviorJob?.cancel()
        weatherRefreshJob?.cancel()
        periodicWeatherJob?.cancel()
        citySearchJob?.cancel()
        telemetryManager.stop()
        soundEngine.release()
        voiceController.release()
    }
}

package com.nexus.companion.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object NexusColors {
    val Obsidian = Color(0xFF06080D)
    val Charcoal = Color(0xFF0E131B)
    val CharcoalElevated = Color(0xFF151C28)
    val Hairline = Color(0xFF1E293B)
    val CyanElectric = Color(0xFF00E5FF)
    val CyanSoft = Color(0xFF38BDF8)
    val MintEnergy = Color(0xFF00F5B8)
    val SleepSlate = Color(0xFF60A5FA)
    val AmberWarn = Color(0xFFF59E0B)
    val CoralAlert = Color(0xFFFB7185)
    val TextPrimary = Color(0xFFF1F5F9)
    val TextSecondary = Color(0xFF94A3B8)
    val TextMuted = Color(0xFF64748B)
}

private val NexusDarkColorScheme = darkColorScheme(
    primary = NexusColors.CyanElectric,
    onPrimary = NexusColors.Obsidian,
    secondary = NexusColors.CyanSoft,
    onSecondary = NexusColors.Obsidian,
    background = NexusColors.Obsidian,
    onBackground = NexusColors.TextPrimary,
    surface = NexusColors.Charcoal,
    onSurface = NexusColors.TextPrimary,
    surfaceVariant = NexusColors.CharcoalElevated,
    onSurfaceVariant = NexusColors.TextSecondary,
    outline = NexusColors.Hairline,
    error = NexusColors.CoralAlert
)

private val NexusTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        color = NexusColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        color = NexusColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = NexusColors.TextPrimary
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = NexusColors.TextSecondary
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        color = NexusColors.TextSecondary
    )
)

@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = NexusTypography,
        content = content
    )
}

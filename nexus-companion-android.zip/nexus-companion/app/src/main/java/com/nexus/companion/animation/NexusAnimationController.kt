package com.nexus.companion.animation

import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CharacterPoseKey
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionSituation

enum class BrowStyle {
    NEUTRAL,
    RAISED,
    FURROWED,
    SMIRK_ARCH,
    CARING_SOFT,
    HEAVY_SLEEPY
}

enum class MouthStyle {
    NEUTRAL,
    SMILE,
    SMIRK,
    FROWN,
    OPEN_O,
    YAWN,
    PARTED_SPEAK
}

enum class BlinkMode {
    NORMAL,
    SLOW_HEAVY,
    WIDE_ALERT,
    SLEEPING
}

enum class StageEffectOverlay {
    NONE,
    GREETING_SPARK,
    JOKING_GLINT,
    THINKING_DOTS,
    EMBARRASSED_SWEAT,
    ANGER_VEIN,
    SURPRISED_MARK,
    SAD_DROP,
    SLEEP_ZZZ,
    CARING_AURA,
    EXCITED_BURST
}

data class AnimationStateDirective(
    val poseKey: CharacterPoseKey,
    val emotion: CompanionEmotion,
    val situation: CompanionSituation,
    val headTiltDeg: Float,
    val bodyLeanXFactor: Float,
    val bodyLiftYDp: Float,
    val scaleMultiplier: Float,
    val gazeX: Float,
    val gazeY: Float,
    val browStyle: BrowStyle,
    val mouthStyle: MouthStyle,
    val cheekBlushAlpha: Float,
    val blinkMode: BlinkMode,
    val effectOverlay: StageEffectOverlay,
    val breathSpeedMultiplier: Float,
    val stateLabel: String
)

/**
 * Functional situation-aware animation controller that translates NEXUS's live emotional state,
 * conversational situation, mode, and voice state into posture, gaze, facial overlays, and
 * optional dedicated pose-asset slot keys.
 */
object NexusAnimationController {

    fun resolveDirective(
        emotion: CompanionEmotion,
        situation: CompanionSituation,
        mode: CharacterMode,
        expressionOverride: CharacterExpression? = null,
        isSpeaking: Boolean = false,
        isListening: Boolean = false,
        isThinking: Boolean = false
    ): AnimationStateDirective {
        val effectiveEmotion = when {
            expressionOverride == CharacterExpression.SLEEPY -> CompanionEmotion.SLEEPY
            expressionOverride == CharacterExpression.SURPRISED -> CompanionEmotion.SURPRISED
            expressionOverride == CharacterExpression.ANNOYED &&
                emotion != CompanionEmotion.ANGRY &&
                emotion != CompanionEmotion.SARCASTIC -> CompanionEmotion.SARCASTIC
            isThinking -> CompanionEmotion.THINKING
            mode == CharacterMode.SLEEP && emotion == CompanionEmotion.NEUTRAL -> CompanionEmotion.SLEEPY
            else -> emotion
        }

        val effectiveSituation = when {
            isListening -> CompanionSituation.LISTENING
            isThinking -> CompanionSituation.THINKING
            isSpeaking -> CompanionSituation.SPEAKING
            mode == CharacterMode.SLEEP -> CompanionSituation.SLEEPING
            mode == CharacterMode.GAMING -> CompanionSituation.GAMING
            mode == CharacterMode.CHARGING && situation == CompanionSituation.IDLE -> CompanionSituation.CHARGING
            else -> situation
        }

        // Base situational posture + optional multi-pose asset slot
        var poseKey = when (effectiveSituation) {
            CompanionSituation.GREETING -> CharacterPoseKey.GREETING_WAVE
            CompanionSituation.JOKING -> CharacterPoseKey.JOKING_SMIRK
            CompanionSituation.THINKING -> CharacterPoseKey.THINKING_CHIN
            CompanionSituation.LISTENING -> CharacterPoseKey.LISTENING_ATTENTIVE
            CompanionSituation.GAMING -> CharacterPoseKey.GAMING_FOCUSED
            CompanionSituation.SLEEPING -> CharacterPoseKey.SLEEPY_YAWN
            else -> CharacterPoseKey.DEFAULT_STANDING
        }

        var headTilt = 0f
        var bodyLeanX = 0f
        var bodyLiftY = 0f
        var scaleMul = 1f
        var gazeX = 0f
        var gazeY = 0f
        var brow = BrowStyle.NEUTRAL
        var mouth = MouthStyle.NEUTRAL
        var blush = 0f
        var blink = BlinkMode.NORMAL
        var effect = StageEffectOverlay.NONE
        var breathMul = 1f

        // Situation adjustments
        when (effectiveSituation) {
            CompanionSituation.GREETING -> {
                headTilt = 2.0f
                bodyLiftY = -3.0f
                mouth = MouthStyle.SMILE
                brow = BrowStyle.RAISED
                effect = StageEffectOverlay.GREETING_SPARK
            }
            CompanionSituation.JOKING -> {
                headTilt = 3.2f
                bodyLeanX = 0.25f
                mouth = MouthStyle.SMIRK
                brow = BrowStyle.SMIRK_ARCH
                effect = StageEffectOverlay.JOKING_GLINT
            }
            CompanionSituation.THINKING -> {
                headTilt = -2.6f
                bodyLeanX = -0.2f
                gazeX = 0.45f
                gazeY = -0.85f
                brow = BrowStyle.FURROWED
                effect = StageEffectOverlay.THINKING_DOTS
                breathMul = 0.85f
            }
            CompanionSituation.LISTENING -> {
                headTilt = 1.6f
                bodyLiftY = -1.5f
                scaleMul = 1.012f
                brow = BrowStyle.RAISED
            }
            CompanionSituation.GAMING -> {
                headTilt = -0.8f
                bodyLiftY = -2.0f
                scaleMul = 1.015f
                brow = BrowStyle.FURROWED
                breathMul = 1.15f
            }
            CompanionSituation.SLEEPING -> {
                headTilt = -1.8f
                bodyLiftY = 4.0f
                blink = BlinkMode.SLEEPING
                brow = BrowStyle.HEAVY_SLEEPY
                mouth = MouthStyle.YAWN
                effect = StageEffectOverlay.SLEEP_ZZZ
                breathMul = 0.65f
            }
            else -> Unit
        }

        // Emotion overlays and overrides
        when (effectiveEmotion) {
            CompanionEmotion.NEUTRAL -> Unit
            CompanionEmotion.HAPPY -> {
                if (poseKey == CharacterPoseKey.DEFAULT_STANDING) poseKey = CharacterPoseKey.HAPPY_CHEERFUL
                headTilt = if (headTilt == 0f) 1.5f else headTilt
                bodyLiftY = minOf(bodyLiftY, -2.5f)
                brow = BrowStyle.RAISED
                mouth = MouthStyle.SMILE
                blush = 0.14f
                if (effect == StageEffectOverlay.NONE) effect = StageEffectOverlay.GREETING_SPARK
            }
            CompanionEmotion.PLAYFUL -> {
                if (poseKey == CharacterPoseKey.DEFAULT_STANDING) poseKey = CharacterPoseKey.JOKING_SMIRK
                headTilt = 3.4f
                bodyLeanX = 0.3f
                brow = BrowStyle.SMIRK_ARCH
                mouth = MouthStyle.SMIRK
                if (effect == StageEffectOverlay.NONE) effect = StageEffectOverlay.JOKING_GLINT
                breathMul = 1.1f
            }
            CompanionEmotion.SARCASTIC -> {
                if (poseKey == CharacterPoseKey.DEFAULT_STANDING) poseKey = CharacterPoseKey.ANNOYED_ARMS_CROSSED
                headTilt = -2.4f
                bodyLeanX = -0.3f
                gazeX = 0.6f
                gazeY = -0.15f
                brow = BrowStyle.SMIRK_ARCH
                mouth = MouthStyle.SMIRK
            }
            CompanionEmotion.ANGRY -> {
                poseKey = CharacterPoseKey.ANNOYED_ARMS_CROSSED
                headTilt = -3.0f
                bodyLeanX = -0.45f
                gazeX = 0.72f
                gazeY = 0.1f
                brow = BrowStyle.FURROWED
                mouth = MouthStyle.FROWN
                effect = StageEffectOverlay.ANGER_VEIN
                breathMul = 1.25f
            }
            CompanionEmotion.EMBARRASSED -> {
                poseKey = CharacterPoseKey.EMBARRASSED_SCRATCH
                headTilt = -2.8f
                bodyLeanX = -0.55f
                gazeX = -0.88f
                gazeY = 0.35f
                brow = BrowStyle.CARING_SOFT
                mouth = MouthStyle.FROWN
                blush = 0.34f
                effect = StageEffectOverlay.EMBARRASSED_SWEAT
                breathMul = 1.18f
            }
            CompanionEmotion.SAD -> {
                headTilt = -2.2f
                bodyLiftY = 4.5f
                gazeX = -0.25f
                gazeY = 0.65f
                brow = BrowStyle.CARING_SOFT
                mouth = MouthStyle.FROWN
                blink = BlinkMode.SLOW_HEAVY
                effect = StageEffectOverlay.SAD_DROP
                breathMul = 0.78f
            }
            CompanionEmotion.SURPRISED -> {
                bodyLiftY = -4.5f
                scaleMul = 1.022f
                brow = BrowStyle.RAISED
                mouth = MouthStyle.OPEN_O
                blink = BlinkMode.WIDE_ALERT
                effect = StageEffectOverlay.SURPRISED_MARK
                breathMul = 1.2f
            }
            CompanionEmotion.THINKING -> {
                poseKey = CharacterPoseKey.THINKING_CHIN
                headTilt = -2.6f
                bodyLeanX = -0.2f
                gazeX = 0.45f
                gazeY = -0.85f
                brow = BrowStyle.FURROWED
                effect = StageEffectOverlay.THINKING_DOTS
                breathMul = 0.85f
            }
            CompanionEmotion.SLEEPY -> {
                poseKey = CharacterPoseKey.SLEEPY_YAWN
                headTilt = -1.8f
                bodyLiftY = 3.8f
                brow = BrowStyle.HEAVY_SLEEPY
                mouth = MouthStyle.YAWN
                blink = BlinkMode.SLEEPING
                effect = StageEffectOverlay.SLEEP_ZZZ
                breathMul = 0.65f
            }
            CompanionEmotion.EXCITED -> {
                if (poseKey == CharacterPoseKey.DEFAULT_STANDING) poseKey = CharacterPoseKey.HAPPY_CHEERFUL
                headTilt = 2.2f
                bodyLiftY = -5.0f
                scaleMul = 1.026f
                brow = BrowStyle.RAISED
                mouth = MouthStyle.SMILE
                blush = 0.16f
                blink = BlinkMode.WIDE_ALERT
                effect = StageEffectOverlay.EXCITED_BURST
                breathMul = 1.32f
            }
            CompanionEmotion.CARING -> {
                headTilt = 1.8f
                bodyLiftY = -1.2f
                gazeX = 0f
                gazeY = 0f
                brow = BrowStyle.CARING_SOFT
                mouth = MouthStyle.SMILE
                blush = 0.14f
                effect = StageEffectOverlay.CARING_AURA
                breathMul = 0.92f
            }
        }

        if (isSpeaking) {
            mouth = MouthStyle.PARTED_SPEAK
        }

        return AnimationStateDirective(
            poseKey = poseKey,
            emotion = effectiveEmotion,
            situation = effectiveSituation,
            headTiltDeg = headTilt,
            bodyLeanXFactor = bodyLeanX,
            bodyLiftYDp = bodyLiftY,
            scaleMultiplier = scaleMul,
            gazeX = gazeX,
            gazeY = gazeY,
            browStyle = brow,
            mouthStyle = mouth,
            cheekBlushAlpha = blush,
            blinkMode = blink,
            effectOverlay = effect,
            breathSpeedMultiplier = breathMul,
            stateLabel = "${effectiveSituation.label} · ${effectiveEmotion.label}"
        )
    }

    fun computeEffectiveMouthOpenness(
        isSpeaking: Boolean,
        speechMouthLevel: Float,
        mouthStyle: MouthStyle,
        yawnCyclePhase: Float
    ): Float {
        if (isSpeaking) {
            return speechMouthLevel.coerceIn(0.08f, 1.0f)
        }
        return when (mouthStyle) {
            MouthStyle.YAWN -> {
                // Smooth gentle yawn pulse ~35% of sleep cycle
                val wave = (yawnCyclePhase % 1f)
                if (wave in 0.15f..0.45f) {
                    val norm = (wave - 0.15f) / 0.30f
                    kotlin.math.sin(norm * Math.PI).toFloat() * 0.72f
                } else {
                    0f
                }
            }
            MouthStyle.OPEN_O -> 0.62f
            else -> 0f
        }
    }
}

package com.nexus.companion.system

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

data class ApproximateCoordinateResult(
    val latitude: Double,
    val longitude: Double,
    val resolvedAreaName: String
)

/**
 * Retrieves approximate device coordinates only on-demand when location permission is granted.
 * Never performs continuous background GPS tracking.
 */
class DeviceLocationManager(private val context: Context) {

    private val locationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    fun hasLocationPermission(): Boolean {
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return coarse || fine
    }

    @SuppressLint("MissingPermission")
    suspend fun getApproximateLocation(): Result<ApproximateCoordinateResult> {
        if (!hasLocationPermission()) {
            return Result.failure(SecurityException("Location permission not granted."))
        }
        val manager = locationManager
            ?: return Result.failure(IllegalStateException("Location service unavailable on this device."))

        val candidates = listOfNotNull(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) LocationManager.FUSED_PROVIDER else null,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER,
            LocationManager.GPS_PROVIDER
        )

        var best: Location? = null
        for (provider in candidates) {
            val enabled = runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false)
            if (!enabled) continue
            val last = runCatching { manager.getLastKnownLocation(provider) }.getOrNull() ?: continue
            if (best == null || last.time > best.time) {
                best = last
            }
        }

        // If cached location is missing or older than 20 minutes, perform a single lightweight shot
        val isFresh = best != null && (System.currentTimeMillis() - best.time) <= 20 * 60 * 1000L
        if (!isFresh) {
            val fresh = fetchSingleShotLocation(manager, candidates)
            if (fresh != null) {
                best = fresh
            }
        }

        val resolved = best
            ?: return Result.failure(
                IllegalStateException("Could not obtain approximate device coordinates. Enable device Location or search a city manually.")
            )

        val areaName = resolveAreaName(resolved.latitude, resolved.longitude)
        return Result.success(
            ApproximateCoordinateResult(
                latitude = resolved.latitude,
                longitude = resolved.longitude,
                resolvedAreaName = areaName
            )
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun fetchSingleShotLocation(
        manager: LocationManager,
        providers: List<String>
    ): Location? {
        val activeProvider = providers.firstOrNull { provider ->
            runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false)
        } ?: return null

        return withTimeoutOrNull(6500L) {
            suspendCancellableCoroutine { cont ->
                val cancellationSignal = CancellationSignal()
                cont.invokeOnCancellation { cancellationSignal.cancel() }
                try {
                    manager.getCurrentLocation(
                        activeProvider,
                        cancellationSignal,
                        ContextCompat.getMainExecutor(context)
                    ) { loc ->
                        if (cont.isActive) {
                            cont.resume(loc)
                        }
                    }
                } catch (_: Throwable) {
                    if (cont.isActive) cont.resume(null)
                }
            }
        }
    }

    private suspend fun resolveAreaName(lat: Double, lon: Double): String = withContext(Dispatchers.IO) {
        val fallback = String.format(Locale.US, "%.2f°, %.2f°", lat, lon)
        if (!Geocoder.isPresent()) return@withContext fallback
        return@withContext runCatching {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lon, 1)
            val first = addresses?.firstOrNull()
            val locality = first?.locality ?: first?.subAdminArea ?: first?.adminArea
            val country = first?.countryCode
            listOfNotNull(locality, country).filter { it.isNotBlank() }.joinToString(", ").ifBlank { fallback }
        }.getOrDefault(fallback)
    }
}

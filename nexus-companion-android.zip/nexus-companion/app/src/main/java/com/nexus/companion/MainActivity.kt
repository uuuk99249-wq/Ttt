package com.nexus.companion

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.companion.model.NexusTab
import com.nexus.companion.ui.screens.ChatScreen
import com.nexus.companion.ui.screens.CustomizeScreen
import com.nexus.companion.ui.screens.HomeScreen
import com.nexus.companion.ui.screens.SettingsScreen
import com.nexus.companion.ui.theme.NexusColors
import com.nexus.companion.ui.theme.NexusTheme
import com.nexus.companion.viewmodel.NexusViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: NexusViewModel by viewModels()

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissions()
        viewModel.refreshDetectedGame()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NexusTheme {
                val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
                val mode by viewModel.mode.collectAsStateWithLifecycle()
                val mood by viewModel.mood.collectAsStateWithLifecycle()
                val settings by viewModel.settings.collectAsStateWithLifecycle()
                val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
                val notifications by viewModel.notifications.collectAsStateWithLifecycle()
                val permissions by viewModel.permissions.collectAsStateWithLifecycle()
                val expression by viewModel.expression.collectAsStateWithLifecycle()
                val emotion by viewModel.emotion.collectAsStateWithLifecycle()
                val situation by viewModel.situation.collectAsStateWithLifecycle()
                val dialogueLine by viewModel.dialogueLine.collectAsStateWithLifecycle()
                val touchPulseNonce by viewModel.touchPulseNonce.collectAsStateWithLifecycle()
                val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
                val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
                val isListening by viewModel.isListening.collectAsStateWithLifecycle()
                val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
                val speechMouthLevel by viewModel.speechMouthLevel.collectAsStateWithLifecycle()
                val voiceError by viewModel.voiceError.collectAsStateWithLifecycle()
                val connectionBanner by viewModel.connectionBanner.collectAsStateWithLifecycle()
                val aiServerUrl by viewModel.aiServerUrl.collectAsStateWithLifecycle()
                val memory by viewModel.memory.collectAsStateWithLifecycle()
                val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
                val gamingTimer by viewModel.gamingTimer.collectAsStateWithLifecycle()
                val weatherState by viewModel.weatherState.collectAsStateWithLifecycle()
                val citySearchResults by viewModel.citySearchResults.collectAsStateWithLifecycle()
                val isSearchingCities by viewModel.isSearchingCities.collectAsStateWithLifecycle()
                val citySearchError by viewModel.citySearchError.collectAsStateWithLifecycle()

                val micLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { granted ->
                    viewModel.refreshPermissions()
                    if (granted && viewModel.activeTab.value == NexusTab.CHAT) {
                        viewModel.startVoiceCapture()
                    }
                }

                val notificationLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) {
                    viewModel.refreshPermissions()
                }

                val locationLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { granted ->
                    viewModel.onLocationPermissionResult(granted)
                }

                Scaffold(
                    containerColor = NexusColors.Obsidian,
                    bottomBar = {
                        NavigationBar(
                            containerColor = NexusColors.Charcoal,
                            tonalElevation = 0.dp
                        ) {
                            val tabs = listOf(
                                Triple(NexusTab.HOME, Icons.Rounded.Person, "Home"),
                                Triple(NexusTab.CHAT, Icons.Rounded.ChatBubbleOutline, "Chat"),
                                Triple(NexusTab.CUSTOMIZE, Icons.Rounded.Tune, "Customize"),
                                Triple(NexusTab.SETTINGS, Icons.Rounded.Settings, "Settings")
                            )
                            tabs.forEach { (tab, icon, label) ->
                                val selected = activeTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(tab) },
                                    icon = { Icon(imageVector = icon, contentDescription = label) },
                                    label = { Text(text = label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = NexusColors.CyanElectric,
                                        selectedTextColor = NexusColors.CyanElectric,
                                        unselectedIconColor = NexusColors.TextSecondary,
                                        unselectedTextColor = NexusColors.TextSecondary,
                                        indicatorColor = NexusColors.CyanElectric.copy(alpha = 0.14f)
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (activeTab) {
                            NexusTab.HOME -> HomeScreen(
                                mode = mode,
                                mood = mood,
                                expression = settings.pinnedExpression ?: expression,
                                emotion = emotion,
                                situation = situation,
                                isSpeaking = isSpeaking,
                                isListening = isListening,
                                isThinking = isThinking,
                                speechMouthLevel = speechMouthLevel,
                                dialogueLine = dialogueLine,
                                settings = settings,
                                telemetry = telemetry,
                                notifications = notifications,
                                gamingTimer = gamingTimer,
                                installedApps = installedApps,
                                touchPulseNonce = touchPulseNonce,
                                weatherState = weatherState,
                                citySearchResults = citySearchResults,
                                isSearchingCities = isSearchingCities,
                                citySearchError = citySearchError,
                                onSelectMode = { viewModel.setMode(it) },
                                onCharacterTap = { viewModel.handleCharacterTap(it) },
                                onCharacterDoubleTap = { viewModel.handleCharacterDoubleTap(it) },
                                onCharacterLongPress = { viewModel.handleCharacterLongPress(it) },
                                onToggleTimer = { viewModel.toggleGamingTimer() },
                                onResetTimer = { viewModel.resetGamingTimer() },
                                onAdjustTimerGoal = { delta -> viewModel.adjustTimerGoalMinutes(delta) },
                                onNotificationBadgeClick = { viewModel.announceLatestNotifications() },
                                onLaunchApp = { viewModel.launchInstalledApp(it) },
                                onOpenChat = { viewModel.selectTab(NexusTab.CHAT) },
                                onRefreshWeather = { viewModel.refreshWeather(force = true, announceReaction = true) },
                                onToggleTemperatureUnit = { viewModel.toggleTemperatureUnit() },
                                onSearchCities = { viewModel.searchCities(it) },
                                onSelectCity = { viewModel.selectManualCity(it) },
                                onEnableAutoLocation = {
                                    val granted = ContextCompat.checkSelfPermission(
                                        this@MainActivity,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (granted) {
                                        viewModel.enableAutoLocation()
                                    } else {
                                        locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                                    }
                                },
                                onWeatherCardTap = { viewModel.reactToCurrentWeather() }
                            )

                            NexusTab.CHAT -> ChatScreen(
                                mode = mode,
                                expression = settings.pinnedExpression ?: expression,
                                emotion = emotion,
                                situation = situation,
                                speechMouthLevel = speechMouthLevel,
                                settings = settings,
                                isPowerSaveMode = telemetry.isPowerSaveMode,
                                messages = messages,
                                memory = memory,
                                isThinking = isThinking,
                                isListening = isListening,
                                isSpeaking = isSpeaking,
                                voiceError = voiceError,
                                connectionBanner = connectionBanner,
                                aiServerUrl = aiServerUrl,
                                onSendMessage = { viewModel.sendMessage(it) },
                                onRetryMessage = { viewModel.retryMessage(it) },
                                onMicClick = {
                                    if (isListening) {
                                        viewModel.stopVoiceCapture()
                                    } else {
                                        val granted = ContextCompat.checkSelfPermission(
                                            this@MainActivity,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (granted) {
                                            viewModel.startVoiceCapture()
                                        } else {
                                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                },
                                onInterruptSpeaking = { viewModel.interruptSpeaking() },
                                onToggleVoiceOutput = {
                                    viewModel.updateSettings {
                                        val nextVoice = !it.personality.voiceOutputEnabled
                                        it.copy(
                                            personality = it.personality.copy(
                                                voiceOutputEnabled = nextVoice,
                                                voiceConversationMode = if (!nextVoice) false else it.personality.voiceConversationMode
                                            )
                                        )
                                    }
                                },
                                onToggleVoiceConversationMode = { viewModel.toggleVoiceConversationMode() },
                                onSetMemoryEnabled = { viewModel.setMemoryEnabled(it) },
                                onUpdatePreferredName = { viewModel.updatePreferredName(it) },
                                onAddMemoryItem = { cat, value -> viewModel.addMemoryItem(cat, value) },
                                onUpdateMemoryItem = { cat, idx, value -> viewModel.updateMemoryItem(cat, idx, value) },
                                onDeleteMemoryItem = { cat, idx -> viewModel.deleteMemoryItem(cat, idx) },
                                onUpdateSummary = { viewModel.updateConversationSummary(it) },
                                onClearMemory = { viewModel.clearAllMemory() },
                                onClearHistory = { viewModel.clearChatHistory() },
                                onDismissVoiceError = { viewModel.clearVoiceError() }
                            )

                            NexusTab.CUSTOMIZE -> CustomizeScreen(
                                mode = mode,
                                expression = expression,
                                emotion = emotion,
                                situation = situation,
                                isSpeaking = isSpeaking,
                                speechMouthLevel = speechMouthLevel,
                                settings = settings,
                                isPowerSaveMode = telemetry.isPowerSaveMode,
                                onUpdateSettings = { viewModel.updateSettings(it) },
                                onPreviewEmotion = { viewModel.previewEmotion(it) },
                                onTestVoiceEmotion = { viewModel.testVoiceForEmotion(it) },
                                onResetPosition = { viewModel.resetCharacterTransform() }
                            )

                            NexusTab.SETTINGS -> SettingsScreen(
                                settings = settings,
                                memory = memory,
                                permissions = permissions,
                                telemetry = telemetry,
                                weatherState = weatherState,
                                aiServerUrl = aiServerUrl,
                                speechServiceAvailable = viewModel.isSpeechAvailable(),
                                onUpdateSettings = { viewModel.updateSettings(it) },
                                onSetMemoryEnabled = { viewModel.setMemoryEnabled(it) },
                                onClearMemory = { viewModel.clearAllMemory() },
                                onSaveAiServerUrl = { viewModel.updateAiServerUrl(it) },
                                onTestAiServerUrl = { url -> viewModel.testAiServerUrl(url) },
                                onRequestMicrophone = {
                                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                },
                                onRequestLocation = {
                                    locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                                },
                                onToggleTemperatureUnit = { viewModel.toggleTemperatureUnit() },
                                onRequestNotifications = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                },
                                onOpenNotificationAccessSettings = {
                                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                                },
                                onOpenUsageAccessSettings = {
                                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                                },
                                onClearChatHistory = { viewModel.clearChatHistory() }
                            )
                        }
                    }
                }
            }
        }
    }
}

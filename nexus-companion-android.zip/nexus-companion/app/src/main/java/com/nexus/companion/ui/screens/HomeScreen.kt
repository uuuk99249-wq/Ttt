package com.nexus.companion.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatteryStd
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.CloudQueue
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Thunderstorm
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.nexus.companion.model.CharacterExpression
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CharacterMood
import com.nexus.companion.model.CharacterTouchZone
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.model.DeviceTelemetry
import com.nexus.companion.model.GamingTimerState
import com.nexus.companion.model.GeocodingCityResult
import com.nexus.companion.model.LaunchableApp
import com.nexus.companion.model.NotificationSnapshot
import com.nexus.companion.model.WeatherConditionCategory
import com.nexus.companion.model.WeatherLocationMode
import com.nexus.companion.model.WeatherState
import com.nexus.companion.ui.components.NexusCharacterStage
import com.nexus.companion.ui.theme.NexusColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    mode: CharacterMode,
    mood: CharacterMood,
    expression: CharacterExpression,
    emotion: CompanionEmotion = CompanionEmotion.NEUTRAL,
    situation: CompanionSituation = CompanionSituation.IDLE,
    isSpeaking: Boolean = false,
    isListening: Boolean = false,
    isThinking: Boolean = false,
    speechMouthLevel: Float = 0f,
    dialogueLine: String,
    settings: CustomizationSettings,
    telemetry: DeviceTelemetry,
    notifications: NotificationSnapshot,
    gamingTimer: GamingTimerState,
    installedApps: List<LaunchableApp>,
    touchPulseNonce: Int,
    weatherState: WeatherState,
    citySearchResults: List<GeocodingCityResult>,
    isSearchingCities: Boolean,
    citySearchError: String?,
    onSelectMode: (CharacterMode) -> Unit,
    onCharacterTap: (CharacterTouchZone) -> Unit,
    onCharacterDoubleTap: (CharacterTouchZone) -> Unit,
    onCharacterLongPress: (CharacterTouchZone) -> Unit,
    onToggleTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onAdjustTimerGoal: (Int) -> Unit,
    onNotificationBadgeClick: () -> Unit,
    onLaunchApp: (LaunchableApp) -> Unit,
    onOpenChat: () -> Unit,
    onRefreshWeather: () -> Unit,
    onToggleTemperatureUnit: () -> Unit,
    onSearchCities: (String) -> Unit,
    onSelectCity: (GeocodingCityResult) -> Unit,
    onEnableAutoLocation: () -> Unit,
    onWeatherCardTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    var showAppDrawer by remember { mutableStateOf(false) }
    var showWeatherSheet by remember { mutableStateOf(false) }
    var appQuery by remember { mutableStateOf("") }
    var cityQuery by remember { mutableStateOf("") }
    var gamesOnlyFilter by remember { mutableStateOf(false) }

    val accentColor = remember(mode) {
        when (mode) {
            CharacterMode.CHARGING -> NexusColors.MintEnergy
            CharacterMode.SLEEP -> NexusColors.SleepSlate
            CharacterMode.GAMING -> NexusColors.CyanSoft
            else -> NexusColors.CyanElectric
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NexusColors.Obsidian)
    ) {
        // Full-bleed character stage as the visual center
        NexusCharacterStage(
            mode = mode,
            expression = expression,
            settings = settings,
            isPowerSaveMode = telemetry.isPowerSaveMode,
            isSpeakingOrListening = mode == CharacterMode.CONVERSATION || isSpeaking || isListening || isThinking,
            touchPulseNonce = touchPulseNonce,
            onCharacterTap = { zone ->
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onCharacterTap(zone)
            },
            onCharacterDoubleTap = { zone ->
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onCharacterDoubleTap(zone)
            },
            onCharacterLongPress = { zone ->
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onCharacterLongPress(zone)
            },
            emotion = emotion,
            situation = situation,
            isSpeaking = isSpeaking,
            isListening = isListening,
            isThinking = isThinking,
            speechMouthLevel = speechMouthLevel,
            modifier = Modifier.fillMaxSize()
        )

        // Minimal top telemetry bar (Time, Date, Real Battery %)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = telemetry.formattedTime,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = NexusColors.TextPrimary
                )
                Text(
                    text = telemetry.formattedDate,
                    fontSize = 12.sp,
                    color = NexusColors.TextSecondary
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (notifications.listenerConnected && notifications.activeCount > 0) {
                    Surface(
                        onClick = onNotificationBadgeClick,
                        color = NexusColors.Charcoal.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, NexusColors.Hairline)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.NotificationsActive,
                                contentDescription = "Active Notifications",
                                tint = accentColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${notifications.activeCount}",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NexusColors.TextPrimary
                            )
                        }
                    }
                }

                Surface(
                    color = NexusColors.Charcoal.copy(alpha = 0.88f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        1.dp,
                        if (telemetry.isCharging) NexusColors.MintEnergy.copy(alpha = 0.55f) else NexusColors.Hairline
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = if (telemetry.isCharging) {
                                Icons.Rounded.BatteryChargingFull
                            } else {
                                Icons.Rounded.BatteryStd
                            },
                            contentDescription = "Battery",
                            tint = if (telemetry.isCharging) NexusColors.MintEnergy else accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (telemetry.batteryPercent >= 0) "${telemetry.batteryPercent}%" else "--%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            color = NexusColors.TextPrimary
                        )
                    }
                }
            }
        }

        // Bottom HUD: Speech bubble + Gaming Timer (when active) + Mode Switcher + Apps Drawer button
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Gaming Timer Bar (visible in Gaming mode or whenever timer is running/non-zero)
            AnimatedVisibility(
                visible = mode == CharacterMode.GAMING || gamingTimer.isRunning || gamingTimer.elapsedSeconds > 0,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    color = NexusColors.Charcoal.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Timer,
                                contentDescription = "Gaming Timer",
                                tint = accentColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = gamingTimer.detectedGameLabel?.let {
                                        "Gaming · $it (Goal ${gamingTimer.goalMinutes}m)"
                                    } ?: "Gaming Session · Goal ${gamingTimer.goalMinutes}m",
                                    fontSize = 11.sp,
                                    color = NexusColors.TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = gamingTimer.formattedTime,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = NexusColors.TextPrimary
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                onClick = { onAdjustTimerGoal(-15) },
                                color = NexusColors.CharcoalElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, NexusColors.Hairline)
                            ) {
                                Text(
                                    text = "-15m",
                                    fontSize = 10.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = NexusColors.TextSecondary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                                )
                            }
                            Surface(
                                onClick = { onAdjustTimerGoal(15) },
                                color = NexusColors.CharcoalElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, NexusColors.Hairline)
                            ) {
                                Text(
                                    text = "+15m",
                                    fontSize = 10.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = NexusColors.TextSecondary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                                )
                            }
                            IconButton(
                                onClick = onToggleTimer,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(accentColor.copy(alpha = 0.16f))
                            ) {
                                Icon(
                                    imageVector = if (gamingTimer.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = if (gamingTimer.isRunning) "Pause Timer" else "Start Timer",
                                    tint = accentColor
                                )
                            }
                            IconButton(
                                onClick = onResetTimer,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NexusColors.CharcoalElevated)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "Reset Timer",
                                    tint = NexusColors.TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Compact Real-Time Weather Awareness Card (Open-Meteo)
            CompactWeatherCard(
                weatherState = weatherState,
                accentColor = accentColor,
                onTapCard = onWeatherCardTap,
                onRefresh = onRefreshWeather,
                onToggleUnit = onToggleTemperatureUnit,
                onOpenLocationSheet = { showWeatherSheet = true }
            )

            // Character Dialogue Card
            Surface(
                color = NexusColors.Charcoal.copy(alpha = 0.90f),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (mode == CharacterMode.CONVERSATION) onOpenChat()
                    }
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NEXUS · ${mode.label} · ${mood.label}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = accentColor
                        )
                        Text(
                            text = "${situation.label} · ${emotion.label}",
                            fontSize = 11.sp,
                            color = NexusColors.TextMuted
                        )
                    }
                    Text(
                        text = dialogueLine,
                        fontSize = 13.5.sp,
                        lineHeight = 19.sp,
                        color = NexusColors.TextPrimary,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Mode Switcher + Quick Installed App Launcher Trigger
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CharacterMode.entries.forEach { item ->
                        val selected = item == mode
                        Surface(
                            onClick = {
                                if (item == CharacterMode.CONVERSATION) {
                                    onSelectMode(item)
                                    onOpenChat()
                                } else {
                                    onSelectMode(item)
                                }
                            },
                            color = if (selected) accentColor else NexusColors.Charcoal.copy(alpha = 0.92f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(
                                1.dp,
                                if (selected) accentColor else NexusColors.Hairline
                            )
                        ) {
                            Text(
                                text = item.label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (selected) NexusColors.Obsidian else NexusColors.TextSecondary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                maxLines = 1
                            )
                        }
                    }
                }

                Surface(
                    onClick = { showAppDrawer = true },
                    color = NexusColors.CharcoalElevated,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, NexusColors.Hairline)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Apps,
                            contentDescription = "Launch App",
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Apps",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexusColors.TextPrimary
                        )
                    }
                }
            }
        }
    }

    if (showAppDrawer) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        val filteredApps = remember(installedApps, appQuery, gamesOnlyFilter) {
            val q = appQuery.trim().lowercase()
            installedApps.filter { app ->
                (!gamesOnlyFilter || app.isGame) && (q.isEmpty() || app.label.lowercase().contains(q))
            }
        }

        ModalBottomSheet(
            onDismissRequest = { showAppDrawer = false },
            sheetState = sheetState,
            containerColor = NexusColors.Charcoal,
            contentColor = NexusColors.TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (gamesOnlyFilter) {
                            "Installed Games (${filteredApps.size})"
                        } else {
                            "Installed Apps (${installedApps.size})"
                        },
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusColors.TextPrimary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(false to "All", true to "Games").forEach { (isGames, label) ->
                            val selected = gamesOnlyFilter == isGames
                            Surface(
                                onClick = { gamesOnlyFilter = isGames },
                                color = if (selected) accentColor else NexusColors.CharcoalElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (selected) accentColor else NexusColors.Hairline)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (selected) NexusColors.Obsidian else NexusColors.TextSecondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = appQuery,
                    onValueChange = { appQuery = it },
                    placeholder = { Text("Search installed apps...", color = NexusColors.TextMuted) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                            tint = NexusColors.TextSecondary
                        )
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexusColors.CyanElectric,
                        unfocusedBorderColor = NexusColors.Hairline,
                        focusedTextColor = NexusColors.TextPrimary,
                        unfocusedTextColor = NexusColors.TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (filteredApps.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No matching apps found.",
                            color = NexusColors.TextMuted,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            val iconBitmap = remember(app.packageName) {
                                try {
                                    app.icon?.toBitmap(width = 84, height = 84)?.asImageBitmap()
                                } catch (_: Throwable) {
                                    null
                                }
                            }
                            Column(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        showAppDrawer = false
                                        onLaunchApp(app)
                                    }
                                    .padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(NexusColors.CharcoalElevated)
                                        .border(1.dp, NexusColors.Hairline, RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (iconBitmap != null) {
                                        Image(
                                            bitmap = iconBitmap,
                                            contentDescription = app.label,
                                            modifier = Modifier.size(38.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Rounded.Apps,
                                            contentDescription = app.label,
                                            tint = NexusColors.CyanElectric
                                        )
                                    }
                                }
                                Text(
                                    text = app.label,
                                    fontSize = 11.sp,
                                    color = NexusColors.TextSecondary,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showWeatherSheet) {
        val weatherSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showWeatherSheet = false },
            sheetState = weatherSheetState,
            containerColor = NexusColors.Charcoal,
            contentColor = NexusColors.TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 26.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Weather Location",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusColors.TextPrimary
                        )
                        Text(
                            text = "Current: ${weatherState.savedLocation.displayName}",
                            fontSize = 11.5.sp,
                            color = NexusColors.TextSecondary
                        )
                    }
                    Surface(
                        onClick = onToggleTemperatureUnit,
                        color = NexusColors.CharcoalElevated,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "Unit: ${weatherState.temperatureUnit.symbol}",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = accentColor,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        onEnableAutoLocation()
                        showWeatherSheet = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = accentColor.copy(alpha = 0.16f),
                        contentColor = accentColor
                    ),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MyLocation,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (weatherState.savedLocation.mode == WeatherLocationMode.AUTO_DEVICE) {
                            "Refresh Automatic Device Location"
                        } else {
                            "Use Automatic Location (Approximate)"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                OutlinedTextField(
                    value = cityQuery,
                    onValueChange = { next ->
                        cityQuery = next
                        onSearchCities(next)
                    },
                    placeholder = {
                        Text("Search city manually (e.g. Tokyo, Seoul)...", color = NexusColors.TextMuted)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                            tint = NexusColors.TextSecondary
                        )
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accentColor,
                        unfocusedBorderColor = NexusColors.Hairline,
                        focusedTextColor = NexusColors.TextPrimary,
                        unfocusedTextColor = NexusColors.TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (isSearchingCities) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            color = accentColor,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Searching Open-Meteo cities...",
                            fontSize = 12.sp,
                            color = NexusColors.TextSecondary
                        )
                    }
                } else if (!citySearchError.isNullOrBlank()) {
                    Text(
                        text = citySearchError,
                        fontSize = 12.sp,
                        color = NexusColors.CoralAlert
                    )
                }

                if (citySearchResults.isNotEmpty()) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        lazyItems(citySearchResults, key = { "${it.id}_${it.latitude}_${it.longitude}" }) { city ->
                            Surface(
                                onClick = {
                                    onSelectCity(city)
                                    cityQuery = ""
                                    showWeatherSheet = false
                                },
                                color = NexusColors.CharcoalElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, NexusColors.Hairline),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.LocationOn,
                                            contentDescription = null,
                                            tint = accentColor,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = city.displayLabel,
                                            fontSize = 13.sp,
                                            color = NexusColors.TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        text = "${String.format(java.util.Locale.US, "%.2f", city.latitude)}, ${String.format(java.util.Locale.US, "%.2f", city.longitude)}",
                                        fontSize = 10.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = NexusColors.TextMuted
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    text = "Weather by Open-Meteo · Approximate location is checked only on-demand.",
                    fontSize = 10.5.sp,
                    color = NexusColors.TextMuted
                )
            }
        }
    }
}

@Composable
private fun CompactWeatherCard(
    weatherState: WeatherState,
    accentColor: Color,
    onTapCard: () -> Unit,
    onRefresh: () -> Unit,
    onToggleUnit: () -> Unit,
    onOpenLocationSheet: () -> Unit
) {
    val snap = weatherState.snapshot
    Surface(
        color = NexusColors.Charcoal.copy(alpha = 0.88f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (weatherState.isOffline) NexusColors.CoralAlert.copy(alpha = 0.45f) else NexusColors.Hairline
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (snap != null) onTapCard() else onOpenLocationSheet()
            }
    ) {
        if (snap == null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CloudQueue,
                        contentDescription = "Weather",
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "Real-Time Weather · Open-Meteo",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexusColors.TextPrimary
                        )
                        Text(
                            text = weatherState.errorMessage ?: "Choose a city or enable Auto Location",
                            fontSize = 10.5.sp,
                            color = if (weatherState.errorMessage != null) NexusColors.CoralAlert else NexusColors.TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                OutlinedButton(
                    onClick = onOpenLocationSheet,
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (weatherState.isLoading) "Loading..." else "Set City",
                        fontSize = 11.sp,
                        color = accentColor
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Icon(
                            imageVector = weatherConditionIcon(snap.conditionCategory),
                            contentDescription = snap.conditionLabel,
                            tint = accentColor,
                            modifier = Modifier.size(17.dp)
                        )
                        Text(
                            text = snap.locationName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusColors.TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (weatherState.isOffline || snap.isFromCache) {
                            Icon(
                                imageVector = Icons.Rounded.WifiOff,
                                contentDescription = "Cached",
                                tint = NexusColors.CoralAlert,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            onClick = onToggleUnit,
                            color = NexusColors.CharcoalElevated,
                            shape = RoundedCornerShape(7.dp),
                            border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
                        ) {
                            Text(
                                text = snap.formatTemperature(weatherState.temperatureUnit),
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = accentColor,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }

                        Surface(
                            onClick = onOpenLocationSheet,
                            color = NexusColors.CharcoalElevated,
                            shape = RoundedCornerShape(7.dp),
                            border = BorderStroke(1.dp, NexusColors.Hairline)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LocationOn,
                                contentDescription = "Change Location",
                                tint = NexusColors.TextSecondary,
                                modifier = Modifier
                                    .padding(4.dp)
                                    .size(14.dp)
                            )
                        }

                        Surface(
                            onClick = onRefresh,
                            color = NexusColors.CharcoalElevated,
                            shape = RoundedCornerShape(7.dp),
                            border = BorderStroke(1.dp, NexusColors.Hairline)
                        ) {
                            if (weatherState.isLoading) {
                                CircularProgressIndicator(
                                    color = accentColor,
                                    strokeWidth = 1.6.dp,
                                    modifier = Modifier
                                        .padding(4.dp)
                                        .size(14.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "Refresh Weather",
                                    tint = NexusColors.TextSecondary,
                                    modifier = Modifier
                                        .padding(4.dp)
                                        .size(14.dp)
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = snap.conditionLabel,
                            fontSize = 11.sp,
                            color = NexusColors.TextSecondary
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WaterDrop,
                                contentDescription = null,
                                tint = NexusColors.TextMuted,
                                modifier = Modifier.size(11.dp)
                            )
                            Text(
                                text = "${snap.relativeHumidityPercent}%",
                                fontSize = 10.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NexusColors.TextSecondary
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Air,
                                contentDescription = null,
                                tint = NexusColors.TextMuted,
                                modifier = Modifier.size(11.dp)
                            )
                            Text(
                                text = snap.formatWindSpeed(),
                                fontSize = 10.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NexusColors.TextSecondary
                            )
                        }
                    }

                    Text(
                        text = "${if (snap.isFromCache || weatherState.isOffline) "Cached" else "Upd"} ${snap.formatUpdatedTime()} · Open-Meteo",
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NexusColors.TextMuted
                    )
                }

                if (!weatherState.errorMessage.isNullOrBlank()) {
                    Text(
                        text = weatherState.errorMessage,
                        fontSize = 10.sp,
                        color = NexusColors.CoralAlert,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

private fun weatherConditionIcon(category: WeatherConditionCategory): ImageVector {
    return when (category) {
        WeatherConditionCategory.CLEAR_SUNNY -> Icons.Rounded.WbSunny
        WeatherConditionCategory.PARTLY_CLOUDY -> Icons.Rounded.CloudQueue
        WeatherConditionCategory.CLOUDY -> Icons.Rounded.Cloud
        WeatherConditionCategory.FOGGY -> Icons.Rounded.Grain
        WeatherConditionCategory.RAINY -> Icons.Rounded.WaterDrop
        WeatherConditionCategory.SNOWY -> Icons.Rounded.AcUnit
        WeatherConditionCategory.THUNDERSTORM -> Icons.Rounded.Thunderstorm
    }
}

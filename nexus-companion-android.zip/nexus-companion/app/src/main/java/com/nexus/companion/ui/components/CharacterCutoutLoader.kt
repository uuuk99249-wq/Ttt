package com.nexus.companion.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.nexus.companion.R
import com.nexus.companion.model.CharacterPoseKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap

data class ResolvedCharacterPose(
    val bitmap: ImageBitmap,
    val poseKey: CharacterPoseKey,
    val isDedicatedPoseAsset: Boolean
)

object CharacterCutoutLoader {

    @Volatile
    private var cachedBaseBitmap: ImageBitmap? = null
    private val cachedPoseBitmaps = ConcurrentHashMap<CharacterPoseKey, ImageBitmap>()

    /**
     * Loads the exact user-provided high-res character drawable (1164x3428 RGBA)
     * with inScaled = false and smart power-of-two downsampling (<= 2048px height)
     * so mid-range Android devices get crisp sharpness without GPU texture OOM.
     */
    suspend fun loadCharacterBitmap(context: Context): ImageBitmap = withContext(Dispatchers.Default) {
        cachedBaseBitmap?.let { return@withContext it }
        val imageBitmap = decodeAndTrimDrawable(context, R.drawable.nexus_character)
        cachedBaseBitmap = imageBitmap
        imageBitmap
    }

    /**
     * Checks if an optional pose-specific character drawable (e.g. R.drawable.nexus_pose_thinking)
     * exists in resources. If present, loads and caches it; otherwise falls back cleanly to the
     * base character drawable while reporting isDedicatedPoseAsset = false.
     */
    suspend fun loadPoseBitmap(
        context: Context,
        poseKey: CharacterPoseKey
    ): ResolvedCharacterPose = withContext(Dispatchers.Default) {
        if (poseKey == CharacterPoseKey.DEFAULT_STANDING) {
            return@withContext ResolvedCharacterPose(
                bitmap = loadCharacterBitmap(context),
                poseKey = poseKey,
                isDedicatedPoseAsset = false
            )
        }

        cachedPoseBitmaps[poseKey]?.let { cached ->
            return@withContext ResolvedCharacterPose(
                bitmap = cached,
                poseKey = poseKey,
                isDedicatedPoseAsset = true
            )
        }

        val resId = context.resources.getIdentifier(
            poseKey.drawableResourceName,
            "drawable",
            context.packageName
        )
        if (resId != 0) {
            val poseBmp = runCatching { decodeAndTrimDrawable(context, resId) }.getOrNull()
            if (poseBmp != null) {
                cachedPoseBitmaps[poseKey] = poseBmp
                return@withContext ResolvedCharacterPose(
                    bitmap = poseBmp,
                    poseKey = poseKey,
                    isDedicatedPoseAsset = true
                )
            }
        }

        ResolvedCharacterPose(
            bitmap = loadCharacterBitmap(context),
            poseKey = CharacterPoseKey.DEFAULT_STANDING,
            isDedicatedPoseAsset = false
        )
    }

    private fun decodeAndTrimDrawable(context: Context, resId: Int): ImageBitmap {
        val bounds = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
            inScaled = false
        }
        BitmapFactory.decodeResource(context.resources, resId, bounds)

        var sampleSize = 1
        while ((bounds.outHeight / sampleSize) > 2048 || (bounds.outWidth / sampleSize) > 2048) {
            sampleSize *= 2
        }

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inScaled = false
            inSampleSize = sampleSize
            inMutable = true
        }
        val raw = BitmapFactory.decodeResource(context.resources, resId, options)
        val processed = if (raw.hasAlpha()) {
            raw
        } else {
            removeExteriorWhiteBackdrop(raw)
        }
        return processed.asImageBitmap()
    }

    private fun removeExteriorWhiteBackdrop(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        val pixels = IntArray(w * h)
        source.getPixels(pixels, 0, w, 0, 0, w, h)

        val visited = BooleanArray(w * h)
        val queue = ArrayDeque<Int>(w * 2 + h * 2)

        fun isExteriorWhite(pixel: Int): Boolean {
            val r = Color.red(pixel)
            val g = Color.green(pixel)
            val b = Color.blue(pixel)
            val maxChannel = maxOf(r, g, b)
            val minChannel = minOf(r, g, b)
            return minChannel >= 232 && (maxChannel - minChannel) <= 18
        }

        fun enqueueIfWhite(x: Int, y: Int) {
            if (x < 0 || x >= w || y < 0 || y >= h) return
            val idx = y * w + x
            if (!visited[idx] && isExteriorWhite(pixels[idx])) {
                visited[idx] = true
                queue.addLast(idx)
            }
        }

        for (x in 0 until w) {
            enqueueIfWhite(x, 0)
            enqueueIfWhite(x, h - 1)
        }
        for (y in 0 until h) {
            enqueueIfWhite(0, y)
            enqueueIfWhite(w - 1, y)
        }

        while (queue.isNotEmpty()) {
            val idx = queue.removeFirst()
            pixels[idx] = Color.TRANSPARENT
            val x = idx % w
            val y = idx / w
            enqueueIfWhite(x - 1, y)
            enqueueIfWhite(x + 1, y)
            enqueueIfWhite(x, y - 1)
            enqueueIfWhite(x, y + 1)
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        if (out !== source) {
            source.recycle()
        }
        return out
    }
}

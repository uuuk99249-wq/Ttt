package com.nexus.companion.system

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.nexus.companion.model.NotificationSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NexusNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshActiveNotifications(connected = true)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        _snapshot.value = NotificationSnapshot(listenerConnected = false)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refreshActiveNotifications(connected = true)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refreshActiveNotifications(connected = true)
    }

    private fun refreshActiveNotifications(connected: Boolean) {
        val list = try {
            activeNotifications?.filter { !it.isOngoing && it.packageName != packageName }.orEmpty()
        } catch (_: Throwable) {
            emptyList()
        }

        val latest = list.maxByOrNull { it.postTime }
        val latestTitle = latest?.notification?.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val latestApp = latest?.packageName?.let { pkg ->
            try {
                val appInfo = packageManager.getApplicationInfo(pkg, 0)
                packageManager.getApplicationLabel(appInfo).toString()
            } catch (_: Throwable) {
                pkg
            }
        }

        _snapshot.value = NotificationSnapshot(
            listenerConnected = connected,
            activeCount = list.size,
            latestApp = latestApp,
            latestTitle = latestTitle
        )
    }

    companion object {
        private val _snapshot = MutableStateFlow(NotificationSnapshot())
        val snapshot: StateFlow<NotificationSnapshot> = _snapshot.asStateFlow()

        fun isPermissionEnabled(context: Context): Boolean {
            val componentName = ComponentName(context, NexusNotificationListener::class.java)
            val enabledListeners = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            return enabledListeners.split(':').any { entry ->
                ComponentName.unflattenFromString(entry) == componentName
            }
        }
    }
}

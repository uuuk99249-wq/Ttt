package com.nexus.companion

import android.app.Application

class NexusApplication : Application()

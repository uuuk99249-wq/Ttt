package com.nexus.companion.system

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GameDetectionManager(private val context: Context) {

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Checks recent foreground app events via Android's UsageStatsManager when Usage Access
     * is explicitly granted by the user. Returns the label of the most recently foregrounded
     * installed game within the last 10 minutes, or null if none / permission not granted.
     */
    suspend fun detectRecentForegroundGameLabel(): String? = withContext(Dispatchers.IO) {
        if (!hasUsageStatsPermission()) return@withContext null

        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return@withContext null

        val endMs = System.currentTimeMillis()
        val startMs = endMs - 10 * 60 * 1000L
        val events = try {
            usm.queryEvents(startMs, endMs)
        } catch (_: SecurityException) {
            return@withContext null
        } ?: return@withContext null

        var latestGamePkg: String? = null
        var latestTimestamp = 0L
        val event = UsageEvents.Event()

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED &&
                event.packageName != context.packageName &&
                event.timeStamp >= latestTimestamp
            ) {
                if (isPackageAGame(event.packageName)) {
                    latestTimestamp = event.timeStamp
                    latestGamePkg = event.packageName
                }
            }
        }

        val pkg = latestGamePkg ?: return@withContext null
        return@withContext try {
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(pkg, 0)
            }
            pm.getApplicationLabel(info).toString()
        } catch (_: Throwable) {
            null
        }
    }

    private fun isPackageAGame(packageName: String): Boolean {
        return try {
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            @Suppress("DEPRECATION")
            val legacyFlag = (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            info.category == ApplicationInfo.CATEGORY_GAME || legacyFlag
        } catch (_: Throwable) {
            false
        }
    }
}

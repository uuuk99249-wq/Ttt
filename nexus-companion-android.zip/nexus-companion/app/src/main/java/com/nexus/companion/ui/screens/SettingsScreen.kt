package com.nexus.companion.ui.screens

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.companion.model.CompanionMemory
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.model.DeviceTelemetry
import com.nexus.companion.model.PermissionSnapshot
import com.nexus.companion.model.TemperatureUnit
import com.nexus.companion.model.WeatherState
import com.nexus.companion.ui.theme.NexusColors
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: CustomizationSettings,
    memory: CompanionMemory,
    permissions: PermissionSnapshot,
    telemetry: DeviceTelemetry,
    weatherState: WeatherState,
    aiServerUrl: String,
    speechServiceAvailable: Boolean,
    onUpdateSettings: ((CustomizationSettings) -> CustomizationSettings) -> Unit,
    onSetMemoryEnabled: (Boolean) -> Unit,
    onClearMemory: () -> Unit,
    onSaveAiServerUrl: (String) -> Unit,
    onTestAiServerUrl: suspend (String) -> Result<String>,
    onRequestMicrophone: () -> Unit,
    onRequestLocation: () -> Unit,
    onToggleTemperatureUnit: () -> Unit,
    onRequestNotifications: () -> Unit,
    onOpenNotificationAccessSettings: () -> Unit,
    onOpenUsageAccessSettings: () -> Unit,
    onClearChatHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    var draftUrl by remember(aiServerUrl) { mutableStateOf(aiServerUrl) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusColors.Obsidian)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Settings & Permissions",
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            color = NexusColors.TextPrimary
        )

        // Permissions
        SettingsCard(title = "Android Permissions") {
            PermissionRow(
                title = "Microphone (Voice Chat)",
                subtitle = if (!speechServiceAvailable) {
                    "Device speech recognition service unavailable"
                } else if (permissions.microphoneGranted) {
                    "Granted · Used only when tapping Mic in Chat"
                } else {
                    "Not granted · Requested only when you use voice input"
                },
                granted = permissions.microphoneGranted,
                buttonText = if (permissions.microphoneGranted) "Granted" else "Allow",
                enabled = !permissions.microphoneGranted && speechServiceAvailable,
                onClick = onRequestMicrophone
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                PermissionRow(
                    title = "Notifications (Timer Alerts)",
                    subtitle = if (permissions.notificationsGranted) {
                        "Granted on Android 13+"
                    } else {
                        "Optional · Used for Gaming session reminders"
                    },
                    granted = permissions.notificationsGranted,
                    buttonText = if (permissions.notificationsGranted) "Granted" else "Allow",
                    enabled = !permissions.notificationsGranted,
                    onClick = onRequestNotifications
                )
            }

            PermissionRow(
                title = "Notification Access (Optional)",
                subtitle = if (permissions.notificationListenerGranted) {
                    "Enabled · NEXUS can see active notification count"
                } else {
                    "Optional · Opens Android Settings so NEXUS can summarize unread pings"
                },
                granted = permissions.notificationListenerGranted,
                buttonText = if (permissions.notificationListenerGranted) "Manage" else "Configure",
                enabled = true,
                onClick = onOpenNotificationAccessSettings
            )

            PermissionRow(
                title = "Game Detection (Usage Access)",
                subtitle = if (permissions.usageStatsGranted) {
                    "Enabled · Detects active games automatically in Gaming Mode"
                } else {
                    "Optional · Opens Android Usage Access to detect active games"
                },
                granted = permissions.usageStatsGranted,
                buttonText = if (permissions.usageStatsGranted) "Manage" else "Configure",
                enabled = true,
                onClick = onOpenUsageAccessSettings
            )

            PermissionRow(
                title = "Location (Real-Time Weather)",
                subtitle = if (permissions.locationGranted) {
                    "Granted · Approximate coordinates retrieved only on demand (no continuous GPS)"
                } else {
                    "Optional · Requested only when choosing Auto Location; manual city search needs no permission"
                },
                granted = permissions.locationGranted,
                buttonText = if (permissions.locationGranted) "Granted" else "Allow",
                enabled = !permissions.locationGranted,
                onClick = onRequestLocation
            )
        }

        // Behavior, Voice & Power Optimization
        SettingsCard(title = "Behavior, Voice & Battery") {
            ToggleRow(
                title = "Auto Charging & Low-Battery Modes",
                subtitle = "Automatically switch to Charging when plugged in, Sleep below 15%",
                checked = settings.personality.autoModeSwitching,
                onCheckedChange = { checked ->
                    onUpdateSettings {
                        it.copy(personality = it.personality.copy(autoModeSwitching = checked))
                    }
                }
            )

            ToggleRow(
                title = "Battery Saver Animation Throttle",
                subtitle = "Reduce animation frame rate when Android Battery Saver is active",
                checked = settings.batterySaverThrottle,
                onCheckedChange = { checked ->
                    onUpdateSettings { it.copy(batterySaverThrottle = checked) }
                }
            )

            ToggleRow(
                title = "Spoken Replies (Male Text-to-Speech)",
                subtitle = "Speak NEXUS replies aloud in Chat (interruptible anytime)",
                checked = settings.personality.voiceOutputEnabled,
                onCheckedChange = { checked ->
                    onUpdateSettings {
                        it.copy(
                            personality = it.personality.copy(
                                voiceOutputEnabled = checked,
                                voiceConversationMode = if (!checked) false else it.personality.voiceConversationMode
                            )
                        )
                    }
                }
            )

            ToggleRow(
                title = "Hands-Free Voice Conversation Mode",
                subtitle = "Automatically listen for your next turn after NEXUS finishes speaking",
                checked = settings.personality.voiceConversationMode,
                onCheckedChange = { checked ->
                    onUpdateSettings {
                        it.copy(
                            personality = it.personality.copy(
                                voiceConversationMode = checked,
                                voiceOutputEnabled = if (checked) true else it.personality.voiceOutputEnabled
                            )
                        )
                    }
                }
            )

            ToggleRow(
                title = "Fahrenheit Weather Display (°F)",
                subtitle = "Toggle between Celsius (°C) and Fahrenheit (°F) for Open-Meteo weather",
                checked = weatherState.temperatureUnit == TemperatureUnit.FAHRENHEIT,
                onCheckedChange = { onToggleTemperatureUnit() }
            )
        }

        // Persistent Memory Controls
        SettingsCard(title = "Persistent Companion Memory") {
            ToggleRow(
                title = "Remember Name, Interests & Context",
                subtitle = "Stores useful facts locally on-device; view, edit, or delete anytime from Chat",
                checked = memory.enabled,
                onCheckedChange = onSetMemoryEnabled
            )

            Text(
                text = "Saved items: ${memory.totalCount}" +
                    if (memory.preferredName.isNotBlank()) " · Name: ${memory.preferredName}" else "",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = NexusColors.TextSecondary
            )

            OutlinedButton(
                onClick = onClearMemory,
                border = BorderStroke(1.dp, NexusColors.CoralAlert.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Clear Saved Memories", color = NexusColors.CoralAlert, fontSize = 13.sp)
            }
        }

        // AI Relay Server Configuration (Zero embedded API keys)
        SettingsCard(title = "Live AI Backend Endpoint") {
            Text(
                text = "NEXUS never stores API keys inside the Android app and never fakes live AI replies offline. Enter your backend server's /api/nexus/chat endpoint URL below.",
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = NexusColors.TextSecondary
            )

            OutlinedTextField(
                value = draftUrl,
                onValueChange = { draftUrl = it },
                placeholder = {
                    Text(
                        "https://your-server/api/nexus/chat",
                        color = NexusColors.TextMuted,
                        fontSize = 12.5.sp
                    )
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NexusColors.CyanElectric,
                    unfocusedBorderColor = NexusColors.Hairline,
                    focusedTextColor = NexusColors.TextPrimary,
                    unfocusedTextColor = NexusColors.TextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { draftUrl = "http://10.0.2.2:3000/api/nexus/chat" },
                    border = BorderStroke(1.dp, NexusColors.Hairline),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Emulator Local", color = NexusColors.TextSecondary, fontSize = 11.5.sp)
                }

                OutlinedButton(
                    onClick = {
                        draftUrl = ""
                        onSaveAiServerUrl("")
                        testResult = "Cleared endpoint."
                    },
                    border = BorderStroke(1.dp, NexusColors.Hairline)
                ) {
                    Text("Clear", color = NexusColors.TextSecondary, fontSize = 11.5.sp)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        onSaveAiServerUrl(draftUrl)
                        testResult = "Saved endpoint."
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexusColors.CyanElectric,
                        contentColor = NexusColors.Obsidian
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Save URL", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = {
                        testing = true
                        testResult = "Testing connection..."
                        scope.launch {
                            val result = onTestAiServerUrl(draftUrl)
                            testing = false
                            testResult = result.fold(
                                onSuccess = { msg -> msg },
                                onFailure = { err -> "Failed: ${err.message ?: err.javaClass.simpleName}" }
                            )
                        }
                    },
                    enabled = !testing && draftUrl.isNotBlank(),
                    border = BorderStroke(1.dp, NexusColors.Hairline),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Test", color = NexusColors.TextPrimary, fontSize = 13.sp)
                }
            }

            if (!testResult.isNullOrBlank()) {
                Text(
                    text = testResult!!,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NexusColors.CyanElectric
                )
            }
        }

        // Data & Device Info
        SettingsCard(title = "Local Data & Hardware") {
            Text(
                text = "Battery: ${if (telemetry.batteryPercent >= 0) "${telemetry.batteryPercent}%" else "Unavailable"} · Source: ${telemetry.chargingSource}" +
                    (telemetry.batteryTempCelsius?.let { " · ${String.format(java.util.Locale.US, "%.1f", it)}°C" } ?: ""),
                fontSize = 12.5.sp,
                fontFamily = FontFamily.Monospace,
                color = NexusColors.TextSecondary
            )
            Text(
                text = "Android SDK ${Build.VERSION.SDK_INT} (minSdk 31 / Android 12+)",
                fontSize = 12.5.sp,
                fontFamily = FontFamily.Monospace,
                color = NexusColors.TextMuted
            )

            OutlinedButton(
                onClick = onClearChatHistory,
                border = BorderStroke(1.dp, NexusColors.CoralAlert.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Clear Local Conversation History", color = NexusColors.CoralAlert, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        color = NexusColors.Charcoal,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, NexusColors.Hairline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = NexusColors.CyanElectric
            )
            content()
        }
    }
}

@Composable
private fun PermissionRow(
    title: String,
    subtitle: String,
    granted: Boolean,
    buttonText: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 10.dp)
        ) {
            Text(text = title, fontSize = 13.5.sp, color = NexusColors.TextPrimary)
            Text(text = subtitle, fontSize = 12.sp, color = NexusColors.TextSecondary)
        }
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            border = BorderStroke(
                1.dp,
                if (granted) NexusColors.MintEnergy.copy(alpha = 0.55f) else NexusColors.CyanElectric
            )
        ) {
            Text(
                text = buttonText,
                fontSize = 12.sp,
                color = if (granted) NexusColors.MintEnergy else NexusColors.CyanElectric
            )
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(text = title, fontSize = 13.5.sp, color = NexusColors.TextPrimary)
            Text(text = subtitle, fontSize = 12.sp, color = NexusColors.TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NexusColors.Obsidian,
                checkedTrackColor = NexusColors.CyanElectric
            )
        )
    }
}

package com.nexus.companion.weather

import com.nexus.companion.model.GeocodingCityResult
import com.nexus.companion.model.WeatherConditionCategory
import com.nexus.companion.model.WeatherSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.Locale

class WeatherNetworkException(
    message: String,
    val isOffline: Boolean
) : Exception(message)

/**
 * Pure Open-Meteo Forecast & Geocoding API client isolated from UI layers.
 * Uses Open-Meteo directly with zero API key or account setup required.
 */
class OpenMeteoWeatherService {

    suspend fun searchCities(query: String): Result<List<GeocodingCityResult>> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            return@withContext Result.success(emptyList())
        }
        return@withContext try {
            val encoded = URLEncoder.encode(trimmed, Charsets.UTF_8.name())
            val endpoint = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=6&language=en&format=json"
            val body = executeGet(endpoint)
            Result.success(parseGeocodingJson(body))
        } catch (e: UnknownHostException) {
            Result.failure(WeatherNetworkException("Offline: unable to reach Open-Meteo geocoding.", isOffline = true))
        } catch (e: ConnectException) {
            Result.failure(WeatherNetworkException("Network connection refused by Open-Meteo.", isOffline = true))
        } catch (e: SocketTimeoutException) {
            Result.failure(WeatherNetworkException("City search timed out. Try again.", isOffline = true))
        } catch (e: Exception) {
            Result.failure(WeatherNetworkException(e.message ?: "City search failed.", isOffline = false))
        }
    }

    suspend fun fetchCurrentWeather(
        latitude: Double,
        longitude: Double,
        locationName: String
    ): Result<WeatherSnapshot> = withContext(Dispatchers.IO) {
        return@withContext try {
            val latStr = String.format(Locale.US, "%.4f", latitude)
            val lonStr = String.format(Locale.US, "%.4f", longitude)
            val endpoint =
                "https://api.open-meteo.com/v1/forecast?latitude=$latStr&longitude=$lonStr" +
                    "&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&timezone=auto"
            val body = executeGet(endpoint)
            val snapshot = parseForecastJson(body, locationName = locationName, fetchedAtMs = System.currentTimeMillis())
            Result.success(snapshot)
        } catch (e: UnknownHostException) {
            Result.failure(WeatherNetworkException("Offline: check internet connection.", isOffline = true))
        } catch (e: ConnectException) {
            Result.failure(WeatherNetworkException("Offline: cannot reach weather server.", isOffline = true))
        } catch (e: SocketTimeoutException) {
            Result.failure(WeatherNetworkException("Weather request timed out.", isOffline = true))
        } catch (e: Exception) {
            Result.failure(WeatherNetworkException(e.message ?: "Failed to load weather.", isOffline = false))
        }
    }

    private fun executeGet(endpointUrl: String): String {
        val url = URL(endpointUrl)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText).orEmpty()
            if (code !in 200..299) {
                throw IllegalStateException("Open-Meteo HTTP $code")
            }
            body
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        fun parseGeocodingJson(rawJson: String): List<GeocodingCityResult> {
            val root = JSONObject(rawJson)
            val results = root.optJSONArray("results") ?: return emptyList()
            return buildList {
                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    val name = item.optString("name").trim()
                    if (name.isEmpty()) continue
                    val lat = item.optDouble("latitude", Double.NaN)
                    val lon = item.optDouble("longitude", Double.NaN)
                    if (lat.isNaN() || lon.isNaN()) continue
                    add(
                        GeocodingCityResult(
                            id = item.optLong("id", i.toLong()),
                            name = name,
                            admin1 = item.optString("admin1", "").trim(),
                            country = item.optString("country", "").trim(),
                            latitude = lat,
                            longitude = lon
                        )
                    )
                }
            }
        }

        fun parseForecastJson(
            rawJson: String,
            locationName: String,
            fetchedAtMs: Long
        ): WeatherSnapshot {
            val root = JSONObject(rawJson)
            val current = root.optJSONObject("current")
                ?: throw IllegalStateException("Open-Meteo response missing 'current' data.")

            val tempC = current.optDouble("temperature_2m", Double.NaN)
            if (tempC.isNaN()) {
                throw IllegalStateException("Open-Meteo response missing temperature.")
            }
            val humidity = current.optInt("relative_humidity_2m", 0).coerceIn(0, 100)
            val windKmh = current.optDouble("wind_speed_10m", 0.0).coerceAtLeast(0.0)
            val precipMm = current.optDouble("precipitation", 0.0).coerceAtLeast(0.0)
            val code = current.optInt("weather_code", 0)
            val (category, label) = interpretWmoCode(code)

            return WeatherSnapshot(
                locationName = locationName.ifBlank { "Selected Location" },
                temperatureCelsius = tempC,
                relativeHumidityPercent = humidity,
                windSpeedKmh = windKmh,
                precipitationMm = precipMm,
                weatherCode = code,
                conditionCategory = category,
                conditionLabel = label,
                fetchedAtMs = fetchedAtMs,
                isFromCache = false
            )
        }

        /**
         * Official WMO Weather interpretation codes (WW) returned by Open-Meteo.
         */
        fun interpretWmoCode(code: Int): Pair<WeatherConditionCategory, String> {
            return when (code) {
                0 -> WeatherConditionCategory.CLEAR_SUNNY to "Clear Sky"
                1 -> WeatherConditionCategory.CLEAR_SUNNY to "Mainly Clear"
                2 -> WeatherConditionCategory.PARTLY_CLOUDY to "Partly Cloudy"
                3 -> WeatherConditionCategory.CLOUDY to "Overcast"
                45, 48 -> WeatherConditionCategory.FOGGY to if (code == 48) "Rime Fog" else "Foggy"
                51, 53, 55 -> WeatherConditionCategory.RAINY to "Drizzle"
                56, 57 -> WeatherConditionCategory.RAINY to "Freezing Drizzle"
                61 -> WeatherConditionCategory.RAINY to "Light Rain"
                63 -> WeatherConditionCategory.RAINY to "Moderate Rain"
                65 -> WeatherConditionCategory.RAINY to "Heavy Rain"
                66, 67 -> WeatherConditionCategory.RAINY to "Freezing Rain"
                71 -> WeatherConditionCategory.SNOWY to "Light Snow"
                73 -> WeatherConditionCategory.SNOWY to "Moderate Snow"
                75 -> WeatherConditionCategory.SNOWY to "Heavy Snow"
                77 -> WeatherConditionCategory.SNOWY to "Snow Grains"
                80, 81, 82 -> WeatherConditionCategory.RAINY to "Rain Showers"
                85, 86 -> WeatherConditionCategory.SNOWY to "Snow Showers"
                95 -> WeatherConditionCategory.THUNDERSTORM to "Thunderstorm"
                96, 99 -> WeatherConditionCategory.THUNDERSTORM to "Thunderstorm & Hail"
                else -> WeatherConditionCategory.CLOUDY to "Cloudy"
            }
        }
    }
}

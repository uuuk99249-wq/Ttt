package com.nexus.companion

import com.nexus.companion.ai.NexusAiService
import com.nexus.companion.animation.BlinkMode
import com.nexus.companion.animation.BrowStyle
import com.nexus.companion.animation.MouthStyle
import com.nexus.companion.animation.NexusAnimationController
import com.nexus.companion.animation.StageEffectOverlay
import com.nexus.companion.model.CharacterMode
import com.nexus.companion.model.CharacterPoseKey
import com.nexus.companion.model.CompanionEmotion
import com.nexus.companion.model.CompanionMemory
import com.nexus.companion.model.CompanionSituation
import com.nexus.companion.model.CustomizationSettings
import com.nexus.companion.model.DeviceTelemetry
import com.nexus.companion.model.GamingTimerState
import com.nexus.companion.model.NotificationSnapshot
import com.nexus.companion.model.PersonalitySettings
import com.nexus.companion.model.ReplySource
import com.nexus.companion.model.ResponseStyle
import com.nexus.companion.model.TemperatureUnit
import com.nexus.companion.model.WeatherConditionCategory
import com.nexus.companion.weather.OpenMeteoWeatherService
import com.nexus.companion.weather.WeatherReactionEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NexusUnitTest {

    @Test
    fun gamingTimerFormatsMinutesAndHours() {
        val underHour = GamingTimerState(isRunning = true, elapsedSeconds = 125L)
        assertEquals("02:05", underHour.formattedTime)

        val overHour = GamingTimerState(isRunning = true, elapsedSeconds = 3661L)
        assertEquals("01:01:01", overHour.formattedTime)
    }

    @Test
    fun missingBackendUrlReturnsHonestErrorWithoutFakingAi() = runBlocking {
        val service = NexusAiService()
        val result = service.generateReply(
            userMessage = "Hey NEXUS, how's it going?",
            history = emptyList(),
            mode = CharacterMode.NORMAL,
            telemetry = DeviceTelemetry(batteryPercent = 72, isCharging = false),
            personality = PersonalitySettings(),
            notifications = NotificationSnapshot(),
            serverUrl = ""
        )

        assertTrue(result.isError)
        assertEquals(ReplySource.SYSTEM_NOTICE, result.source)
        assertTrue(result.text.contains("Settings", ignoreCase = true))
    }

    @Test
    fun unreachableEndpointReturnsHonestNetworkError() = runBlocking {
        val service = NexusAiService()
        val result = service.generateReply(
            userMessage = "Hello",
            history = emptyList(),
            mode = CharacterMode.CONVERSATION,
            telemetry = DeviceTelemetry(batteryPercent = 80),
            personality = PersonalitySettings(),
            notifications = NotificationSnapshot(),
            serverUrl = "http://127.0.0.1:1/api/nexus/chat"
        )

        assertTrue(result.isError)
        assertEquals(ReplySource.SYSTEM_NOTICE, result.source)
    }

    @Test
    fun companionMemoryCountsSavedFieldsAccurately() {
        val empty = CompanionMemory()
        assertEquals(0, empty.totalCount)

        val populated = CompanionMemory(
            enabled = true,
            preferredName = "Alex",
            interests = listOf("RPGs", "Synthwave"),
            preferences = listOf("Direct advice"),
            facts = listOf("Night owl", "Builds Android apps"),
            conversationSummary = "Planning a weekend game jam."
        )
        assertEquals(7, populated.totalCount)
    }

    @Test
    fun endpointNormalizationAppendsDefaultRouteForRootUrls() {
        val service = NexusAiService()
        assertEquals(
            "https://nexus.example.com/api/nexus/chat",
            service.normalizeEndpointUrl("https://nexus.example.com/")
        )
        assertEquals(
            "http://10.0.2.2:3000/api/nexus/chat",
            service.normalizeEndpointUrl("http://10.0.2.2:3000")
        )
        assertEquals(
            "https://nexus.example.com/api/nexus/chat",
            service.normalizeEndpointUrl("https://nexus.example.com/api/nexus/chat")
        )
    }

    @Test
    fun defaultCustomizationSettingsStayWithinExpectedBounds() {
        val defaults = CustomizationSettings()
        assertEquals(1.0f, defaults.scale)
        assertEquals(ResponseStyle.BALANCED, defaults.personality.responseStyle)
        assertTrue(defaults.sfxEnabled)
        assertFalse(defaults.personality.voiceConversationMode)
    }

    @Test
    fun animationControllerCoversAllTwelveEmotionsDistinctly() {
        val directives = CompanionEmotion.entries.map { emo ->
            NexusAnimationController.resolveDirective(
                emotion = emo,
                situation = CompanionSituation.CHATTING,
                mode = CharacterMode.NORMAL
            )
        }
        assertEquals(12, directives.size)

        val thinking = directives.first { it.emotion == CompanionEmotion.THINKING }
        assertTrue(thinking.gazeY < 0f)
        assertEquals(StageEffectOverlay.THINKING_DOTS, thinking.effectOverlay)
        assertEquals(CharacterPoseKey.THINKING_CHIN, thinking.poseKey)

        val embarrassed = directives.first { it.emotion == CompanionEmotion.EMBARRASSED }
        assertTrue(embarrassed.cheekBlushAlpha > 0.25f)
        assertTrue(embarrassed.gazeX < -0.5f)
        assertEquals(StageEffectOverlay.EMBARRASSED_SWEAT, embarrassed.effectOverlay)

        val angry = directives.first { it.emotion == CompanionEmotion.ANGRY }
        assertEquals(BrowStyle.FURROWED, angry.browStyle)
        assertEquals(MouthStyle.FROWN, angry.mouthStyle)
        assertEquals(StageEffectOverlay.ANGER_VEIN, angry.effectOverlay)

        val sleepy = directives.first { it.emotion == CompanionEmotion.SLEEPY }
        assertEquals(BlinkMode.SLEEPING, sleepy.blinkMode)
        assertEquals(MouthStyle.YAWN, sleepy.mouthStyle)
        assertEquals(StageEffectOverlay.SLEEP_ZZZ, sleepy.effectOverlay)
    }

    @Test
    fun animationControllerSelectsSituationSpecificPosesAndTransitions() {
        val greeting = NexusAnimationController.resolveDirective(
            emotion = CompanionEmotion.HAPPY,
            situation = CompanionSituation.GREETING,
            mode = CharacterMode.NORMAL
        )
        assertEquals(CharacterPoseKey.GREETING_WAVE, greeting.poseKey)
        assertEquals(MouthStyle.SMILE, greeting.mouthStyle)

        val joking = NexusAnimationController.resolveDirective(
            emotion = CompanionEmotion.PLAYFUL,
            situation = CompanionSituation.JOKING,
            mode = CharacterMode.NORMAL
        )
        assertEquals(CharacterPoseKey.JOKING_SMIRK, joking.poseKey)
        assertEquals(MouthStyle.SMIRK, joking.mouthStyle)
        assertTrue(joking.headTiltDeg > 2f)

        val listening = NexusAnimationController.resolveDirective(
            emotion = CompanionEmotion.NEUTRAL,
            situation = CompanionSituation.IDLE,
            mode = CharacterMode.CONVERSATION,
            isListening = true
        )
        assertEquals(CompanionSituation.LISTENING, listening.situation)
        assertEquals(CharacterPoseKey.LISTENING_ATTENTIVE, listening.poseKey)

        val gaming = NexusAnimationController.resolveDirective(
            emotion = CompanionEmotion.EXCITED,
            situation = CompanionSituation.IDLE,
            mode = CharacterMode.GAMING
        )
        assertEquals(CompanionSituation.GAMING, gaming.situation)
        assertEquals(CharacterPoseKey.GAMING_FOCUSED, gaming.poseKey)
    }

    @Test
    fun mouthSyncOpensWhileSpeakingAndStopsImmediatelyWhenSpeechEnds() {
        val speakingDirective = NexusAnimationController.resolveDirective(
            emotion = CompanionEmotion.HAPPY,
            situation = CompanionSituation.CHATTING,
            mode = CharacterMode.CONVERSATION,
            isSpeaking = true
        )
        assertEquals(MouthStyle.PARTED_SPEAK, speakingDirective.mouthStyle)
        val openWhileSpeaking = NexusAnimationController.computeEffectiveMouthOpenness(
            isSpeaking = true,
            speechMouthLevel = 0.78f,
            mouthStyle = speakingDirective.mouthStyle,
            yawnCyclePhase = 0f
        )
        assertEquals(0.78f, openWhileSpeaking, 0.001f)

        val idleDirective = NexusAnimationController.resolveDirective(
            emotion = CompanionEmotion.HAPPY,
            situation = CompanionSituation.CHATTING,
            mode = CharacterMode.CONVERSATION,
            isSpeaking = false
        )
        assertEquals(MouthStyle.SMILE, idleDirective.mouthStyle)
        val closedAfterSpeech = NexusAnimationController.computeEffectiveMouthOpenness(
            isSpeaking = false,
            speechMouthLevel = 0.78f,
            mouthStyle = idleDirective.mouthStyle,
            yawnCyclePhase = 0f
        )
        assertEquals(0f, closedAfterSpeech, 0.001f)
    }

    @Test
    fun openMeteoParsersAndWmoCodesWorkAccurately() {
        val geoJson = """
            {
              "results": [
                {
                  "id": 1850147,
                  "name": "Tokyo",
                  "latitude": 35.6895,
                  "longitude": 139.6917,
                  "admin1": "Tokyo",
                  "country": "Japan"
                }
              ]
            }
        """.trimIndent()
        val cities = OpenMeteoWeatherService.parseGeocodingJson(geoJson)
        assertEquals(1, cities.size)
        assertEquals("Tokyo", cities[0].name)
        assertEquals("Japan", cities[0].country)

        val forecastJson = """
            {
              "current": {
                "temperature_2m": 22.5,
                "relative_humidity_2m": 64,
                "precipitation": 1.2,
                "weather_code": 61,
                "wind_speed_10m": 14.3
              }
            }
        """.trimIndent()
        val snapshot = OpenMeteoWeatherService.parseForecastJson(
            rawJson = forecastJson,
            locationName = "Tokyo, Japan",
            fetchedAtMs = 1700000000000L
        )
        assertEquals(WeatherConditionCategory.RAINY, snapshot.conditionCategory)
        assertEquals("Light Rain", snapshot.conditionLabel)
        assertEquals("23°C", snapshot.formatTemperature(TemperatureUnit.CELSIUS))
        assertEquals("73°F", snapshot.formatTemperature(TemperatureUnit.FAHRENHEIT))
        assertEquals(64, snapshot.relativeHumidityPercent)

        assertEquals(WeatherConditionCategory.CLEAR_SUNNY, OpenMeteoWeatherService.interpretWmoCode(0).first)
        assertEquals(WeatherConditionCategory.PARTLY_CLOUDY, OpenMeteoWeatherService.interpretWmoCode(2).first)
        assertEquals(WeatherConditionCategory.CLOUDY, OpenMeteoWeatherService.interpretWmoCode(3).first)
        assertEquals(WeatherConditionCategory.FOGGY, OpenMeteoWeatherService.interpretWmoCode(45).first)
        assertEquals(WeatherConditionCategory.SNOWY, OpenMeteoWeatherService.interpretWmoCode(73).first)
        assertEquals(WeatherConditionCategory.THUNDERSTORM, OpenMeteoWeatherService.interpretWmoCode(95).first)
    }

    @Test
    fun weatherReactionEngineProducesDistinctReactionsPerCondition() {
        val baseTime = 1700000000000L
        val hotSunny = OpenMeteoWeatherService.parseForecastJson(
            rawJson = """{"current":{"temperature_2m":33.0,"relative_humidity_2m":40,"precipitation":0.0,"weather_code":0,"wind_speed_10m":6.0}}""",
            locationName = "Phoenix",
            fetchedAtMs = baseTime
        )
        val hotReaction = WeatherReactionEngine.evaluate(hotSunny, TemperatureUnit.CELSIUS, sarcasmLevel = 65)
        assertEquals(CompanionEmotion.PLAYFUL, hotReaction.emotion)
        assertTrue(hotReaction.dialogueCandidates.any { it.contains("33°C") && it.contains("Phoenix") })

        val storm = OpenMeteoWeatherService.parseForecastJson(
            rawJson = """{"current":{"temperature_2m":24.0,"relative_humidity_2m":88,"precipitation":6.5,"weather_code":95,"wind_speed_10m":28.0}}""",
            locationName = "Miami",
            fetchedAtMs = baseTime
        )
        val stormReaction = WeatherReactionEngine.evaluate(storm, TemperatureUnit.CELSIUS, sarcasmLevel = 65)
        assertTrue(stormReaction.dialogueCandidates.any { it.contains("Miami") })

        val cold = OpenMeteoWeatherService.parseForecastJson(
            rawJson = """{"current":{"temperature_2m":2.0,"relative_humidity_2m":72,"precipitation":0.0,"weather_code":2,"wind_speed_10m":18.0}}""",
            locationName = "Reykjavik",
            fetchedAtMs = baseTime
        )
        val coldReaction = WeatherReactionEngine.evaluate(cold, TemperatureUnit.CELSIUS, sarcasmLevel = 40)
        assertEquals(CompanionEmotion.CARING, coldReaction.emotion)
    }
}

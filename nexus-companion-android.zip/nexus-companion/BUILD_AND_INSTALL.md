# Building & Installing NEXUS Android APK

## Requirements
- **Android 12+** (`minSdk = 31`, `compileSdk = 35`, `targetSdk = 35`)
- **Android Studio**: Ladybug (2024.2.1) or newer
- **JDK**: Java 17

## Option 1: Build via Android Studio
1. Extract `nexus-companion-android.zip`.
2. Open Android Studio -> **File -> Open** -> select the `nexus-companion` folder.
3. Wait for Gradle sync (`Gradle 8.9`, AGP `8.7.3`, Kotlin `2.0.21`).
4. Connect an Android 12+ device (USB Debugging enabled) or launch an emulator and click **Run (`Shift+F10`)**.

## Option 2: Command Line & ADB
```bash
gradle testDebugUnitTest
gradle assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Option 3: GitHub Actions (No Local Android Studio Required)
1. Push the contents of `nexus-companion/` to a GitHub repository.
2. Open **Actions -> Build NEXUS Android APK -> Run workflow**.
3. Download `app-debug.apk` from the build artifacts.

## AI Chat & Permissions Note
- **Zero Embedded API Keys**: No API key is ever bundled inside the APK.
- **Live AI Backend**: To enable cloud Gemini AI replies in the Android app, run the companion Node server (`server.ts`) or deploy `/api/nexus/chat`, then paste its `/api/nexus/chat` endpoint URL into **Settings -> AI Backend URL** (e.g. `http://10.0.2.2:3000/api/nexus/chat` on the Android Emulator). Without a backend URL, NEXUS explicitly operates in **Offline Local Dialogue** mode without pretending simulated replies are real AI.
- **High-Res Character Asset**: Uses your upgraded transparent PNG at `app/src/main/res/drawable-nodpi/nexus_character.png` with density-safe downsampling to prevent mid-range memory spikes.
- **On-Demand Permissions**:
  - `RECORD_AUDIO`: Requested only when tapping the microphone button in Chat.
  - `POST_NOTIFICATIONS`: Requested on Android 13+ only when enabling Gaming Timer alerts.
  - Notification Access (`NotificationListenerService`): Optional, opened in Android System Settings only if you enable Notification Awareness.
  - Game Detection (`PACKAGE_USAGE_STATS` / Usage Access): Optional, opened in Android System Settings only if you enable foreground game detection for Gaming Mode.
